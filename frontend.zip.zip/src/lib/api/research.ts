import { api } from "./client";
import { ListQuery, Paginated, Research, ResearchStats, ResearchType } from "./types";

export interface ResearchListQuery extends ListQuery {
  type?: ResearchType;
  faculty_id?: string;
  year?: number;
  verified?: boolean;
}

export interface ResearchInput {
  faculty_id: string;
  title: string;
  type: ResearchType;
  journal_name?: string;
  publisher?: string;
  doi?: string;
  isbn_issn?: string;
  year?: number;
  volume?: string;
  issue?: string;
  pages?: string;
  impact_factor?: number;
  scopus_indexed?: boolean;
  wos_indexed?: boolean;
  ugc_listed?: boolean;
  funding_agency?: string;
  funding_amount?: number;
  abstract?: string;
  keywords?: string;
  co_authors?: string;
  document_url?: string;
}

export const researchApi = {
  list: (query: ResearchListQuery = {}) => api.get<Paginated<Research>>("/research", query),
  get: (id: string) => api.get<Research>(`/research/${id}`),
  stats: () => api.get<ResearchStats>("/research/stats"),
  create: (input: ResearchInput) => api.post<Research>("/research", input),
  update: (id: string, input: Partial<ResearchInput>) => api.put<Research>(`/research/${id}`, input),
  verify: (id: string) => api.patch<Research>(`/research/${id}/verify`),
  remove: (id: string) => api.delete<null>(`/research/${id}`),
};
