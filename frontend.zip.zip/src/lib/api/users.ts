import { api } from "./client";
import { BackendUserRole, ListQuery, ManagedUser, Paginated } from "./types";

export interface UserListQuery extends ListQuery {
  role?: BackendUserRole;
  dept?: string;
}

export interface UserCreateInput {
  email: string;
  password: string;
  name: string;
  role: BackendUserRole;
  phone?: string;
  designation?: string;
  employee_id?: string;
  department_id?: string;
}

export interface UserUpdateInput {
  name?: string;
  phone?: string;
  designation?: string;
  employee_id?: string;
  avatar_url?: string;
  department_id?: string;
  is_active?: boolean;
  role?: BackendUserRole;
}

export const usersApi = {
  list: (query: UserListQuery = {}) => api.get<Paginated<ManagedUser>>("/users", { limit: 50, ...query }),
  get: (id: string) => api.get<ManagedUser>(`/users/${id}`),
  create: (input: UserCreateInput) => api.post<ManagedUser>("/users", input),
  update: (id: string, input: UserUpdateInput) => api.put<ManagedUser>(`/users/${id}`, input),
  remove: (id: string) => api.delete<null>(`/users/${id}`),
};
