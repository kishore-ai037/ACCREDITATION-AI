import { api, apiRequest } from "./client";
import { AppDocument, CriterionType, DocStatus, DocumentStats, ListQuery, Paginated } from "./types";

// Server origin (without the `/api` suffix) — used to build links to statically
// served files under `/uploads`, since those are not behind the `/api` prefix.
const SERVER_ORIGIN = (process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000/api").replace(/\/api\/?$/, "");

/**
 * Builds the URL to view/download a document's stored file.
 * Relies on the backend's existing static `/uploads` route (see app.ts) and the
 * document's `file_path` (only present on the full record returned by
 * `documentsApi.get`, not the list endpoint). Returns null if unavailable.
 */
export function getDocumentDownloadUrl(doc: Pick<AppDocument, "file_path"> | null | undefined): string | null {
  if (!doc?.file_path) return null;
  const filename = doc.file_path.split(/[\\/]/).pop();
  if (!filename) return null;
  return `${SERVER_ORIGIN}/uploads/${filename}`;
}

export interface DocumentListQuery extends ListQuery {
  status?: DocStatus;
  criterion_type?: CriterionType;
  criterion_ref?: string;
  department_id?: string;
  ai_mapped?: boolean;
}

export interface DocumentUploadInput {
  file: File;
  title: string;
  description?: string;
  department_id?: string;
  criterion_type?: CriterionType;
  criterion_ref?: string;
  tags?: string;
  academic_year?: string;
}

export const documentsApi = {
  list: (query: DocumentListQuery = {}) => api.get<Paginated<AppDocument>>("/documents", query),
  get: (id: string) => api.get<AppDocument>(`/documents/${id}`),
  stats: () => api.get<DocumentStats>("/documents/stats"),
  search: (q: string, criterionType?: string) =>
    api.get<AppDocument[]>("/documents/search", { q, criterion_type: criterionType }),

  upload: (input: DocumentUploadInput) => {
    const form = new FormData();
    form.append("file", input.file);
    form.append("title", input.title);
    if (input.description) form.append("description", input.description);
    if (input.department_id) form.append("department_id", input.department_id);
    if (input.criterion_type) form.append("criterion_type", input.criterion_type);
    if (input.criterion_ref) form.append("criterion_ref", input.criterion_ref);
    if (input.tags) form.append("tags", input.tags);
    if (input.academic_year) form.append("academic_year", input.academic_year);

    return apiRequest<AppDocument>("/documents/upload", {
      method: "POST",
      body: form,
      isFormData: true,
    });
  },

  approve: (id: string, note?: string) => api.patch<AppDocument>(`/documents/${id}/approve`, { note }),
  reject: (id: string, note?: string) => api.patch<AppDocument>(`/documents/${id}/reject`, { note }),
  setStatus: (id: string, status: DocStatus, note?: string) =>
    api.patch<AppDocument>(`/documents/${id}/status`, { status, note }),
  remove: (id: string) => api.delete<null>(`/documents/${id}`),
};
