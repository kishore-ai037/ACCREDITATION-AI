import { api } from "./client";
import { DashboardSummary, DocumentTrendPoint, RecentActivityItem } from "./types";

export const dashboardApi = {
  summary: () => api.get<DashboardSummary>("/dashboard/summary"),
  recentActivity: (limit = 10) => api.get<RecentActivityItem[]>("/dashboard/recent-activity", { limit }),
  documentTrend: (months = 6) => api.get<DocumentTrendPoint[]>("/dashboard/document-trend", { months }),
};
