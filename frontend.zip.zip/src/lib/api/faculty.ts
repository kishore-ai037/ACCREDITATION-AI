import { api } from "./client";
import { EmploymentType, Faculty, FacultyStats, ListQuery, Paginated } from "./types";

export interface FacultyListQuery extends ListQuery {
  department_id?: string;
  employment_type?: EmploymentType;
}

export interface FacultyInput {
  user_id: string;
  department_id?: string;
  employee_code?: string;
  gender?: string;
  date_of_birth?: string;
  date_of_joining?: string;
  employment_type?: EmploymentType;
  qualification?: string;
  specialization?: string;
  experience_years?: number;
  industry_exp_years?: number;
  ugc_net?: boolean;
  gate_score?: number;
  phd_guide?: boolean;
  phd_students_count?: number;
  funded_projects?: number;
  publications_count?: number;
  patents_count?: number;
  awards_count?: number;
  fdp_attended?: number;
  fdp_organized?: number;
  orcid_id?: string;
  scopus_id?: string;
  google_scholar_url?: string;
  profile_url?: string;
}

export const facultyApi = {
  list: (query: FacultyListQuery = {}) => api.get<Paginated<Faculty>>("/faculty", query),
  get: (id: string) => api.get<Faculty>(`/faculty/${id}`),
  stats: () => api.get<FacultyStats>("/faculty/stats"),
  create: (input: FacultyInput) => api.post<Faculty>("/faculty", input),
  update: (id: string, input: Partial<FacultyInput>) => api.put<Faculty>(`/faculty/${id}`, input),
  remove: (id: string) => api.delete<null>(`/faculty/${id}`),
};
