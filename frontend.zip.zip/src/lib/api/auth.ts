import { api } from "./client";
import { LoginResponse, RefreshResponse, UserProfile } from "./types";

export const authApi = {
  login: (email: string, password: string) =>
    api.post<LoginResponse>("/auth/login", { email, password }, { skipAuth: true }),

  refresh: (refreshToken: string) =>
    api.post<RefreshResponse>("/auth/refresh", { refreshToken }, { skipAuth: true }),

  logout: () => api.post<null>("/auth/logout"),

  me: () => api.get<UserProfile>("/auth/me"),

  changePassword: (currentPassword: string, newPassword: string) =>
    api.post<null>("/auth/change-password", { currentPassword, newPassword }),
};
