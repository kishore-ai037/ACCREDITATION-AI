import { api } from "./client";
import { Department, ListQuery, Paginated } from "./types";

export interface DepartmentInput {
  name: string;
  code: string;
  hod_name?: string;
  established?: number;
  intake?: number;
  nba_accredited?: boolean;
  nba_valid_till?: string;
  description?: string;
}

export const departmentsApi = {
  list: (query: ListQuery = {}) => api.get<Paginated<Department>>("/departments", { limit: 50, ...query }),
  get: (id: string) => api.get<Department>(`/departments/${id}`),
  create: (input: DepartmentInput) => api.post<Department>("/departments", input),
  update: (id: string, input: Partial<DepartmentInput>) => api.put<Department>(`/departments/${id}`, input),
  remove: (id: string) => api.delete<null>(`/departments/${id}`),
};
