import { ApiError, tokenStorage } from "./client";
import { api } from "./client";
import { ListQuery, Paginated, Report, ReportType } from "./types";

export interface ReportGenerateInput {
  title: string;
  type: ReportType;
  academic_year?: string;
  description?: string;
  parameters?: Record<string, unknown>;
}

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000/api";

export const reportsApi = {
  list: (query: ListQuery & { type?: ReportType; academic_year?: string } = {}) =>
    api.get<Paginated<Report>>("/reports", query),
  get: (id: string) => api.get<Report>(`/reports/${id}`),
  generate: (input: ReportGenerateInput) => api.post<Report>("/reports/generate", input),
  remove: (id: string) => api.delete<null>(`/reports/${id}`),

  /** Triggers a browser download of the generated report file. */
  async download(id: string, filename: string): Promise<void> {
    const token = tokenStorage.getAccessToken();
    const res = await fetch(`${API_BASE_URL}/reports/${id}/download`, {
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    });
    if (!res.ok) {
      throw new ApiError("Failed to download report", res.status);
    }
    const blob = await res.blob();
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.URL.revokeObjectURL(url);
  },
};
