import { api } from "./client";
import { AppNotification, ListQuery, Paginated } from "./types";

export const notificationsApi = {
  list: (query: ListQuery & { unread?: boolean } = {}) =>
    api.get<Paginated<AppNotification>>("/notifications", query),
  unreadCount: () => api.get<{ count: number }>("/notifications/unread-count"),
  markRead: (id: string) => api.patch<AppNotification>(`/notifications/${id}/read`),
  markAllRead: () => api.patch<{ updated: number }>("/notifications/read-all"),
  remove: (id: string) => api.delete<null>(`/notifications/${id}`),
};
