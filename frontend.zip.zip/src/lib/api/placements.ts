import { api } from "./client";
import {
  ListQuery,
  Paginated,
  Placement,
  PlacementStats,
  PlacementStatus,
  PlacementTrendPoint,
} from "./types";

export interface PlacementListQuery extends ListQuery {
  department_id?: string;
  batch_year?: number;
  status?: PlacementStatus;
}

export interface PlacementInput {
  status?: PlacementStatus;
  company_name?: string;
  package_lpa?: number;
  offer_date?: string;
  joining_date?: string;
  job_role?: string;
  placement_type?: string;
  higher_studies?: string;
  batch_year?: number;
}

export const placementsApi = {
  list: (query: PlacementListQuery = {}) => api.get<Paginated<Placement>>("/placements", query),
  get: (id: string) => api.get<Placement>(`/placements/${id}`),
  stats: (batchYear?: number) => api.get<PlacementStats>("/placements/stats", { batch_year: batchYear }),
  trend: () => api.get<PlacementTrendPoint[]>("/placements/trend"),
  upsertForStudent: (studentId: string, input: PlacementInput) =>
    api.put<Placement>(`/placements/student/${studentId}`, input),
  remove: (id: string) => api.delete<null>(`/placements/${id}`),
};
