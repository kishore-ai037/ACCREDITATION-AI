import { api } from "./client";
import { AIAnalysis, AIAnalysisStatsSummary, AIAnalysisStatus, ListQuery, Paginated } from "./types";

export const aiAnalysisApi = {
  list: (query: ListQuery & { status?: AIAnalysisStatus; analysis_type?: string } = {}) =>
    api.get<Paginated<AIAnalysis>>("/ai-analysis", query),
  get: (id: string) => api.get<AIAnalysis>(`/ai-analysis/${id}`),
  stats: () => api.get<AIAnalysisStatsSummary>("/ai-analysis/stats"),
  mapDocument: (documentId: string) =>
    api.post<AIAnalysis>("/ai-analysis/map-document", { document_id: documentId }),
  bulkSearch: (criterionType: "naac" | "nba" = "naac") =>
    api.post<AIAnalysis>("/ai-analysis/bulk-search", { criterion_type: criterionType }),
};
