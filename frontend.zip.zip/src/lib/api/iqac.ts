import { api } from "./client";
import { IqacActionPlan, IqacMeeting, ListQuery, Paginated } from "./types";

export interface MeetingInput {
  title: string;
  meeting_date: string;
  venue?: string;
  agenda?: string;
  minutes?: string;
  action_points?: unknown[];
  attendees?: string[];
  document_url?: string;
}

export interface ActionPlanInput {
  title: string;
  description?: string;
  target_date?: string;
  responsible_id?: string;
  status?: string;
  academic_year?: string;
  priority?: string;
  remarks?: string;
  completion_pct?: number;
}

export const iqacApi = {
  listMeetings: (query: ListQuery & { year?: string } = {}) =>
    api.get<Paginated<IqacMeeting>>("/iqac/meetings", query),
  getMeeting: (id: string) => api.get<IqacMeeting>(`/iqac/meetings/${id}`),
  createMeeting: (input: MeetingInput) => api.post<IqacMeeting>("/iqac/meetings", input),
  updateMeeting: (id: string, input: Partial<MeetingInput>) =>
    api.put<IqacMeeting>(`/iqac/meetings/${id}`, input),
  removeMeeting: (id: string) => api.delete<null>(`/iqac/meetings/${id}`),

  listActionPlans: (query: ListQuery & { status?: string; academic_year?: string } = {}) =>
    api.get<Paginated<IqacActionPlan>>("/iqac/action-plans", query),
  createActionPlan: (input: ActionPlanInput) => api.post<IqacActionPlan>("/iqac/action-plans", input),
  updateActionPlan: (id: string, input: Partial<ActionPlanInput>) =>
    api.put<IqacActionPlan>(`/iqac/action-plans/${id}`, input),
  removeActionPlan: (id: string) => api.delete<null>(`/iqac/action-plans/${id}`),
};
