import { api } from "./client";
import { ListQuery, Paginated, Student, StudentStats } from "./types";

export interface StudentListQuery extends ListQuery {
  department_id?: string;
  batch_year?: number;
  active?: boolean;
}

export interface StudentInput {
  department_id: string;
  roll_number: string;
  name: string;
  email?: string;
  phone?: string;
  gender?: string;
  date_of_birth?: string;
  batch_year: number;
  year_of_study?: number;
  semester?: number;
  section?: string;
  lateral_entry?: boolean;
  category?: string;
  cgpa?: number;
  arrear_count?: number;
}

export const studentsApi = {
  list: (query: StudentListQuery = {}) => api.get<Paginated<Student>>("/students", query),
  get: (id: string) => api.get<Student>(`/students/${id}`),
  stats: () => api.get<StudentStats>("/students/stats"),
  create: (input: StudentInput) => api.post<Student>("/students", input),
  update: (id: string, input: Partial<StudentInput> & { active?: boolean }) =>
    api.put<Student>(`/students/${id}`, input),
  remove: (id: string) => api.delete<null>(`/students/${id}`),
};
