// ─── Enums (mirrors backend/src/types/index.ts) ────────────────────────────

export type BackendUserRole =
  | "admin"
  | "principal"
  | "iqac_coordinator"
  | "hod"
  | "faculty"
  | "student";

export type DocStatus = "draft" | "pending" | "approved" | "rejected" | "archived";
export type CriterionType = "naac" | "nba" | "obe" | "iqac";
export type NotifType = "info" | "warning" | "success" | "error";
export type ResearchType =
  | "journal"
  | "conference"
  | "book"
  | "book_chapter"
  | "patent"
  | "project"
  | "consultancy";
export type PlacementStatus = "placed" | "not_placed" | "higher_studies" | "entrepreneur";
export type ReportType = "naac_ssr" | "naac_iqar" | "nba_sar" | "iqac_aqar" | "custom";
export type AIAnalysisStatus = "pending" | "running" | "completed" | "failed";
export type EmploymentType = "permanent" | "temporary" | "visiting" | "contract";

// ─── Pagination ─────────────────────────────────────────────────────────────

export interface Paginated<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

export interface ListQuery {
  page?: number;
  limit?: number;
  search?: string;
  [key: string]: string | number | boolean | undefined;
}

// ─── Auth ───────────────────────────────────────────────────────────────────

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  role: BackendUserRole;
  designation: string | null;
  department_id: string | null;
  institution_id: string;
  institution: string;
  avatar_url: string | null;
}

export interface LoginResponse {
  user: AuthUser;
  accessToken: string;
  refreshToken: string;
}

export interface RefreshResponse {
  accessToken: string;
  refreshToken: string;
}

export interface UserProfile extends AuthUser {
  phone?: string | null;
  employee_id?: string | null;
  is_active: boolean;
  last_login?: string | null;
  created_at: string;
  department?: string | null;
  department_code?: string | null;
}

// ─── Institution / Department ──────────────────────────────────────────────

export interface Institution {
  id: string;
  name: string;
  code: string;
  address?: string;
  city?: string;
  state?: string;
  pincode?: string;
  phone?: string;
  email?: string;
  website?: string;
  established?: number;
  naac_grade?: string;
  naac_score?: number;
  nba_status: boolean;
}

export interface Department {
  id: string;
  institution_id: string;
  name: string;
  code: string;
  hod_name?: string | null;
  established?: number | null;
  intake: number;
  nba_accredited: boolean;
  nba_valid_till?: string | null;
  description?: string | null;
  faculty_count?: number;
  student_count?: number;
  document_count?: number;
  created_at: string;
  updated_at: string;
}

// ─── User (admin-managed) ───────────────────────────────────────────────────

export interface ManagedUser {
  id: string;
  name: string;
  email: string;
  role: BackendUserRole;
  phone?: string | null;
  avatar_url?: string | null;
  designation?: string | null;
  employee_id?: string | null;
  is_active: boolean;
  last_login?: string | null;
  created_at: string;
  department?: string | null;
  department_code?: string | null;
  department_id?: string | null;
}

// ─── Faculty ────────────────────────────────────────────────────────────────

export interface Faculty {
  id: string;
  user_id: string;
  department_id: string;
  employee_code?: string | null;
  gender?: string | null;
  date_of_birth?: string | null;
  date_of_joining?: string | null;
  employment_type: EmploymentType;
  qualification?: string | null;
  specialization?: string | null;
  experience_years: number;
  industry_exp_years: number;
  ugc_net: boolean;
  gate_score?: number | null;
  phd_guide: boolean;
  phd_students_count: number;
  funded_projects: number;
  publications_count: number;
  patents_count: number;
  awards_count: number;
  fdp_attended: number;
  fdp_organized: number;
  orcid_id?: string | null;
  scopus_id?: string | null;
  google_scholar_url?: string | null;
  profile_url?: string | null;
  name: string;
  email: string;
  phone?: string | null;
  designation?: string | null;
  avatar_url?: string | null;
  employee_id?: string | null;
  department?: string;
  department_code?: string;
  publications?: Research[];
  created_at: string;
  updated_at: string;
}

export interface FacultyStats {
  total_faculty: number;
  permanent: number;
  ugc_net_qualified: number;
  phd_guides: number;
  total_publications: number;
  total_patents: number;
  total_funded_projects: number;
  avg_experience: number;
  total_fdp_attended: number;
}

// ─── Student ────────────────────────────────────────────────────────────────

export interface Student {
  id: string;
  institution_id: string;
  department_id: string;
  roll_number: string;
  name: string;
  email?: string | null;
  phone?: string | null;
  gender?: string | null;
  date_of_birth?: string | null;
  batch_year: number;
  year_of_study?: number | null;
  semester?: number | null;
  section?: string | null;
  lateral_entry: boolean;
  category?: string | null;
  cgpa?: number | null;
  arrear_count: number;
  active: boolean;
  department?: string;
  department_code?: string;
  placement_status?: PlacementStatus | null;
  company_name?: string | null;
  package_lpa?: number | null;
  job_role?: string | null;
  created_at: string;
  updated_at: string;
}

export interface StudentStats {
  total_students: number;
  active_students: number;
  total_batches: number;
  lateral_entries: number;
  avg_cgpa: number;
  students_with_arrears: number;
  female_students: number;
  male_students: number;
  total_placed: number;
}

// ─── Documents ──────────────────────────────────────────────────────────────

export interface AppDocument {
  id: string;
  institution_id: string;
  department_id?: string | null;
  uploaded_by: string;
  reviewed_by?: string | null;
  title: string;
  description?: string | null;
  file_name: string;
  file_path?: string;
  file_type?: string | null;
  file_size?: number | null;
  status: DocStatus;
  criterion_type?: CriterionType | null;
  criterion_ref?: string | null;
  tags?: string[] | null;
  ai_tags?: string[] | null;
  ai_mapped: boolean;
  ai_confidence?: number | null;
  academic_year?: string | null;
  version: number;
  rejection_note?: string | null;
  review_note?: string | null;
  uploaded_by_name?: string;
  uploaded_by_email?: string;
  reviewed_by_name?: string;
  department?: string;
  created_at: string;
  updated_at: string;
}

export interface DocumentStats {
  total: number;
  draft: number;
  pending: number;
  approved: number;
  rejected: number;
  ai_mapped: number;
  total_size_bytes: number;
  naac_docs: number;
  nba_docs: number;
  iqac_docs: number;
}

// ─── Research ───────────────────────────────────────────────────────────────

export interface Research {
  id: string;
  faculty_id: string;
  title: string;
  type: ResearchType;
  journal_name?: string | null;
  publisher?: string | null;
  doi?: string | null;
  isbn_issn?: string | null;
  year?: number | null;
  volume?: string | null;
  issue?: string | null;
  pages?: string | null;
  impact_factor?: number | null;
  scopus_indexed: boolean;
  wos_indexed: boolean;
  ugc_listed: boolean;
  funding_agency?: string | null;
  funding_amount?: number | null;
  abstract?: string | null;
  keywords?: string[] | null;
  co_authors?: string[] | null;
  document_url?: string | null;
  verified: boolean;
  verified_by?: string | null;
  faculty_name?: string;
  faculty_email?: string;
  department?: string;
  verified_by_name?: string;
  created_at: string;
  updated_at: string;
}

export interface ResearchStats {
  total: number;
  journals: number;
  conferences: number;
  patents: number;
  books: number;
  scopus_indexed: number;
  wos_indexed: number;
  ugc_listed: number;
  verified: number;
  avg_impact_factor: number;
  total_funding_amount: number;
  years_covered: number;
}

// ─── Placements ─────────────────────────────────────────────────────────────

export interface Placement {
  id: string;
  student_id: string;
  batch_year: number;
  status: PlacementStatus;
  company_name?: string | null;
  package_lpa?: number | null;
  offer_date?: string | null;
  joining_date?: string | null;
  job_role?: string | null;
  placement_type?: string | null;
  higher_studies?: string | null;
  student_name?: string;
  roll_number?: string;
  student_email?: string;
  cgpa?: number;
  department?: string;
  department_code?: string;
  created_at: string;
  updated_at: string;
}

export interface PlacementStatsSummary {
  total_students: number;
  placed: number;
  not_placed: number;
  higher_studies: number;
  entrepreneur: number;
  placement_percentage: number;
  avg_package_lpa: number;
  highest_package_lpa: number;
  lowest_package_lpa: number;
  unique_companies: number;
}

export interface PlacementStats {
  summary: PlacementStatsSummary;
  by_department: Array<{
    department: string;
    code: string;
    total: number;
    placed: number;
    pct: number;
    avg_pkg: number;
  }>;
  top_recruiters: Array<{
    company_name: string;
    hires: number;
    avg_package: number;
    max_package: number;
  }>;
}

export interface PlacementTrendPoint {
  batch_year: number;
  total: number;
  placed: number;
  placement_pct: number;
  avg_package: number;
}

// ─── NAAC / NBA Criteria ────────────────────────────────────────────────────

export interface NaacCriteria {
  id: string;
  institution_id: string;
  criterion_no: string;
  criterion_name: string;
  sub_criteria?: string | null;
  description?: string | null;
  max_score: number;
  current_score: number;
  completion_pct: number;
  cycle_year?: string | null;
  responsible_id?: string | null;
  responsible_name?: string;
  due_date?: string | null;
  notes?: string | null;
  created_at: string;
  updated_at: string;
}

export interface NaacOverview {
  criteria: NaacCriteria[];
  aggregate: {
    total_criteria: number;
    overall_completion: number;
    total_score: number;
    max_possible_score: number;
    criteria_above_80: number;
    criteria_below_50: number;
  };
}

export interface NbaCriteria {
  id: string;
  department_id: string;
  criterion_no: string;
  criterion_name: string;
  max_marks?: number | null;
  obtained_marks: number;
  completion_pct: number;
  cycle_year?: string | null;
  tier: number;
  notes?: string | null;
  department?: string;
  department_code?: string;
  created_at: string;
  updated_at: string;
}

export interface NbaOverviewRow {
  department: string;
  department_code: string;
  total_criteria: number;
  avg_completion: number;
  total_obtained: number;
  total_max: number;
}

// ─── IQAC ───────────────────────────────────────────────────────────────────

export interface IqacMeeting {
  id: string;
  institution_id: string;
  title: string;
  meeting_date: string;
  venue?: string | null;
  agenda?: string | null;
  minutes?: string | null;
  action_points?: unknown[];
  attendees?: string[];
  document_url?: string | null;
  created_by: string;
  created_by_name?: string;
  created_at: string;
  updated_at: string;
}

export interface IqacActionPlan {
  id: string;
  institution_id: string;
  title: string;
  description?: string | null;
  target_date?: string | null;
  responsible_id?: string | null;
  responsible_name?: string;
  status: string;
  completion_pct?: number;
  academic_year?: string | null;
  priority: string;
  remarks?: string | null;
  created_at: string;
  updated_at: string;
}

// ─── Reports ────────────────────────────────────────────────────────────────

export interface Report {
  id: string;
  institution_id: string;
  generated_by: string;
  title: string;
  type: ReportType;
  academic_year?: string | null;
  description?: string | null;
  parameters?: Record<string, unknown>;
  file_path?: string | null;
  file_size?: number | null;
  status: string;
  generated_at?: string | null;
  generated_by_name?: string;
  created_at: string;
  updated_at: string;
}

// ─── AI Analysis ────────────────────────────────────────────────────────────

export interface AIAnalysis {
  id: string;
  institution_id: string;
  document_id?: string | null;
  triggered_by: string;
  analysis_type: string;
  status: AIAnalysisStatus;
  input_data?: Record<string, unknown>;
  result?: {
    naac_suggestions?: CriterionSuggestion[];
    nba_suggestions?: CriterionSuggestion[];
    recommended_tags?: string[];
    matches?: Array<{ document_id: string; title: string; criterion_ref: string; confidence: number }>;
    scanned?: number;
    matched?: number;
  };
  suggestions?: Record<string, unknown>;
  confidence?: number | null;
  criteria_mapped?: string[];
  error_message?: string | null;
  started_at?: string | null;
  completed_at?: string | null;
  triggered_by_name?: string;
  document_title?: string;
  created_at: string;
}

export interface CriterionSuggestion {
  criterion_ref: string;
  confidence: number;
  matched_keywords: string[];
}

export interface AIAnalysisStatsSummary {
  total_jobs: number;
  completed: number;
  failed: number;
  running: number;
  avg_confidence: number;
  documents_ai_mapped: number;
  documents_unmapped: number;
}

// ─── Notifications ──────────────────────────────────────────────────────────

export interface AppNotification {
  id: string;
  user_id: string;
  title: string;
  message: string;
  type: NotifType;
  link?: string | null;
  read: boolean;
  metadata?: Record<string, unknown>;
  created_at: string;
}

// ─── Dashboard ──────────────────────────────────────────────────────────────

export interface DashboardSummary {
  institution: {
    name: string;
    code: string;
    naac_grade?: string;
    naac_score?: number;
    nba_status: boolean;
  } | null;
  naac_score: number | null;
  naac_completion_pct: number;
  documents: { total: number; approved: number };
  faculty_count: number;
  student_count: number;
  pending_reviews: number;
}

export interface RecentActivityItem {
  id: string;
  user_name: string;
  action: string;
  entity_type?: string;
  entity_title?: string;
  description: string;
  created_at: string;
}

export interface DocumentTrendPoint {
  month: string;
  uploaded: number;
  reviewed: number;
}
