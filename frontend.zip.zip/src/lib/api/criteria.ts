import { api } from "./client";
import { ListQuery, NaacCriteria, NaacOverview, NbaCriteria, NbaOverviewRow, Paginated } from "./types";

export interface NaacInput {
  criterion_no: string;
  criterion_name: string;
  sub_criteria?: string;
  description?: string;
  max_score?: number;
  current_score?: number;
  completion_pct?: number;
  cycle_year?: string;
  responsible_id?: string;
  due_date?: string;
  notes?: string;
}

export interface NbaInput {
  department_id: string;
  criterion_no: string;
  criterion_name: string;
  max_marks?: number;
  obtained_marks?: number;
  completion_pct?: number;
  cycle_year?: string;
  tier?: number;
  notes?: string;
}

export const criteriaApi = {
  // NAAC
  listNaac: (query: ListQuery & { cycle_year?: string } = {}) =>
    api.get<Paginated<NaacCriteria>>("/criteria/naac", { limit: 50, ...query }),
  getNaac: (id: string) => api.get<NaacCriteria>(`/criteria/naac/${id}`),
  naacOverview: () => api.get<NaacOverview>("/criteria/naac/overview"),
  createNaac: (input: NaacInput) => api.post<NaacCriteria>("/criteria/naac", input),
  updateNaac: (id: string, input: Partial<NaacInput>) => api.put<NaacCriteria>(`/criteria/naac/${id}`, input),
  removeNaac: (id: string) => api.delete<null>(`/criteria/naac/${id}`),

  // NBA
  listNba: (query: ListQuery & { department_id?: string; cycle_year?: string } = {}) =>
    api.get<Paginated<NbaCriteria>>("/criteria/nba", { limit: 50, ...query }),
  getNba: (id: string) => api.get<NbaCriteria>(`/criteria/nba/${id}`),
  nbaOverview: (departmentId?: string) =>
    api.get<NbaOverviewRow[]>("/criteria/nba/overview", { department_id: departmentId }),
  createNba: (input: NbaInput) => api.post<NbaCriteria>("/criteria/nba", input),
  updateNba: (id: string, input: Partial<NbaInput>) => api.put<NbaCriteria>(`/criteria/nba/${id}`, input),
  removeNba: (id: string) => api.delete<null>(`/criteria/nba/${id}`),
};
