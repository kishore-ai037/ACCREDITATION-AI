import { NavItem } from "@/types";

export const navItems: NavItem[] = [
  { label: "Dashboard", href: "/dashboard", icon: "LayoutDashboard" },
  { label: "Documents", href: "/dashboard/documents", icon: "FileText" },
  { label: "AI Evidence Search", href: "/dashboard/ai-search", icon: "Sparkles" },
  { label: "NAAC", href: "/dashboard/naac", icon: "Award" },
  { label: "NBA / OBE", href: "/dashboard/nba", icon: "GraduationCap" },
  { label: "IQAC", href: "/dashboard/iqac", icon: "ShieldCheck", roles: ["admin", "iqac_coordinator"] },
  { label: "Faculty", href: "/dashboard/faculty", icon: "Users" },
  { label: "Students", href: "/dashboard/students", icon: "BookOpen" },
  { label: "Departments", href: "/dashboard/departments", icon: "Building2" },
  { label: "Reports", href: "/dashboard/reports", icon: "BarChart3" },
  { label: "Settings", href: "/dashboard/settings", icon: "Settings" },
];
