import LoginForm from "@/components/auth/LoginForm";

export const metadata = {
  title: "Sign In – AccrediAI",
};

export default function LoginPage() {
  return <LoginForm />;
}
