"use client";

import { useCallback, useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Plus, Building2, Users, GraduationCap, Pencil, Trash2, Search, BadgeCheck } from "lucide-react";
import PageHeader from "@/components/ui/PageHeader";
import MiniStat from "@/components/ui/MiniStat";
import Modal from "@/components/ui/Modal";
import ConfirmDialog from "@/components/ui/ConfirmDialog";
import { LoadingState, ErrorState, EmptyState, InlineError } from "@/components/ui/DataState";
import { FieldWrapper, TextInput, Checkbox, FormActions } from "@/components/ui/FormField";
import { useToast } from "@/components/ui/Toast";
import { useAuth } from "@/context/AuthContext";
import { departmentsApi, DepartmentInput } from "@/lib/api";
import { Department } from "@/lib/api/types";
import { getErrorMessage } from "@/lib/utils";

const emptyForm: DepartmentInput = {
  name: "",
  code: "",
  hod_name: "",
  established: undefined,
  intake: 60,
  nba_accredited: false,
  nba_valid_till: "",
  description: "",
};

export default function DepartmentsPage() {
  const { user } = useAuth();
  const { showToast } = useToast();
  const canManage = user?.role === "admin" || user?.role === "principal";

  const [departments, setDepartments] = useState<Department[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState("");

  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Department | null>(null);
  const [form, setForm] = useState<DepartmentInput>(emptyForm);
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const [deleteTarget, setDeleteTarget] = useState<Department | null>(null);
  const [deleting, setDeleting] = useState(false);

  const load = useCallback(() => {
    setLoading(true);
    setError(null);
    departmentsApi
      .list({ search: search || undefined })
      .then((r) => setDepartments(r.data))
      .catch((err) => setError(getErrorMessage(err, "Could not load departments.")))
      .finally(() => setLoading(false));
  }, [search]);

  useEffect(() => {
    const t = setTimeout(load, 250);
    return () => clearTimeout(t);
  }, [load]);

  const openCreate = () => {
    setEditing(null);
    setForm(emptyForm);
    setFormError(null);
    setModalOpen(true);
  };

  const openEdit = (d: Department) => {
    setEditing(d);
    setForm({
      name: d.name,
      code: d.code,
      hod_name: d.hod_name || "",
      established: d.established || undefined,
      intake: d.intake,
      nba_accredited: d.nba_accredited,
      nba_valid_till: d.nba_valid_till ? d.nba_valid_till.slice(0, 10) : "",
      description: d.description || "",
    });
    setFormError(null);
    setModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setSaving(true);
    try {
      const payload: DepartmentInput = {
        ...form,
        established: form.established ? Number(form.established) : undefined,
        intake: form.intake ? Number(form.intake) : undefined,
        nba_valid_till: form.nba_valid_till || undefined,
      };
      if (editing) {
        await departmentsApi.update(editing.id, payload);
        showToast("Department updated successfully.");
      } else {
        await departmentsApi.create(payload);
        showToast("Department created successfully.");
      }
      setModalOpen(false);
      load();
    } catch (err) {
      setFormError(getErrorMessage(err, "Could not save department."));
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await departmentsApi.remove(deleteTarget.id);
      showToast("Department deleted.");
      setDeleteTarget(null);
      load();
    } catch (err) {
      showToast(getErrorMessage(err, "Could not delete department."), "error");
    } finally {
      setDeleting(false);
    }
  };

  const totals = departments.reduce(
    (acc, d) => ({
      faculty: acc.faculty + (d.faculty_count || 0),
      students: acc.students + (d.student_count || 0),
      documents: acc.documents + (d.document_count || 0),
      nba: acc.nba + (d.nba_accredited ? 1 : 0),
    }),
    { faculty: 0, students: 0, documents: 0, nba: 0 }
  );

  return (
    <div className="max-w-7xl mx-auto">
      <PageHeader
        title="Departments"
        subtitle="Manage academic departments across your institution"
        actions={
          canManage && (
            <button
              onClick={openCreate}
              className="inline-flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold px-4 py-2.5 rounded-xl transition shadow-lg shadow-blue-600/20"
            >
              <Plus className="w-4 h-4" /> Add Department
            </button>
          )
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <MiniStat label="Departments" value={departments.length} icon={Building2} color="blue" />
        <MiniStat label="Total Faculty" value={totals.faculty} icon={Users} color="indigo" />
        <MiniStat label="Total Students" value={totals.students} icon={GraduationCap} color="emerald" />
        <MiniStat label="NBA Accredited" value={totals.nba} icon={BadgeCheck} color="amber" />
      </div>

      <div className="bg-[var(--card)] border border-[var(--border)] rounded-2xl overflow-hidden">
        <div className="p-4 border-b border-[var(--border)]">
          <div className="relative max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--muted-foreground)]" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search departments…"
              className="w-full pl-9 pr-3 py-2 text-sm rounded-xl border border-[var(--border)] bg-[var(--muted)] text-[var(--foreground)] placeholder:text-[var(--muted-foreground)] focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        {loading ? (
          <LoadingState label="Loading departments…" />
        ) : error ? (
          <ErrorState message={error} onRetry={load} />
        ) : departments.length === 0 ? (
          <EmptyState
            title="No departments found"
            message={search ? "Try a different search term." : "Add your first department to get started."}
            icon={Building2}
          />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 p-4">
            {departments.map((d, i) => (
              <motion.div
                key={d.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.03 }}
                className="border border-[var(--border)] rounded-2xl p-4 hover:shadow-md transition group"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white text-xs font-bold shrink-0">
                      {d.code}
                    </div>
                    <div className="min-w-0">
                      <div className="font-semibold text-[var(--foreground)] text-sm truncate">{d.name}</div>
                      {d.hod_name && <div className="text-[11px] text-[var(--muted-foreground)] truncate">HoD: {d.hod_name}</div>}
                    </div>
                  </div>
                  {canManage && (
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition shrink-0">
                      <button
                        onClick={() => openEdit(d)}
                        className="p-1.5 rounded-lg hover:bg-[var(--muted)] text-[var(--muted-foreground)] hover:text-[var(--foreground)]"
                      >
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setDeleteTarget(d)}
                        className="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-950/30 text-[var(--muted-foreground)] hover:text-red-600"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>
                {d.nba_accredited && (
                  <span className="inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 mb-3">
                    <BadgeCheck className="w-3 h-3" /> NBA Accredited
                  </span>
                )}
                <div className="grid grid-cols-3 gap-2 text-center pt-3 border-t border-[var(--border)]">
                  <div>
                    <div className="text-sm font-bold text-[var(--foreground)]">{d.faculty_count ?? 0}</div>
                    <div className="text-[10px] text-[var(--muted-foreground)]">Faculty</div>
                  </div>
                  <div>
                    <div className="text-sm font-bold text-[var(--foreground)]">{d.student_count ?? 0}</div>
                    <div className="text-[10px] text-[var(--muted-foreground)]">Students</div>
                  </div>
                  <div>
                    <div className="text-sm font-bold text-[var(--foreground)]">{d.document_count ?? 0}</div>
                    <div className="text-[10px] text-[var(--muted-foreground)]">Documents</div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>

      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editing ? "Edit Department" : "Add Department"}
        subtitle={editing ? editing.name : "Create a new academic department"}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          {formError && <InlineError message={formError} />}
          <div className="grid grid-cols-2 gap-3">
            <FieldWrapper label="Department Name" required className="col-span-2">
              <TextInput
                required
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="Computer Science & Engineering"
              />
            </FieldWrapper>
            <FieldWrapper label="Department Code" required>
              <TextInput
                required
                value={form.code}
                onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })}
                placeholder="CSE"
                maxLength={10}
              />
            </FieldWrapper>
            <FieldWrapper label="HoD Name">
              <TextInput
                value={form.hod_name}
                onChange={(e) => setForm({ ...form, hod_name: e.target.value })}
                placeholder="Dr. Jane Doe"
              />
            </FieldWrapper>
            <FieldWrapper label="Established Year">
              <TextInput
                type="number"
                value={form.established ?? ""}
                onChange={(e) => setForm({ ...form, established: e.target.value ? Number(e.target.value) : undefined })}
                placeholder="2005"
              />
            </FieldWrapper>
            <FieldWrapper label="Annual Intake">
              <TextInput
                type="number"
                value={form.intake ?? ""}
                onChange={(e) => setForm({ ...form, intake: e.target.value ? Number(e.target.value) : undefined })}
                placeholder="60"
              />
            </FieldWrapper>
            <FieldWrapper label="Description" className="col-span-2">
              <TextInput
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                placeholder="Short description"
              />
            </FieldWrapper>
            <div className="col-span-2 flex items-center justify-between border border-[var(--border)] rounded-xl p-3">
              <Checkbox
                label="NBA Accredited"
                checked={!!form.nba_accredited}
                onChange={(checked) => setForm({ ...form, nba_accredited: checked })}
              />
              {form.nba_accredited && (
                <div className="flex items-center gap-2">
                  <span className="text-xs text-[var(--muted-foreground)]">Valid till</span>
                  <TextInput
                    type="date"
                    value={form.nba_valid_till}
                    onChange={(e) => setForm({ ...form, nba_valid_till: e.target.value })}
                    className="!w-auto"
                  />
                </div>
              )}
            </div>
          </div>
          <FormActions onCancel={() => setModalOpen(false)} loading={saving} submitLabel={editing ? "Save Changes" : "Create Department"} />
        </form>
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        title="Delete department?"
        message={`This will permanently remove "${deleteTarget?.name}". This action cannot be undone.`}
        confirmLabel="Delete"
        loading={deleting}
        onConfirm={handleDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
}
