"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import {
  Upload, Search, Filter, FileText, CheckCircle2, XCircle, Trash2,
  Sparkles, Clock, File as FileIcon, Eye,
} from "lucide-react";
import PageHeader from "@/components/ui/PageHeader";
import MiniStat from "@/components/ui/MiniStat";
import Modal from "@/components/ui/Modal";
import ConfirmDialog from "@/components/ui/ConfirmDialog";
import Pagination from "@/components/ui/Pagination";
import StatusBadge from "@/components/ui/StatusBadge";
import DocumentPreviewModal from "@/components/documents/DocumentPreviewModal";
import { LoadingState, ErrorState, EmptyState, InlineError } from "@/components/ui/DataState";
import { FieldWrapper, TextInput, TextArea, Select, FormActions } from "@/components/ui/FormField";
import { useToast } from "@/components/ui/Toast";
import { useAuth } from "@/context/AuthContext";
import { documentsApi, departmentsApi, aiAnalysisApi, DocumentUploadInput } from "@/lib/api";
import { AppDocument, Department, DocumentStats, DocStatus, CriterionType } from "@/lib/api/types";
import { getErrorMessage, formatFileSize, formatDate } from "@/lib/utils";


export default function DocumentsPage() {
  const { user } = useAuth();
  const { showToast } = useToast();
  const canReview = ["admin", "principal", "iqac_coordinator", "hod"].includes(user?.role || "");

  const [documents, setDocuments] = useState<AppDocument[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [stats, setStats] = useState<DocumentStats | null>(null);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [page, setPage] = useState(1);
  const limit = 10;

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<DocStatus | "">("");
  const [criterionFilter, setCriterionFilter] = useState<CriterionType | "">("");
  const [showFilters, setShowFilters] = useState(false);

  const [uploadOpen, setUploadOpen] = useState(false);
  const [uploadForm, setUploadForm] = useState<Partial<DocumentUploadInput>>({});
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [detailTarget, setDetailTarget] = useState<AppDocument | null>(null);
  const [reviewNote, setReviewNote] = useState("");
  const [reviewSaving, setReviewSaving] = useState(false);

  const [deleteTarget, setDeleteTarget] = useState<AppDocument | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [mappingId, setMappingId] = useState<string | null>(null);

  const [previewTarget, setPreviewTarget] = useState<AppDocument | null>(null);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewLoadingId, setPreviewLoadingId] = useState<string | null>(null);

  useEffect(() => {
    departmentsApi.list().then((r) => setDepartments(r.data)).catch(() => {});
    documentsApi.stats().then(setStats).catch(() => {});
  }, []);

  const load = useCallback(() => {
    setLoading(true);
    setError(null);
    documentsApi
      .list({
        page,
        limit,
        search: search || undefined,
        status: statusFilter || undefined,
        criterion_type: criterionFilter || undefined,
      })
      .then((r) => {
        setDocuments(r.data);
        setTotal(r.total);
        setTotalPages(r.totalPages);
      })
      .catch((err) => setError(getErrorMessage(err, "Could not load documents.")))
      .finally(() => setLoading(false));
  }, [page, search, statusFilter, criterionFilter]);

  useEffect(() => {
    const t = setTimeout(load, 250);
    return () => clearTimeout(t);
  }, [load]);

  useEffect(() => setPage(1), [search, statusFilter, criterionFilter]);

  const refreshStats = () => documentsApi.stats().then(setStats).catch(() => {});

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    setUploadError(null);
    if (!file) {
      setUploadError("Please select a file to upload.");
      return;
    }
    if (!uploadForm.title) {
      setUploadError("Please provide a title.");
      return;
    }
    setUploading(true);
    try {
      await documentsApi.upload({ file, title: uploadForm.title!, ...uploadForm });
      showToast("Document uploaded successfully.");
      setUploadOpen(false);
      setUploadForm({});
      setFile(null);
      load();
      refreshStats();
    } catch (err) {
      setUploadError(getErrorMessage(err, "Upload failed."));
    } finally {
      setUploading(false);
    }
  };

  const openDetail = (d: AppDocument) => {
    setDetailTarget(d);
    setReviewNote("");
  };

  const handleApprove = async () => {
    if (!detailTarget) return;
    setReviewSaving(true);
    try {
      await documentsApi.approve(detailTarget.id, reviewNote || undefined);
      showToast("Document approved.");
      setDetailTarget(null);
      load();
      refreshStats();
    } catch (err) {
      showToast(getErrorMessage(err, "Could not approve document."), "error");
    } finally {
      setReviewSaving(false);
    }
  };

  const handleReject = async () => {
    if (!detailTarget) return;
    setReviewSaving(true);
    try {
      await documentsApi.reject(detailTarget.id, reviewNote || undefined);
      showToast("Document rejected.");
      setDetailTarget(null);
      load();
      refreshStats();
    } catch (err) {
      showToast(getErrorMessage(err, "Could not reject document."), "error");
    } finally {
      setReviewSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await documentsApi.remove(deleteTarget.id);
      showToast("Document deleted.");
      setDeleteTarget(null);
      load();
      refreshStats();
    } catch (err) {
      showToast(getErrorMessage(err, "Could not delete document."), "error");
    } finally {
      setDeleting(false);
    }
  };

  const handleAiMap = async (d: AppDocument) => {
    setMappingId(d.id);
    try {
      await aiAnalysisApi.mapDocument(d.id);
      showToast("AI mapping started. Check AI Evidence Search for results.");
    } catch (err) {
      showToast(getErrorMessage(err, "Could not start AI mapping."), "error");
    } finally {
      setMappingId(null);
    }
  };

  const openPreview = async (d: AppDocument) => {
    setPreviewLoadingId(d.id);
    try {
      // List rows don't include `file_path`; fetch the full record so the
      // preview modal has what it needs to build the file URL.
      const full = await documentsApi.get(d.id);
      setPreviewTarget(full);
      setPreviewOpen(true);
    } catch (err) {
      showToast(getErrorMessage(err, "Could not load document preview."), "error");
    } finally {
      setPreviewLoadingId(null);
    }
  };

  const closePreview = () => {
    setPreviewOpen(false);
  };

  return (
    <div className="max-w-7xl mx-auto">
      <PageHeader
        title="Documents"
        subtitle="Upload, review, and map evidence to accreditation criteria"
        actions={
          <button
            onClick={() => setUploadOpen(true)}
            className="inline-flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold px-4 py-2.5 rounded-xl transition shadow-lg shadow-blue-600/20"
          >
            <Upload className="w-4 h-4" /> Upload Document
          </button>
        }
      />

      {stats && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <MiniStat label="Total Documents" value={stats.total} icon={FileText} color="blue" />
          <MiniStat label="Pending Review" value={stats.pending} icon={Clock} color="amber" />
          <MiniStat label="Approved" value={stats.approved} icon={CheckCircle2} color="emerald" />
          <MiniStat label="AI Mapped" value={stats.ai_mapped} icon={Sparkles} color="indigo" />
        </div>
      )}

      <div className="bg-[var(--card)] border border-[var(--border)] rounded-2xl overflow-hidden">
        <div className="p-4 border-b border-[var(--border)] flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--muted-foreground)]" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search documents…"
              className="w-full pl-9 pr-3 py-2 text-sm rounded-xl border border-[var(--border)] bg-[var(--muted)] text-[var(--foreground)] placeholder:text-[var(--muted-foreground)] focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <button
            onClick={() => setShowFilters((v) => !v)}
            className="inline-flex items-center gap-1.5 text-xs font-medium px-3 py-2 rounded-xl border border-[var(--border)] text-[var(--foreground)] hover:bg-[var(--muted)] transition"
          >
            <Filter className="w-3.5 h-3.5" /> Filters
          </button>
          {showFilters && (
            <>
              <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value as DocStatus | "")} className="!w-auto">
                <option value="">All Statuses</option>
                <option value="draft">Draft</option>
                <option value="pending">Pending</option>
                <option value="approved">Approved</option>
                <option value="rejected">Rejected</option>
                <option value="archived">Archived</option>
              </Select>
              <Select value={criterionFilter} onChange={(e) => setCriterionFilter(e.target.value as CriterionType | "")} className="!w-auto">
                <option value="">All Criteria</option>
                <option value="naac">NAAC</option>
                <option value="nba">NBA</option>
                <option value="obe">OBE</option>
                <option value="iqac">IQAC</option>
              </Select>
            </>
          )}
        </div>

        {loading ? (
          <LoadingState label="Loading documents…" />
        ) : error ? (
          <ErrorState message={error} onRetry={load} />
        ) : documents.length === 0 ? (
          <EmptyState title="No documents found" message="Upload your first document to get started." icon={FileText} />
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-[var(--border)] text-left">
                    <th className="px-4 py-3 text-[11px] font-semibold text-[var(--muted-foreground)] uppercase">Document</th>
                    <th className="px-4 py-3 text-[11px] font-semibold text-[var(--muted-foreground)] uppercase">Criterion</th>
                    <th className="px-4 py-3 text-[11px] font-semibold text-[var(--muted-foreground)] uppercase">Status</th>
                    <th className="px-4 py-3 text-[11px] font-semibold text-[var(--muted-foreground)] uppercase">Uploaded By</th>
                    <th className="px-4 py-3 text-[11px] font-semibold text-[var(--muted-foreground)] uppercase">Date</th>
                    <th className="px-4 py-3 text-[11px] font-semibold text-[var(--muted-foreground)] uppercase text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[var(--border)]">
                  {documents.map((d) => (
                    <tr key={d.id} className="hover:bg-[var(--muted)] transition cursor-pointer" onClick={() => openDetail(d)}>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-lg bg-blue-50 dark:bg-blue-950/40 flex items-center justify-center shrink-0">
                            <FileIcon className="w-4 h-4 text-blue-500" />
                          </div>
                          <div className="min-w-0">
                            <div className="font-medium text-[var(--foreground)] truncate max-w-[220px]">{d.title}</div>
                            <div className="text-[11px] text-[var(--muted-foreground)]">{formatFileSize(d.file_size)}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-[var(--foreground)] uppercase text-xs">
                        {d.criterion_type ? `${d.criterion_type}${d.criterion_ref ? ` · ${d.criterion_ref}` : ""}` : "—"}
                      </td>
                      <td className="px-4 py-3"><StatusBadge status={d.status} /></td>
                      <td className="px-4 py-3 text-[var(--foreground)]">{d.uploaded_by_name || "—"}</td>
                      <td className="px-4 py-3 text-[var(--muted-foreground)] text-xs">{formatDate(d.created_at)}</td>
                      <td className="px-4 py-3" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => openPreview(d)}
                            disabled={previewLoadingId === d.id}
                            className="p-1.5 rounded-lg hover:bg-blue-50 dark:hover:bg-blue-950/30 text-[var(--muted-foreground)] hover:text-blue-600 disabled:opacity-50"
                            title="Preview"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          {!d.ai_mapped && (
                            <button
                              onClick={() => handleAiMap(d)}
                              disabled={mappingId === d.id}
                              className="p-1.5 rounded-lg hover:bg-indigo-50 dark:hover:bg-indigo-950/30 text-[var(--muted-foreground)] hover:text-indigo-600 disabled:opacity-50"
                              title="Run AI mapping"
                            >
                              <Sparkles className="w-3.5 h-3.5" />
                            </button>
                          )}
                          {(canReview || d.uploaded_by === user?.id) && (
                            <button onClick={() => setDeleteTarget(d)} className="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-950/30 text-[var(--muted-foreground)] hover:text-red-600">
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="px-4">
              <Pagination page={page} totalPages={totalPages} total={total} limit={limit} onPageChange={setPage} />
            </div>
          </>
        )}
      </div>

      {/* Upload modal */}
      <Modal open={uploadOpen} onClose={() => setUploadOpen(false)} title="Upload Document" maxWidth="max-w-lg">
        <form onSubmit={handleUpload} className="space-y-4">
          {uploadError && <InlineError message={uploadError} />}
          <FieldWrapper label="File" required>
            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-[var(--border)] rounded-xl p-6 text-center cursor-pointer hover:border-blue-400 transition"
            >
              <input
                ref={fileInputRef}
                type="file"
                className="hidden"
                onChange={(e) => setFile(e.target.files?.[0] || null)}
              />
              <Upload className="w-6 h-6 mx-auto text-[var(--muted-foreground)] mb-2" />
              <p className="text-xs text-[var(--foreground)] font-medium">{file ? file.name : "Click to select a file"}</p>
              {file && <p className="text-[10px] text-[var(--muted-foreground)] mt-1">{formatFileSize(file.size)}</p>}
            </div>
          </FieldWrapper>
          <FieldWrapper label="Title" required>
            <TextInput required value={uploadForm.title || ""} onChange={(e) => setUploadForm({ ...uploadForm, title: e.target.value })} />
          </FieldWrapper>
          <FieldWrapper label="Description">
            <TextArea value={uploadForm.description || ""} onChange={(e) => setUploadForm({ ...uploadForm, description: e.target.value })} />
          </FieldWrapper>
          <div className="grid grid-cols-2 gap-3">
            <FieldWrapper label="Department">
              <Select value={uploadForm.department_id || ""} onChange={(e) => setUploadForm({ ...uploadForm, department_id: e.target.value })}>
                <option value="">Institution-wide</option>
                {departments.map((d) => (
                  <option key={d.id} value={d.id}>{d.name}</option>
                ))}
              </Select>
            </FieldWrapper>
            <FieldWrapper label="Criterion Type">
              <Select value={uploadForm.criterion_type || ""} onChange={(e) => setUploadForm({ ...uploadForm, criterion_type: e.target.value as CriterionType })}>
                <option value="">Unmapped</option>
                <option value="naac">NAAC</option>
                <option value="nba">NBA</option>
                <option value="obe">OBE</option>
                <option value="iqac">IQAC</option>
              </Select>
            </FieldWrapper>
            <FieldWrapper label="Criterion Reference" hint="e.g. 1.1.2">
              <TextInput value={uploadForm.criterion_ref || ""} onChange={(e) => setUploadForm({ ...uploadForm, criterion_ref: e.target.value })} />
            </FieldWrapper>
            <FieldWrapper label="Academic Year" hint="e.g. 2024-25">
              <TextInput value={uploadForm.academic_year || ""} onChange={(e) => setUploadForm({ ...uploadForm, academic_year: e.target.value })} />
            </FieldWrapper>
          </div>
          <FormActions onCancel={() => setUploadOpen(false)} loading={uploading} submitLabel="Upload" />
        </form>
      </Modal>

      {/* Detail / review modal */}
      <Modal open={!!detailTarget} onClose={() => setDetailTarget(null)} title={detailTarget?.title || ""} subtitle="Document details" maxWidth="max-w-lg">
        {detailTarget && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div><span className="text-[var(--muted-foreground)]">Status</span><div className="mt-1"><StatusBadge status={detailTarget.status} /></div></div>
              <div><span className="text-[var(--muted-foreground)]">Uploaded By</span><div className="text-[var(--foreground)] font-medium mt-1">{detailTarget.uploaded_by_name}</div></div>
              <div><span className="text-[var(--muted-foreground)]">File Size</span><div className="text-[var(--foreground)] font-medium mt-1">{formatFileSize(detailTarget.file_size)}</div></div>
              <div><span className="text-[var(--muted-foreground)]">Uploaded On</span><div className="text-[var(--foreground)] font-medium mt-1">{formatDate(detailTarget.created_at)}</div></div>
              {detailTarget.criterion_type && (
                <div className="col-span-2">
                  <span className="text-[var(--muted-foreground)]">Criterion</span>
                  <div className="text-[var(--foreground)] font-medium mt-1 uppercase">{detailTarget.criterion_type} {detailTarget.criterion_ref}</div>
                </div>
              )}
            </div>
            {detailTarget.description && (
              <div>
                <span className="text-xs text-[var(--muted-foreground)]">Description</span>
                <p className="text-sm text-[var(--foreground)] mt-1">{detailTarget.description}</p>
              </div>
            )}
            {detailTarget.rejection_note && (
              <InlineError message={`Rejection note: ${detailTarget.rejection_note}`} />
            )}
            {canReview && detailTarget.status === "pending" && (
              <div className="space-y-3 pt-3 border-t border-[var(--border)]">
                <FieldWrapper label="Review Note (optional)">
                  <TextArea value={reviewNote} onChange={(e) => setReviewNote(e.target.value)} placeholder="Add a note for the uploader…" />
                </FieldWrapper>
                <div className="flex justify-end gap-2">
                  <button
                    onClick={handleReject}
                    disabled={reviewSaving}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold text-red-600 bg-red-50 dark:bg-red-950/40 hover:bg-red-100 dark:hover:bg-red-900/40 transition disabled:opacity-50"
                  >
                    <XCircle className="w-3.5 h-3.5" /> Reject
                  </button>
                  <button
                    onClick={handleApprove}
                    disabled={reviewSaving}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 transition disabled:opacity-50"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" /> Approve
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        title="Delete document?"
        message={`This will permanently remove "${deleteTarget?.title}".`}
        confirmLabel="Delete"
        loading={deleting}
        onConfirm={handleDelete}
        onCancel={() => setDeleteTarget(null)}
      />

      <DocumentPreviewModal document={previewTarget} open={previewOpen} onClose={closePreview} />
    </div>
  );
}
