"use client";

import { useCallback, useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Plus, Award, Pencil, Trash2, TrendingUp, Target, CheckCircle2, AlertTriangle } from "lucide-react";
import PageHeader from "@/components/ui/PageHeader";
import MiniStat from "@/components/ui/MiniStat";
import Modal from "@/components/ui/Modal";
import ConfirmDialog from "@/components/ui/ConfirmDialog";
import { LoadingState, ErrorState, EmptyState, InlineError } from "@/components/ui/DataState";
import { FieldWrapper, TextInput, TextArea, FormActions } from "@/components/ui/FormField";
import { useToast } from "@/components/ui/Toast";
import { useAuth } from "@/context/AuthContext";
import { criteriaApi, NaacInput } from "@/lib/api";
import { NaacCriteria, NaacOverview } from "@/lib/api/types";
import { cn, getErrorMessage } from "@/lib/utils";

const emptyForm: NaacInput = {
  criterion_no: "",
  criterion_name: "",
  sub_criteria: "",
  description: "",
  max_score: 100,
  current_score: 0,
  cycle_year: "",
};

function getColor(val: number) {
  if (val >= 80) return "bg-emerald-500";
  if (val >= 60) return "bg-blue-500";
  if (val >= 40) return "bg-amber-500";
  return "bg-red-500";
}

export default function NaacPage() {
  const { user } = useAuth();
  const { showToast } = useToast();
  const canManage = ["admin", "principal", "iqac_coordinator"].includes(user?.role || "");

  const [overview, setOverview] = useState<NaacOverview | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<NaacCriteria | null>(null);
  const [form, setForm] = useState<NaacInput>(emptyForm);
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const [deleteTarget, setDeleteTarget] = useState<NaacCriteria | null>(null);
  const [deleting, setDeleting] = useState(false);

  const load = useCallback(() => {
    setLoading(true);
    setError(null);
    criteriaApi
      .naacOverview()
      .then(setOverview)
      .catch((err) => setError(getErrorMessage(err, "Could not load NAAC criteria.")))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => { load(); }, [load]);

  const openCreate = () => {
    setEditing(null);
    setForm(emptyForm);
    setFormError(null);
    setModalOpen(true);
  };

  const openEdit = (c: NaacCriteria) => {
    setEditing(c);
    setForm({
      criterion_no: c.criterion_no,
      criterion_name: c.criterion_name,
      sub_criteria: c.sub_criteria || "",
      description: c.description || "",
      max_score: c.max_score,
      current_score: c.current_score,
      cycle_year: c.cycle_year || "",
      due_date: c.due_date ? c.due_date.slice(0, 10) : undefined,
      notes: c.notes || "",
    });
    setFormError(null);
    setModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setSaving(true);
    try {
      const payload = {
        ...form,
        max_score: Number(form.max_score),
        current_score: Number(form.current_score),
      };
      if (editing) {
        await criteriaApi.updateNaac(editing.id, payload);
        showToast("Criterion updated.");
      } else {
        await criteriaApi.createNaac(payload);
        showToast("Criterion created.");
      }
      setModalOpen(false);
      load();
    } catch (err) {
      setFormError(getErrorMessage(err, "Could not save criterion."));
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await criteriaApi.removeNaac(deleteTarget.id);
      showToast("Criterion removed.");
      setDeleteTarget(null);
      load();
    } catch (err) {
      showToast(getErrorMessage(err, "Could not delete criterion."), "error");
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto">
      <PageHeader
        title="NAAC Accreditation"
        subtitle="Track criteria completion for your NAAC cycle"
        actions={
          canManage && (
            <button
              onClick={openCreate}
              className="inline-flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold px-4 py-2.5 rounded-xl transition shadow-lg shadow-blue-600/20"
            >
              <Plus className="w-4 h-4" /> Add Criterion
            </button>
          )
        }
      />

      {loading ? (
        <LoadingState label="Loading NAAC data…" />
      ) : error ? (
        <ErrorState message={error} onRetry={load} />
      ) : overview ? (
        <>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <MiniStat label="Overall Completion" value={`${Math.round(overview.aggregate.overall_completion)}%`} icon={TrendingUp} color="blue" />
            <MiniStat label="Total Criteria" value={overview.aggregate.total_criteria} icon={Target} color="indigo" />
            <MiniStat label="Above 80%" value={overview.aggregate.criteria_above_80} icon={CheckCircle2} color="emerald" />
            <MiniStat label="Below 50%" value={overview.aggregate.criteria_below_50} icon={AlertTriangle} color="amber" />
          </div>

          {overview.criteria.length === 0 ? (
            <div className="bg-[var(--card)] border border-[var(--border)] rounded-2xl">
              <EmptyState title="No NAAC criteria yet" message="Add criteria to start tracking your accreditation progress." icon={Award} />
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {overview.criteria.map((c, i) => (
                <motion.div
                  key={c.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.03 }}
                  className="bg-[var(--card)] border border-[var(--border)] rounded-2xl p-4 group"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="text-[10px] font-bold w-8 h-6 bg-[var(--muted)] rounded text-[var(--muted-foreground)] flex items-center justify-center shrink-0">
                        {c.criterion_no}
                      </span>
                      <span className="text-sm font-semibold text-[var(--foreground)] truncate">{c.criterion_name}</span>
                    </div>
                    {canManage && (
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition shrink-0">
                        <button onClick={() => openEdit(c)} className="p-1.5 rounded-lg hover:bg-[var(--muted)] text-[var(--muted-foreground)] hover:text-[var(--foreground)]">
                          <Pencil className="w-3.5 h-3.5" />
                        </button>
                        <button onClick={() => setDeleteTarget(c)} className="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-950/30 text-[var(--muted-foreground)] hover:text-red-600">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}
                  </div>
                  {c.description && <p className="text-xs text-[var(--muted-foreground)] mb-3 line-clamp-2">{c.description}</p>}
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[11px] text-[var(--muted-foreground)]">
                      {c.current_score} / {c.max_score} pts {c.responsible_name && `· ${c.responsible_name}`}
                    </span>
                    <span className="text-xs font-bold text-[var(--foreground)]">{Math.round(c.completion_pct)}%</span>
                  </div>
                  <div className="h-2 bg-[var(--muted)] rounded-full overflow-hidden">
                    <div className={cn("h-full rounded-full", getColor(c.completion_pct))} style={{ width: `${c.completion_pct}%` }} />
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </>
      ) : null}

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? "Edit Criterion" : "Add NAAC Criterion"} maxWidth="max-w-lg">
        <form onSubmit={handleSubmit} className="space-y-4">
          {formError && <InlineError message={formError} />}
          <div className="grid grid-cols-2 gap-3">
            <FieldWrapper label="Criterion No." required>
              <TextInput required value={form.criterion_no} onChange={(e) => setForm({ ...form, criterion_no: e.target.value })} placeholder="1.1.2" />
            </FieldWrapper>
            <FieldWrapper label="Cycle Year">
              <TextInput value={form.cycle_year} onChange={(e) => setForm({ ...form, cycle_year: e.target.value })} placeholder="2024-25" />
            </FieldWrapper>
            <FieldWrapper label="Criterion Name" required className="col-span-2">
              <TextInput required value={form.criterion_name} onChange={(e) => setForm({ ...form, criterion_name: e.target.value })} />
            </FieldWrapper>
            <FieldWrapper label="Description" className="col-span-2">
              <TextArea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
            </FieldWrapper>
            <FieldWrapper label="Max Score">
              <TextInput type="number" value={form.max_score} onChange={(e) => setForm({ ...form, max_score: Number(e.target.value) })} />
            </FieldWrapper>
            <FieldWrapper label="Current Score">
              <TextInput type="number" value={form.current_score} onChange={(e) => setForm({ ...form, current_score: Number(e.target.value) })} />
            </FieldWrapper>
          </div>
          <FormActions onCancel={() => setModalOpen(false)} loading={saving} submitLabel={editing ? "Save Changes" : "Add Criterion"} />
        </form>
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        title="Delete criterion?"
        message={`This will permanently remove criterion "${deleteTarget?.criterion_no}".`}
        confirmLabel="Delete"
        loading={deleting}
        onConfirm={handleDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
}
