"use client";

import { Suspense, useCallback, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { motion } from "framer-motion";
import { Sparkles, Search, FileText, CheckCircle2, XCircle, Loader2, Clock, RefreshCw, Target } from "lucide-react";
import PageHeader from "@/components/ui/PageHeader";
import MiniStat from "@/components/ui/MiniStat";
import StatusBadge from "@/components/ui/StatusBadge";
import { LoadingState, ErrorState, EmptyState } from "@/components/ui/DataState";
import { useToast } from "@/components/ui/Toast";
import { aiAnalysisApi, documentsApi } from "@/lib/api";
import { AIAnalysis, AIAnalysisStatsSummary, AppDocument } from "@/lib/api/types";
import { getErrorMessage, timeAgo } from "@/lib/utils";

export default function AiSearchPage() {
  return (
    <Suspense fallback={<LoadingState label="Loading AI Evidence Search…" />}>
      <AiSearchContent />
    </Suspense>
  );
}

function AiSearchContent() {
  const { showToast } = useToast();
  const searchParams = useSearchParams();
  const initialQuery = searchParams.get("q") || "";

  const [stats, setStats] = useState<AIAnalysisStatsSummary | null>(null);
  const [jobs, setJobs] = useState<AIAnalysis[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [query, setQuery] = useState(initialQuery);
  const [searchResults, setSearchResults] = useState<AppDocument[] | null>(null);
  const [searching, setSearching] = useState(false);
  const [criterionType, setCriterionType] = useState<"naac" | "nba">("naac");
  const [bulkRunning, setBulkRunning] = useState(false);

  const load = useCallback(() => {
    setLoading(true);
    setError(null);
    Promise.all([aiAnalysisApi.stats(), aiAnalysisApi.list({ limit: 10 })])
      .then(([s, j]) => {
        setStats(s);
        setJobs(j.data);
      })
      .catch((err) => setError(getErrorMessage(err, "Could not load AI analysis data.")))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => { load(); }, [load]);

  const runSearch = useCallback((q: string) => {
    if (!q.trim()) {
      setSearchResults(null);
      return;
    }
    setSearching(true);
    documentsApi
      .search(q, undefined)
      .then(setSearchResults)
      .catch(() => setSearchResults([]))
      .finally(() => setSearching(false));
  }, []);

  useEffect(() => {
    if (initialQuery) runSearch(initialQuery);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleBulkSearch = async () => {
    setBulkRunning(true);
    try {
      await aiAnalysisApi.bulkSearch(criterionType);
      showToast(`AI evidence search for ${criterionType.toUpperCase()} completed.`);
      load();
    } catch (err) {
      showToast(getErrorMessage(err, "Could not run AI evidence search."), "error");
    } finally {
      setBulkRunning(false);
    }
  };

  const statusIcon: Record<string, React.ReactNode> = {
    completed: <CheckCircle2 className="w-4 h-4 text-emerald-500" />,
    failed: <XCircle className="w-4 h-4 text-red-500" />,
    running: <Loader2 className="w-4 h-4 text-blue-500 animate-spin" />,
    pending: <Clock className="w-4 h-4 text-amber-500" />,
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <PageHeader title="AI Evidence Search" subtitle="Use AI to map documents to NAAC/NBA criteria and search evidence" />

      {/* Search bar */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-[var(--card)] border border-[var(--border)] rounded-2xl p-5">
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--muted-foreground)]" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && runSearch(query)}
            placeholder="Search evidence documents by keyword…"
            className="w-full pl-10 pr-24 py-3 text-sm rounded-xl border border-[var(--border)] bg-[var(--muted)] text-[var(--foreground)] placeholder:text-[var(--muted-foreground)] focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <button
            onClick={() => runSearch(query)}
            className="absolute right-2 top-1/2 -translate-y-1/2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold px-3.5 py-1.5 rounded-lg transition"
          >
            Search
          </button>
        </div>

        {searching ? (
          <LoadingState label="Searching…" />
        ) : searchResults !== null ? (
          searchResults.length === 0 ? (
            <EmptyState title="No matching documents" message="Try a different search term." icon={FileText} />
          ) : (
            <div className="mt-4 divide-y divide-[var(--border)]">
              {searchResults.map((d) => (
                <div key={d.id} className="py-3 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <FileText className="w-4 h-4 text-blue-500 shrink-0" />
                    <div className="min-w-0">
                      <div className="text-sm font-medium text-[var(--foreground)] truncate">{d.title}</div>
                      <div className="text-[11px] text-[var(--muted-foreground)]">
                        {d.criterion_type ? `${d.criterion_type.toUpperCase()} ${d.criterion_ref || ""}` : "Unmapped"}
                      </div>
                    </div>
                  </div>
                  <StatusBadge status={d.status} />
                </div>
              ))}
            </div>
          )
        ) : null}
      </motion.div>

      {/* Bulk AI mapping */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.05 }}
        className="relative overflow-hidden bg-gradient-to-r from-indigo-600 to-blue-600 rounded-2xl p-5 text-white"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Sparkles className="w-6 h-6 shrink-0" />
            <div>
              <p className="font-semibold text-sm">Bulk Evidence Mapping</p>
              <p className="text-xs opacity-80 mt-0.5">Scan unmapped documents and auto-suggest criteria matches.</p>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <select
              value={criterionType}
              onChange={(e) => setCriterionType(e.target.value as "naac" | "nba")}
              className="text-xs bg-white/15 border border-white/25 rounded-lg px-2.5 py-2 focus:outline-none"
            >
              <option value="naac" className="text-black">NAAC</option>
              <option value="nba" className="text-black">NBA</option>
            </select>
            <button
              onClick={handleBulkSearch}
              disabled={bulkRunning}
              className="inline-flex items-center gap-1.5 bg-white text-blue-600 font-semibold text-xs px-4 py-2 rounded-xl hover:bg-blue-50 transition disabled:opacity-60"
            >
              {bulkRunning ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
              Run Evidence Search
            </button>
          </div>
        </div>
      </motion.div>

      {loading ? (
        <LoadingState label="Loading AI analysis history…" />
      ) : error ? (
        <ErrorState message={error} onRetry={load} />
      ) : (
        <>
          {stats && (
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <MiniStat label="Total Jobs" value={stats.total_jobs} icon={Sparkles} color="blue" />
              <MiniStat label="Completed" value={stats.completed} icon={CheckCircle2} color="emerald" />
              <MiniStat label="Documents Mapped" value={stats.documents_ai_mapped} icon={Target} color="indigo" />
              <MiniStat label="Unmapped" value={stats.documents_unmapped} icon={XCircle} color="amber" />
            </div>
          )}

          <div className="bg-[var(--card)] border border-[var(--border)] rounded-2xl overflow-hidden">
            <div className="p-4 border-b border-[var(--border)]">
              <h3 className="font-semibold text-[var(--foreground)] text-sm">Recent AI Jobs</h3>
            </div>
            {jobs.length === 0 ? (
              <EmptyState title="No AI jobs yet" message="Run an evidence search or map a document to see history here." icon={Sparkles} />
            ) : (
              <div className="divide-y divide-[var(--border)]">
                {jobs.map((j) => (
                  <div key={j.id} className="p-4 flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3 min-w-0">
                      <div className="mt-0.5 shrink-0">{statusIcon[j.status]}</div>
                      <div className="min-w-0">
                        <div className="text-sm font-medium text-[var(--foreground)] capitalize">
                          {j.analysis_type.replace("_", " ")} {j.document_title ? `· ${j.document_title}` : ""}
                        </div>
                        <div className="text-[11px] text-[var(--muted-foreground)] mt-0.5">
                          Triggered by {j.triggered_by_name || "system"} · {timeAgo(j.created_at)}
                          {j.confidence != null && ` · ${Math.round(j.confidence * 100)}% confidence`}
                        </div>
                        {j.result?.matched != null && (
                          <div className="text-[11px] text-[var(--muted-foreground)] mt-0.5">
                            Scanned {j.result.scanned} documents, matched {j.result.matched}
                          </div>
                        )}
                        {j.error_message && <div className="text-[11px] text-red-500 mt-0.5">{j.error_message}</div>}
                      </div>
                    </div>
                    <StatusBadge status={j.status} />
                  </div>
                ))}
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
