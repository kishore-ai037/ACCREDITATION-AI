"use client";

import { useCallback, useEffect, useState } from "react";
import { motion } from "framer-motion";
import { User, Lock, Users, Plus, Pencil, Trash2, Shield } from "lucide-react";
import PageHeader from "@/components/ui/PageHeader";
import Modal from "@/components/ui/Modal";
import ConfirmDialog from "@/components/ui/ConfirmDialog";
import Pagination from "@/components/ui/Pagination";
import StatusBadge from "@/components/ui/StatusBadge";
import { LoadingState, ErrorState, EmptyState, InlineError } from "@/components/ui/DataState";
import { FieldWrapper, TextInput, Select, FormActions } from "@/components/ui/FormField";
import { useToast } from "@/components/ui/Toast";
import { useAuth } from "@/context/AuthContext";
import { authApi, usersApi, departmentsApi, UserCreateInput, UserUpdateInput } from "@/lib/api";
import { ManagedUser, Department, BackendUserRole } from "@/lib/api/types";
import { getErrorMessage } from "@/lib/utils";

const roleLabels: Record<BackendUserRole, string> = {
  admin: "Administrator",
  principal: "Principal",
  iqac_coordinator: "IQAC Coordinator",
  hod: "Head of Department",
  faculty: "Faculty",
  student: "Student",
};

const emptyUserForm: UserCreateInput = { email: "", password: "", name: "", role: "faculty" };

export default function SettingsPage() {
  const { user, refreshProfile } = useAuth();
  const { showToast } = useToast();
  const isAdmin = user?.role === "admin";
  const [tab, setTab] = useState<"profile" | "security" | "users">("profile");

  // Profile
  const [profileForm, setProfileForm] = useState({ name: user?.name || "", designation: user?.designation || "" });
  const [profileSaving, setProfileSaving] = useState(false);

  // Password
  const [pwForm, setPwForm] = useState({ current: "", next: "", confirm: "" });
  const [pwError, setPwError] = useState<string | null>(null);
  const [pwSaving, setPwSaving] = useState(false);

  // Users (admin)
  const [users, setUsers] = useState<ManagedUser[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [page, setPage] = useState(1);
  const limit = 10;
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [userModal, setUserModal] = useState(false);
  const [editingUser, setEditingUser] = useState<ManagedUser | null>(null);
  const [userForm, setUserForm] = useState<UserCreateInput>(emptyUserForm);
  const [userFormError, setUserFormError] = useState<string | null>(null);
  const [userSaving, setUserSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<ManagedUser | null>(null);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    if (isAdmin) departmentsApi.list().then((r) => setDepartments(r.data)).catch(() => {});
  }, [isAdmin]);

  const loadUsers = useCallback(() => {
    if (!isAdmin) return;
    setLoading(true);
    setError(null);
    usersApi
      .list({ page, limit })
      .then((r) => {
        setUsers(r.data);
        setTotal(r.total);
        setTotalPages(r.totalPages);
      })
      .catch((err) => setError(getErrorMessage(err, "Could not load users.")))
      .finally(() => setLoading(false));
  }, [page, isAdmin]);

  useEffect(() => { if (tab === "users") loadUsers(); }, [tab, loadUsers]);

  const handleProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setProfileSaving(true);
    try {
      await usersApi.update(user.id, { name: profileForm.name, designation: profileForm.designation });
      await refreshProfile();
      showToast("Profile updated successfully.");
    } catch (err) {
      showToast(getErrorMessage(err, "Could not update profile."), "error");
    } finally {
      setProfileSaving(false);
    }
  };

  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setPwError(null);
    if (pwForm.next !== pwForm.confirm) {
      setPwError("New password and confirmation do not match.");
      return;
    }
    setPwSaving(true);
    try {
      await authApi.changePassword(pwForm.current, pwForm.next);
      showToast("Password changed successfully.");
      setPwForm({ current: "", next: "", confirm: "" });
    } catch (err) {
      setPwError(getErrorMessage(err, "Could not change password."));
    } finally {
      setPwSaving(false);
    }
  };

  const openCreateUser = () => {
    setEditingUser(null);
    setUserForm(emptyUserForm);
    setUserFormError(null);
    setUserModal(true);
  };

  const openEditUser = (u: ManagedUser) => {
    setEditingUser(u);
    setUserForm({
      email: u.email,
      password: "",
      name: u.name,
      role: u.role,
      designation: u.designation || "",
      department_id: u.department_id || "",
    });
    setUserFormError(null);
    setUserModal(true);
  };

  const handleUserSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setUserFormError(null);
    setUserSaving(true);
    try {
      if (editingUser) {
        const payload: UserUpdateInput = {
          name: userForm.name,
          role: userForm.role,
          designation: userForm.designation,
          department_id: userForm.department_id,
        };
        await usersApi.update(editingUser.id, payload);
        showToast("User updated.");
      } else {
        await usersApi.create(userForm);
        showToast("User created.");
      }
      setUserModal(false);
      loadUsers();
    } catch (err) {
      setUserFormError(getErrorMessage(err, "Could not save user."));
    } finally {
      setUserSaving(false);
    }
  };

  const handleToggleActive = async (u: ManagedUser) => {
    try {
      const updated = await usersApi.update(u.id, { is_active: !u.is_active });
      setUsers((list) => list.map((x) => (x.id === u.id ? updated : x)));
    } catch (err) {
      showToast(getErrorMessage(err, "Could not update user status."), "error");
    }
  };

  const handleDeleteUser = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await usersApi.remove(deleteTarget.id);
      showToast("User removed.");
      setDeleteTarget(null);
      loadUsers();
    } catch (err) {
      showToast(getErrorMessage(err, "Could not delete user."), "error");
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto">
      <PageHeader title="Settings" subtitle="Manage your profile, security, and platform users" />

      <div className="flex gap-2 mb-6 border-b border-[var(--border)]">
        {([
          { key: "profile", label: "Profile", icon: User },
          { key: "security", label: "Security", icon: Lock },
          ...(isAdmin ? [{ key: "users" as const, label: "Users", icon: Users }] : []),
        ] as const).map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`flex items-center gap-1.5 px-4 py-2.5 text-sm font-medium border-b-2 transition ${
              tab === t.key ? "border-blue-600 text-blue-600" : "border-transparent text-[var(--muted-foreground)] hover:text-[var(--foreground)]"
            }`}
          >
            <t.icon className="w-3.5 h-3.5" /> {t.label}
          </button>
        ))}
      </div>

      {tab === "profile" && (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="bg-[var(--card)] border border-[var(--border)] rounded-2xl p-6 max-w-lg">
          <form onSubmit={handleProfileSubmit} className="space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white font-bold text-lg mb-2">
              {user?.name?.split(" ").map((n) => n[0]).slice(0, 2).join("")}
            </div>
            <FieldWrapper label="Full Name">
              <TextInput value={profileForm.name} onChange={(e) => setProfileForm({ ...profileForm, name: e.target.value })} />
            </FieldWrapper>
            <FieldWrapper label="Designation">
              <TextInput value={profileForm.designation} onChange={(e) => setProfileForm({ ...profileForm, designation: e.target.value })} />
            </FieldWrapper>
            <FieldWrapper label="Email">
              <TextInput value={user?.email} disabled />
            </FieldWrapper>
            <FieldWrapper label="Role">
              <TextInput value={user?.role ? roleLabels[user.role as BackendUserRole] : ""} disabled />
            </FieldWrapper>
            <FormActions onCancel={() => setProfileForm({ name: user?.name || "", designation: user?.designation || "" })} loading={profileSaving} submitLabel="Save Profile" />
          </form>
        </motion.div>
      )}

      {tab === "security" && (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="bg-[var(--card)] border border-[var(--border)] rounded-2xl p-6 max-w-lg">
          <form onSubmit={handlePasswordSubmit} className="space-y-4">
            {pwError && <InlineError message={pwError} />}
            <FieldWrapper label="Current Password" required>
              <TextInput type="password" required value={pwForm.current} onChange={(e) => setPwForm({ ...pwForm, current: e.target.value })} />
            </FieldWrapper>
            <FieldWrapper label="New Password" required hint="At least 8 characters">
              <TextInput type="password" required minLength={8} value={pwForm.next} onChange={(e) => setPwForm({ ...pwForm, next: e.target.value })} />
            </FieldWrapper>
            <FieldWrapper label="Confirm New Password" required>
              <TextInput type="password" required value={pwForm.confirm} onChange={(e) => setPwForm({ ...pwForm, confirm: e.target.value })} />
            </FieldWrapper>
            <FormActions onCancel={() => setPwForm({ current: "", next: "", confirm: "" })} loading={pwSaving} submitLabel="Change Password" />
          </form>
        </motion.div>
      )}

      {tab === "users" && isAdmin && (
        <div className="bg-[var(--card)] border border-[var(--border)] rounded-2xl overflow-hidden">
          <div className="p-4 border-b border-[var(--border)] flex justify-end">
            <button
              onClick={openCreateUser}
              className="inline-flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold px-4 py-2.5 rounded-xl transition"
            >
              <Plus className="w-4 h-4" /> Add User
            </button>
          </div>
          {loading ? (
            <LoadingState label="Loading users…" />
          ) : error ? (
            <ErrorState message={error} onRetry={loadUsers} />
          ) : users.length === 0 ? (
            <EmptyState title="No users found" message="Add users to give them access to the platform." icon={Users} />
          ) : (
            <>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-[var(--border)] text-left">
                      <th className="px-4 py-3 text-[11px] font-semibold text-[var(--muted-foreground)] uppercase">User</th>
                      <th className="px-4 py-3 text-[11px] font-semibold text-[var(--muted-foreground)] uppercase">Role</th>
                      <th className="px-4 py-3 text-[11px] font-semibold text-[var(--muted-foreground)] uppercase">Department</th>
                      <th className="px-4 py-3 text-[11px] font-semibold text-[var(--muted-foreground)] uppercase">Status</th>
                      <th className="px-4 py-3 text-[11px] font-semibold text-[var(--muted-foreground)] uppercase text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[var(--border)]">
                    {users.map((u) => (
                      <tr key={u.id} className="hover:bg-[var(--muted)] transition">
                        <td className="px-4 py-3">
                          <div className="font-medium text-[var(--foreground)]">{u.name}</div>
                          <div className="text-[11px] text-[var(--muted-foreground)]">{u.email}</div>
                        </td>
                        <td className="px-4 py-3">
                          <span className="inline-flex items-center gap-1 text-xs text-[var(--foreground)]">
                            <Shield className="w-3 h-3 text-[var(--muted-foreground)]" /> {roleLabels[u.role]}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-[var(--foreground)]">{u.department || "—"}</td>
                        <td className="px-4 py-3">
                          <button onClick={() => handleToggleActive(u)}>
                            <StatusBadge status={u.is_active ? "active" : "inactive"} />
                          </button>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex items-center justify-end gap-1">
                            <button onClick={() => openEditUser(u)} className="p-1.5 rounded-lg hover:bg-[var(--muted)] text-[var(--muted-foreground)] hover:text-[var(--foreground)]">
                              <Pencil className="w-3.5 h-3.5" />
                            </button>
                            {u.id !== user?.id && (
                              <button onClick={() => setDeleteTarget(u)} className="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-950/30 text-[var(--muted-foreground)] hover:text-red-600">
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="px-4">
                <Pagination page={page} totalPages={totalPages} total={total} limit={limit} onPageChange={setPage} />
              </div>
            </>
          )}
        </div>
      )}

      <Modal open={userModal} onClose={() => setUserModal(false)} title={editingUser ? "Edit User" : "Add User"} maxWidth="max-w-lg">
        <form onSubmit={handleUserSubmit} className="space-y-4">
          {userFormError && <InlineError message={userFormError} />}
          <div className="grid grid-cols-2 gap-3">
            <FieldWrapper label="Full Name" required className="col-span-2">
              <TextInput required value={userForm.name} onChange={(e) => setUserForm({ ...userForm, name: e.target.value })} />
            </FieldWrapper>
            <FieldWrapper label="Email" required className="col-span-2">
              <TextInput type="email" required disabled={!!editingUser} value={userForm.email} onChange={(e) => setUserForm({ ...userForm, email: e.target.value })} />
            </FieldWrapper>
            {!editingUser && (
              <FieldWrapper label="Password" required hint="At least 8 characters" className="col-span-2">
                <TextInput type="password" required minLength={8} value={userForm.password} onChange={(e) => setUserForm({ ...userForm, password: e.target.value })} />
              </FieldWrapper>
            )}
            <FieldWrapper label="Role" required>
              <Select required value={userForm.role} onChange={(e) => setUserForm({ ...userForm, role: e.target.value as BackendUserRole })}>
                {Object.entries(roleLabels).map(([val, label]) => (
                  <option key={val} value={val}>{label}</option>
                ))}
              </Select>
            </FieldWrapper>
            <FieldWrapper label="Department">
              <Select value={userForm.department_id || ""} onChange={(e) => setUserForm({ ...userForm, department_id: e.target.value })}>
                <option value="">None</option>
                {departments.map((d) => (
                  <option key={d.id} value={d.id}>{d.name}</option>
                ))}
              </Select>
            </FieldWrapper>
            <FieldWrapper label="Designation" className="col-span-2">
              <TextInput value={userForm.designation ?? ""} onChange={(e) => setUserForm({ ...userForm, designation: e.target.value })} />
            </FieldWrapper>
          </div>
          <FormActions onCancel={() => setUserModal(false)} loading={userSaving} submitLabel={editingUser ? "Save Changes" : "Create User"} />
        </form>
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        title="Remove user?"
        message={`This will permanently remove "${deleteTarget?.name}"'s access.`}
        confirmLabel="Remove"
        loading={deleting}
        onConfirm={handleDeleteUser}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
}
