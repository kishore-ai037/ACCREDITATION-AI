"use client";

import { useCallback, useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Plus, Calendar, ListChecks, Pencil, Trash2, MapPin, User } from "lucide-react";
import PageHeader from "@/components/ui/PageHeader";
import Modal from "@/components/ui/Modal";
import ConfirmDialog from "@/components/ui/ConfirmDialog";
import StatusBadge from "@/components/ui/StatusBadge";
import { LoadingState, ErrorState, EmptyState, InlineError } from "@/components/ui/DataState";
import { FieldWrapper, TextInput, TextArea, Select, FormActions } from "@/components/ui/FormField";
import { useToast } from "@/components/ui/Toast";
import { useAuth } from "@/context/AuthContext";
import { iqacApi, MeetingInput, ActionPlanInput } from "@/lib/api";
import { IqacMeeting, IqacActionPlan } from "@/lib/api/types";
import { getErrorMessage, formatDate } from "@/lib/utils";

const emptyMeeting: MeetingInput = { title: "", meeting_date: "", venue: "", agenda: "", minutes: "" };
const emptyPlan: ActionPlanInput = { title: "", description: "", status: "planned", priority: "medium" };

export default function IqacPage() {
  const { user } = useAuth();
  const { showToast } = useToast();
  const canManage = ["admin", "principal", "iqac_coordinator"].includes(user?.role || "");
  const [tab, setTab] = useState<"meetings" | "plans">("meetings");

  const [meetings, setMeetings] = useState<IqacMeeting[]>([]);
  const [plans, setPlans] = useState<IqacActionPlan[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [meetingModal, setMeetingModal] = useState(false);
  const [editingMeeting, setEditingMeeting] = useState<IqacMeeting | null>(null);
  const [meetingForm, setMeetingForm] = useState<MeetingInput>(emptyMeeting);
  const [meetingError, setMeetingError] = useState<string | null>(null);
  const [savingMeeting, setSavingMeeting] = useState(false);
  const [deleteMeeting, setDeleteMeeting] = useState<IqacMeeting | null>(null);

  const [planModal, setPlanModal] = useState(false);
  const [editingPlan, setEditingPlan] = useState<IqacActionPlan | null>(null);
  const [planForm, setPlanForm] = useState<ActionPlanInput>(emptyPlan);
  const [planError, setPlanError] = useState<string | null>(null);
  const [savingPlan, setSavingPlan] = useState(false);
  const [deletePlan, setDeletePlan] = useState<IqacActionPlan | null>(null);

  const [deleting, setDeleting] = useState(false);

  const load = useCallback(() => {
    setLoading(true);
    setError(null);
    Promise.all([iqacApi.listMeetings({ limit: 50 }), iqacApi.listActionPlans({ limit: 50 })])
      .then(([m, p]) => {
        setMeetings(m.data);
        setPlans(p.data);
      })
      .catch((err) => setError(getErrorMessage(err, "Could not load IQAC data.")))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => { load(); }, [load]);

  // ── Meetings ──
  const openCreateMeeting = () => { setEditingMeeting(null); setMeetingForm(emptyMeeting); setMeetingError(null); setMeetingModal(true); };
  const openEditMeeting = (m: IqacMeeting) => {
    setEditingMeeting(m);
    setMeetingForm({ title: m.title, meeting_date: m.meeting_date.slice(0, 10), venue: m.venue || "", agenda: m.agenda || "", minutes: m.minutes || "" });
    setMeetingError(null);
    setMeetingModal(true);
  };
  const handleMeetingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setMeetingError(null);
    setSavingMeeting(true);
    try {
      if (editingMeeting) {
        await iqacApi.updateMeeting(editingMeeting.id, meetingForm);
        showToast("Meeting updated.");
      } else {
        await iqacApi.createMeeting(meetingForm);
        showToast("Meeting scheduled.");
      }
      setMeetingModal(false);
      load();
    } catch (err) {
      setMeetingError(getErrorMessage(err, "Could not save meeting."));
    } finally {
      setSavingMeeting(false);
    }
  };
  const handleDeleteMeeting = async () => {
    if (!deleteMeeting) return;
    setDeleting(true);
    try {
      await iqacApi.removeMeeting(deleteMeeting.id);
      showToast("Meeting removed.");
      setDeleteMeeting(null);
      load();
    } catch (err) {
      showToast(getErrorMessage(err, "Could not delete meeting."), "error");
    } finally {
      setDeleting(false);
    }
  };

  // ── Action plans ──
  const openCreatePlan = () => { setEditingPlan(null); setPlanForm(emptyPlan); setPlanError(null); setPlanModal(true); };
  const openEditPlan = (p: IqacActionPlan) => {
    setEditingPlan(p);
    setPlanForm({
      title: p.title,
      description: p.description || "",
      target_date: p.target_date ? p.target_date.slice(0, 10) : undefined,
      status: p.status,
      priority: p.priority,
      remarks: p.remarks || "",
      completion_pct: p.completion_pct,
    });
    setPlanError(null);
    setPlanModal(true);
  };
  const handlePlanSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setPlanError(null);
    setSavingPlan(true);
    try {
      const payload = { ...planForm, completion_pct: planForm.completion_pct ? Number(planForm.completion_pct) : undefined };
      if (editingPlan) {
        await iqacApi.updateActionPlan(editingPlan.id, payload);
        showToast("Action plan updated.");
      } else {
        await iqacApi.createActionPlan(payload);
        showToast("Action plan created.");
      }
      setPlanModal(false);
      load();
    } catch (err) {
      setPlanError(getErrorMessage(err, "Could not save action plan."));
    } finally {
      setSavingPlan(false);
    }
  };
  const handleDeletePlan = async () => {
    if (!deletePlan) return;
    setDeleting(true);
    try {
      await iqacApi.removeActionPlan(deletePlan.id);
      showToast("Action plan removed.");
      setDeletePlan(null);
      load();
    } catch (err) {
      showToast(getErrorMessage(err, "Could not delete action plan."), "error");
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto">
      <PageHeader
        title="IQAC"
        subtitle="Internal Quality Assurance Cell — meetings and action plans"
        actions={
          canManage && (
            <button
              onClick={tab === "meetings" ? openCreateMeeting : openCreatePlan}
              className="inline-flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold px-4 py-2.5 rounded-xl transition shadow-lg shadow-blue-600/20"
            >
              <Plus className="w-4 h-4" /> {tab === "meetings" ? "Schedule Meeting" : "New Action Plan"}
            </button>
          )
        }
      />

      <div className="flex gap-2 mb-6 border-b border-[var(--border)]">
        {(["meetings", "plans"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-4 py-2.5 text-sm font-medium border-b-2 transition ${
              tab === t ? "border-blue-600 text-blue-600" : "border-transparent text-[var(--muted-foreground)] hover:text-[var(--foreground)]"
            }`}
          >
            {t === "meetings" ? "Meetings" : "Action Plans"}
          </button>
        ))}
      </div>

      {loading ? (
        <LoadingState />
      ) : error ? (
        <ErrorState message={error} onRetry={load} />
      ) : tab === "meetings" ? (
        meetings.length === 0 ? (
          <div className="bg-[var(--card)] border border-[var(--border)] rounded-2xl">
            <EmptyState title="No meetings scheduled" message="Schedule your first IQAC meeting." icon={Calendar} />
          </div>
        ) : (
          <div className="space-y-3">
            {meetings.map((m, i) => (
              <motion.div
                key={m.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.03 }}
                className="bg-[var(--card)] border border-[var(--border)] rounded-2xl p-4 flex items-start justify-between gap-3 group"
              >
                <div className="flex gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950/40 flex items-center justify-center shrink-0">
                    <Calendar className="w-5 h-5 text-blue-500" />
                  </div>
                  <div className="min-w-0">
                    <div className="font-semibold text-[var(--foreground)] text-sm">{m.title}</div>
                    <div className="text-xs text-[var(--muted-foreground)] mt-0.5 flex items-center gap-3 flex-wrap">
                      <span>{formatDate(m.meeting_date)}</span>
                      {m.venue && <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {m.venue}</span>}
                      {m.created_by_name && <span className="flex items-center gap-1"><User className="w-3 h-3" /> {m.created_by_name}</span>}
                    </div>
                    {m.agenda && <p className="text-xs text-[var(--muted-foreground)] mt-2 line-clamp-2">{m.agenda}</p>}
                  </div>
                </div>
                {canManage && (
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition shrink-0">
                    <button onClick={() => openEditMeeting(m)} className="p-1.5 rounded-lg hover:bg-[var(--muted)] text-[var(--muted-foreground)] hover:text-[var(--foreground)]">
                      <Pencil className="w-3.5 h-3.5" />
                    </button>
                    <button onClick={() => setDeleteMeeting(m)} className="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-950/30 text-[var(--muted-foreground)] hover:text-red-600">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        )
      ) : plans.length === 0 ? (
        <div className="bg-[var(--card)] border border-[var(--border)] rounded-2xl">
          <EmptyState title="No action plans yet" message="Create action plans to track IQAC follow-ups." icon={ListChecks} />
        </div>
      ) : (
        <div className="space-y-3">
          {plans.map((p, i) => (
            <motion.div
              key={p.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.03 }}
              className="bg-[var(--card)] border border-[var(--border)] rounded-2xl p-4 flex items-start justify-between gap-3 group"
            >
              <div className="flex gap-3 min-w-0">
                <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 flex items-center justify-center shrink-0">
                  <ListChecks className="w-5 h-5 text-indigo-500" />
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-semibold text-[var(--foreground)] text-sm">{p.title}</span>
                    <StatusBadge status={p.status} />
                    <StatusBadge status={p.priority} />
                  </div>
                  {p.description && <p className="text-xs text-[var(--muted-foreground)] mt-1.5 line-clamp-2">{p.description}</p>}
                  <div className="text-[11px] text-[var(--muted-foreground)] mt-1.5 flex items-center gap-3">
                    {p.target_date && <span>Due {formatDate(p.target_date)}</span>}
                    {p.responsible_name && <span>Owner: {p.responsible_name}</span>}
                  </div>
                </div>
              </div>
              {canManage && (
                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition shrink-0">
                  <button onClick={() => openEditPlan(p)} className="p-1.5 rounded-lg hover:bg-[var(--muted)] text-[var(--muted-foreground)] hover:text-[var(--foreground)]">
                    <Pencil className="w-3.5 h-3.5" />
                  </button>
                  <button onClick={() => setDeletePlan(p)} className="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-950/30 text-[var(--muted-foreground)] hover:text-red-600">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </motion.div>
          ))}
        </div>
      )}

      {/* Meeting modal */}
      <Modal open={meetingModal} onClose={() => setMeetingModal(false)} title={editingMeeting ? "Edit Meeting" : "Schedule Meeting"} maxWidth="max-w-lg">
        <form onSubmit={handleMeetingSubmit} className="space-y-4">
          {meetingError && <InlineError message={meetingError} />}
          <FieldWrapper label="Title" required>
            <TextInput required value={meetingForm.title} onChange={(e) => setMeetingForm({ ...meetingForm, title: e.target.value })} />
          </FieldWrapper>
          <div className="grid grid-cols-2 gap-3">
            <FieldWrapper label="Date" required>
              <TextInput type="date" required value={meetingForm.meeting_date} onChange={(e) => setMeetingForm({ ...meetingForm, meeting_date: e.target.value })} />
            </FieldWrapper>
            <FieldWrapper label="Venue">
              <TextInput value={meetingForm.venue} onChange={(e) => setMeetingForm({ ...meetingForm, venue: e.target.value })} />
            </FieldWrapper>
          </div>
          <FieldWrapper label="Agenda">
            <TextArea value={meetingForm.agenda} onChange={(e) => setMeetingForm({ ...meetingForm, agenda: e.target.value })} />
          </FieldWrapper>
          <FieldWrapper label="Minutes">
            <TextArea value={meetingForm.minutes} onChange={(e) => setMeetingForm({ ...meetingForm, minutes: e.target.value })} />
          </FieldWrapper>
          <FormActions onCancel={() => setMeetingModal(false)} loading={savingMeeting} submitLabel={editingMeeting ? "Save Changes" : "Schedule"} />
        </form>
      </Modal>

      {/* Plan modal */}
      <Modal open={planModal} onClose={() => setPlanModal(false)} title={editingPlan ? "Edit Action Plan" : "New Action Plan"} maxWidth="max-w-lg">
        <form onSubmit={handlePlanSubmit} className="space-y-4">
          {planError && <InlineError message={planError} />}
          <FieldWrapper label="Title" required>
            <TextInput required value={planForm.title} onChange={(e) => setPlanForm({ ...planForm, title: e.target.value })} />
          </FieldWrapper>
          <FieldWrapper label="Description">
            <TextArea value={planForm.description} onChange={(e) => setPlanForm({ ...planForm, description: e.target.value })} />
          </FieldWrapper>
          <div className="grid grid-cols-2 gap-3">
            <FieldWrapper label="Target Date">
              <TextInput type="date" value={planForm.target_date ?? ""} onChange={(e) => setPlanForm({ ...planForm, target_date: e.target.value })} />
            </FieldWrapper>
            <FieldWrapper label="Priority">
              <Select value={planForm.priority} onChange={(e) => setPlanForm({ ...planForm, priority: e.target.value })}>
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
              </Select>
            </FieldWrapper>
            <FieldWrapper label="Status">
              <Select value={planForm.status} onChange={(e) => setPlanForm({ ...planForm, status: e.target.value })}>
                <option value="planned">Planned</option>
                <option value="in_progress">In Progress</option>
                <option value="completed">Completed</option>
                <option value="delayed">Delayed</option>
              </Select>
            </FieldWrapper>
            <FieldWrapper label="Completion %">
              <TextInput type="number" min="0" max="100" value={planForm.completion_pct ?? 0} onChange={(e) => setPlanForm({ ...planForm, completion_pct: Number(e.target.value) })} />
            </FieldWrapper>
          </div>
          <FormActions onCancel={() => setPlanModal(false)} loading={savingPlan} submitLabel={editingPlan ? "Save Changes" : "Create"} />
        </form>
      </Modal>

      <ConfirmDialog
        open={!!deleteMeeting}
        title="Delete meeting?"
        message={`This will permanently remove "${deleteMeeting?.title}".`}
        confirmLabel="Delete"
        loading={deleting}
        onConfirm={handleDeleteMeeting}
        onCancel={() => setDeleteMeeting(null)}
      />
      <ConfirmDialog
        open={!!deletePlan}
        title="Delete action plan?"
        message={`This will permanently remove "${deletePlan?.title}".`}
        confirmLabel="Delete"
        loading={deleting}
        onConfirm={handleDeletePlan}
        onCancel={() => setDeletePlan(null)}
      />
    </div>
  );
}
