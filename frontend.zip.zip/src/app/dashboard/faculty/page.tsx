"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Plus, Search, Pencil, Trash2, Users, Award, BookOpen, Briefcase,
  Filter, BookMarked, CheckCircle2,
} from "lucide-react";
import PageHeader from "@/components/ui/PageHeader";
import MiniStat from "@/components/ui/MiniStat";
import Modal from "@/components/ui/Modal";
import ConfirmDialog from "@/components/ui/ConfirmDialog";
import Pagination from "@/components/ui/Pagination";
import { LoadingState, ErrorState, EmptyState, InlineError } from "@/components/ui/DataState";
import { FieldWrapper, TextInput, Select, Checkbox, FormActions } from "@/components/ui/FormField";
import { useToast } from "@/components/ui/Toast";
import { useAuth } from "@/context/AuthContext";
import { facultyApi, departmentsApi, usersApi, researchApi, FacultyInput, ResearchInput } from "@/lib/api";
import { Faculty, Department, FacultyStats, ManagedUser, Research, EmploymentType, ResearchType } from "@/lib/api/types";
import { getErrorMessage } from "@/lib/utils";

const emptyForm: FacultyInput = {
  user_id: "",
  department_id: "",
  employment_type: "permanent",
  qualification: "",
  specialization: "",
  experience_years: 0,
  ugc_net: false,
  phd_guide: false,
};

const emptyResearch: ResearchInput = { faculty_id: "", title: "", type: "journal" };

export default function FacultyPage() {
  const { user } = useAuth();
  const { showToast } = useToast();
  const canManage = ["admin", "principal", "hod"].includes(user?.role || "");

  const [faculty, setFaculty] = useState<Faculty[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [availableUsers, setAvailableUsers] = useState<ManagedUser[]>([]);
  const [stats, setStats] = useState<FacultyStats | null>(null);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [page, setPage] = useState(1);
  const limit = 10;

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [deptFilter, setDeptFilter] = useState("");
  const [showFilters, setShowFilters] = useState(false);

  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Faculty | null>(null);
  const [form, setForm] = useState<FacultyInput>(emptyForm);
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const [deleteTarget, setDeleteTarget] = useState<Faculty | null>(null);
  const [deleting, setDeleting] = useState(false);

  const [pubTarget, setPubTarget] = useState<Faculty | null>(null);
  const [pubList, setPubList] = useState<Research[]>([]);
  const [pubLoading, setPubLoading] = useState(false);
  const [pubForm, setPubForm] = useState<ResearchInput>(emptyResearch);
  const [pubFormOpen, setPubFormOpen] = useState(false);
  const [pubSaving, setPubSaving] = useState(false);

  useEffect(() => {
    departmentsApi.list().then((r) => setDepartments(r.data)).catch(() => {});
    facultyApi.stats().then(setStats).catch(() => {});
    usersApi.list({ role: "faculty", limit: 100 }).then((r) => setAvailableUsers(r.data)).catch(() => {});
  }, []);

  const load = useCallback(() => {
    setLoading(true);
    setError(null);
    facultyApi
      .list({ page, limit, search: search || undefined, department_id: deptFilter || undefined })
      .then((r) => {
        setFaculty(r.data);
        setTotal(r.total);
        setTotalPages(r.totalPages);
      })
      .catch((err) => setError(getErrorMessage(err, "Could not load faculty.")))
      .finally(() => setLoading(false));
  }, [page, search, deptFilter]);

  useEffect(() => {
    const t = setTimeout(load, 250);
    return () => clearTimeout(t);
  }, [load]);

  useEffect(() => setPage(1), [search, deptFilter]);

  const openCreate = () => {
    setEditing(null);
    setForm({ ...emptyForm, department_id: departments[0]?.id || "" });
    setFormError(null);
    setModalOpen(true);
  };

  const openEdit = (f: Faculty) => {
    setEditing(f);
    setForm({
      user_id: f.user_id,
      department_id: f.department_id,
      employee_code: f.employee_code || "",
      gender: f.gender || "",
      employment_type: f.employment_type,
      qualification: f.qualification || "",
      specialization: f.specialization || "",
      experience_years: f.experience_years,
      industry_exp_years: f.industry_exp_years,
      ugc_net: f.ugc_net,
      phd_guide: f.phd_guide,
      publications_count: f.publications_count,
      patents_count: f.patents_count,
      funded_projects: f.funded_projects,
    });
    setFormError(null);
    setModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setSaving(true);
    try {
      const payload = {
        ...form,
        experience_years: form.experience_years ? Number(form.experience_years) : 0,
        industry_exp_years: form.industry_exp_years ? Number(form.industry_exp_years) : 0,
      };
      if (editing) {
        await facultyApi.update(editing.id, payload);
        showToast("Faculty profile updated.");
      } else {
        await facultyApi.create(payload);
        showToast("Faculty profile created.");
      }
      setModalOpen(false);
      load();
      facultyApi.stats().then(setStats).catch(() => {});
    } catch (err) {
      setFormError(getErrorMessage(err, "Could not save faculty profile."));
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await facultyApi.remove(deleteTarget.id);
      showToast("Faculty profile removed.");
      setDeleteTarget(null);
      load();
    } catch (err) {
      showToast(getErrorMessage(err, "Could not delete faculty."), "error");
    } finally {
      setDeleting(false);
    }
  };

  const openPublications = (f: Faculty) => {
    setPubTarget(f);
    setPubLoading(true);
    researchApi
      .list({ faculty_id: f.id, limit: 50 })
      .then((r) => setPubList(r.data))
      .catch(() => setPubList([]))
      .finally(() => setPubLoading(false));
  };

  const handleAddPublication = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pubTarget) return;
    setPubSaving(true);
    try {
      const created = await researchApi.create({ ...pubForm, faculty_id: pubTarget.id });
      setPubList((l) => [created, ...l]);
      setPubForm({ ...emptyResearch, faculty_id: pubTarget.id });
      setPubFormOpen(false);
      showToast("Publication added.");
    } catch (err) {
      showToast(getErrorMessage(err, "Could not add publication."), "error");
    } finally {
      setPubSaving(false);
    }
  };

  const handleVerifyPublication = async (r: Research) => {
    try {
      const updated = await researchApi.verify(r.id);
      setPubList((l) => l.map((x) => (x.id === r.id ? updated : x)));
    } catch (err) {
      showToast(getErrorMessage(err, "Could not verify publication."), "error");
    }
  };

  const handleDeletePublication = async (r: Research) => {
    try {
      await researchApi.remove(r.id);
      setPubList((l) => l.filter((x) => x.id !== r.id));
      showToast("Publication removed.");
    } catch (err) {
      showToast(getErrorMessage(err, "Could not remove publication."), "error");
    }
  };

  return (
    <div className="max-w-7xl mx-auto">
      <PageHeader
        title="Faculty"
        subtitle="Manage faculty profiles, qualifications, and research output"
        actions={
          canManage && (
            <button
              onClick={openCreate}
              className="inline-flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold px-4 py-2.5 rounded-xl transition shadow-lg shadow-blue-600/20"
            >
              <Plus className="w-4 h-4" /> Add Faculty
            </button>
          )
        }
      />

      {stats && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <MiniStat label="Total Faculty" value={stats.total_faculty} icon={Users} color="blue" />
          <MiniStat label="PhD Guides" value={stats.phd_guides} icon={Award} color="indigo" />
          <MiniStat label="Publications" value={stats.total_publications} icon={BookOpen} color="emerald" />
          <MiniStat label="Funded Projects" value={stats.total_funded_projects} icon={Briefcase} color="amber" />
        </div>
      )}

      <div className="bg-[var(--card)] border border-[var(--border)] rounded-2xl overflow-hidden">
        <div className="p-4 border-b border-[var(--border)] flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--muted-foreground)]" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by name or specialization…"
              className="w-full pl-9 pr-3 py-2 text-sm rounded-xl border border-[var(--border)] bg-[var(--muted)] text-[var(--foreground)] placeholder:text-[var(--muted-foreground)] focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <button
            onClick={() => setShowFilters((v) => !v)}
            className="inline-flex items-center gap-1.5 text-xs font-medium px-3 py-2 rounded-xl border border-[var(--border)] text-[var(--foreground)] hover:bg-[var(--muted)] transition"
          >
            <Filter className="w-3.5 h-3.5" /> Filters
          </button>
          {showFilters && (
            <Select value={deptFilter} onChange={(e) => setDeptFilter(e.target.value)} className="!w-auto max-w-[220px]">
              <option value="">All Departments</option>
              {departments.map((d) => (
                <option key={d.id} value={d.id}>{d.name}</option>
              ))}
            </Select>
          )}
        </div>

        {loading ? (
          <LoadingState label="Loading faculty…" />
        ) : error ? (
          <ErrorState message={error} onRetry={load} />
        ) : faculty.length === 0 ? (
          <EmptyState title="No faculty found" message="Add a faculty profile to get started." icon={Users} />
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-[var(--border)] text-left">
                    <th className="px-4 py-3 text-[11px] font-semibold text-[var(--muted-foreground)] uppercase">Faculty</th>
                    <th className="px-4 py-3 text-[11px] font-semibold text-[var(--muted-foreground)] uppercase">Department</th>
                    <th className="px-4 py-3 text-[11px] font-semibold text-[var(--muted-foreground)] uppercase">Type</th>
                    <th className="px-4 py-3 text-[11px] font-semibold text-[var(--muted-foreground)] uppercase">Experience</th>
                    <th className="px-4 py-3 text-[11px] font-semibold text-[var(--muted-foreground)] uppercase">Publications</th>
                    <th className="px-4 py-3 text-[11px] font-semibold text-[var(--muted-foreground)] uppercase text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[var(--border)]">
                  {faculty.map((f) => (
                    <tr key={f.id} className="hover:bg-[var(--muted)] transition">
                      <td className="px-4 py-3">
                        <div className="font-medium text-[var(--foreground)]">{f.name}</div>
                        <div className="text-[11px] text-[var(--muted-foreground)]">{f.designation || f.qualification || "—"}</div>
                      </td>
                      <td className="px-4 py-3 text-[var(--foreground)]">{f.department || "—"}</td>
                      <td className="px-4 py-3 text-[var(--foreground)] capitalize">{f.employment_type}</td>
                      <td className="px-4 py-3 text-[var(--foreground)]">{f.experience_years} yrs</td>
                      <td className="px-4 py-3">
                        <button
                          onClick={() => openPublications(f)}
                          className="inline-flex items-center gap-1 text-xs font-medium text-blue-600 hover:text-blue-700"
                        >
                          <BookMarked className="w-3.5 h-3.5" /> {f.publications_count}
                        </button>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-end gap-1">
                          {canManage && (
                            <>
                              <button onClick={() => openEdit(f)} className="p-1.5 rounded-lg hover:bg-[var(--muted)] text-[var(--muted-foreground)] hover:text-[var(--foreground)]">
                                <Pencil className="w-3.5 h-3.5" />
                              </button>
                              <button onClick={() => setDeleteTarget(f)} className="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-950/30 text-[var(--muted-foreground)] hover:text-red-600">
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="px-4">
              <Pagination page={page} totalPages={totalPages} total={total} limit={limit} onPageChange={setPage} />
            </div>
          </>
        )}
      </div>

      {/* Create/Edit modal */}
      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? "Edit Faculty Profile" : "Add Faculty"} maxWidth="max-w-2xl">
        <form onSubmit={handleSubmit} className="space-y-4">
          {formError && <InlineError message={formError} />}
          <div className="grid grid-cols-2 gap-3">
            {!editing && (
              <FieldWrapper label="User Account" required hint="Faculty must have an existing user login" className="col-span-2">
                <Select required value={form.user_id} onChange={(e) => setForm({ ...form, user_id: e.target.value })}>
                  <option value="">Select a user…</option>
                  {availableUsers.map((u) => (
                    <option key={u.id} value={u.id}>{u.name} ({u.email})</option>
                  ))}
                </Select>
              </FieldWrapper>
            )}
            <FieldWrapper label="Department" required>
              <Select required value={form.department_id} onChange={(e) => setForm({ ...form, department_id: e.target.value })}>
                <option value="">Select department</option>
                {departments.map((d) => (
                  <option key={d.id} value={d.id}>{d.name}</option>
                ))}
              </Select>
            </FieldWrapper>
            <FieldWrapper label="Employment Type">
              <Select value={form.employment_type} onChange={(e) => setForm({ ...form, employment_type: e.target.value as EmploymentType })}>
                <option value="permanent">Permanent</option>
                <option value="temporary">Temporary</option>
                <option value="visiting">Visiting</option>
                <option value="contract">Contract</option>
              </Select>
            </FieldWrapper>
            <FieldWrapper label="Qualification">
              <TextInput value={form.qualification} onChange={(e) => setForm({ ...form, qualification: e.target.value })} placeholder="Ph.D." />
            </FieldWrapper>
            <FieldWrapper label="Specialization">
              <TextInput value={form.specialization} onChange={(e) => setForm({ ...form, specialization: e.target.value })} />
            </FieldWrapper>
            <FieldWrapper label="Experience (years)">
              <TextInput type="number" min="0" value={form.experience_years ?? 0} onChange={(e) => setForm({ ...form, experience_years: Number(e.target.value) })} />
            </FieldWrapper>
            <FieldWrapper label="Industry Experience (years)">
              <TextInput type="number" min="0" value={form.industry_exp_years ?? 0} onChange={(e) => setForm({ ...form, industry_exp_years: Number(e.target.value) })} />
            </FieldWrapper>
            <div className="col-span-2 flex flex-wrap gap-4 border border-[var(--border)] rounded-xl p-3">
              <Checkbox label="UGC-NET Qualified" checked={!!form.ugc_net} onChange={(c) => setForm({ ...form, ugc_net: c })} />
              <Checkbox label="PhD Guide" checked={!!form.phd_guide} onChange={(c) => setForm({ ...form, phd_guide: c })} />
            </div>
          </div>
          <FormActions onCancel={() => setModalOpen(false)} loading={saving} submitLabel={editing ? "Save Changes" : "Add Faculty"} />
        </form>
      </Modal>

      {/* Publications panel */}
      <Modal open={!!pubTarget} onClose={() => setPubTarget(null)} title="Publications" subtitle={pubTarget?.name} maxWidth="max-w-2xl">
        <div className="space-y-3">
          <div className="flex justify-end">
            {canManage && (
              <button
                onClick={() => { setPubForm({ ...emptyResearch, faculty_id: pubTarget?.id || "" }); setPubFormOpen((v) => !v); }}
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-600 hover:text-blue-700"
              >
                <Plus className="w-3.5 h-3.5" /> Add Publication
              </button>
            )}
          </div>

          {pubFormOpen && (
            <form onSubmit={handleAddPublication} className="border border-[var(--border)] rounded-xl p-3 space-y-3 bg-[var(--muted)]">
              <div className="grid grid-cols-2 gap-3">
                <FieldWrapper label="Title" required className="col-span-2">
                  <TextInput required value={pubForm.title} onChange={(e) => setPubForm({ ...pubForm, title: e.target.value })} />
                </FieldWrapper>
                <FieldWrapper label="Type">
                  <Select value={pubForm.type} onChange={(e) => setPubForm({ ...pubForm, type: e.target.value as ResearchType })}>
                    <option value="journal">Journal</option>
                    <option value="conference">Conference</option>
                    <option value="book">Book</option>
                    <option value="book_chapter">Book Chapter</option>
                    <option value="patent">Patent</option>
                    <option value="project">Project</option>
                    <option value="consultancy">Consultancy</option>
                  </Select>
                </FieldWrapper>
                <FieldWrapper label="Year">
                  <TextInput type="number" value={pubForm.year ?? ""} onChange={(e) => setPubForm({ ...pubForm, year: e.target.value ? Number(e.target.value) : undefined })} />
                </FieldWrapper>
                <FieldWrapper label="Journal / Publisher" className="col-span-2">
                  <TextInput value={pubForm.journal_name ?? ""} onChange={(e) => setPubForm({ ...pubForm, journal_name: e.target.value })} />
                </FieldWrapper>
              </div>
              <FormActions onCancel={() => setPubFormOpen(false)} loading={pubSaving} submitLabel="Add" />
            </form>
          )}

          {pubLoading ? (
            <LoadingState label="Loading publications…" />
          ) : pubList.length === 0 ? (
            <EmptyState title="No publications yet" message="Add journal articles, patents, or conference papers." icon={BookMarked} />
          ) : (
            <div className="divide-y divide-[var(--border)] max-h-96 overflow-y-auto">
              {pubList.map((r) => (
                <div key={r.id} className="py-3 flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-sm font-medium text-[var(--foreground)] flex items-center gap-1.5">
                      {r.title}
                      {r.verified && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />}
                    </div>
                    <div className="text-[11px] text-[var(--muted-foreground)] mt-0.5 capitalize">
                      {r.type.replace("_", " ")} {r.year ? `· ${r.year}` : ""} {r.journal_name ? `· ${r.journal_name}` : ""}
                    </div>
                  </div>
                  {canManage && (
                    <div className="flex items-center gap-1 shrink-0">
                      {!r.verified && (
                        <button onClick={() => handleVerifyPublication(r)} className="p-1.5 rounded-lg hover:bg-emerald-50 dark:hover:bg-emerald-950/30 text-[var(--muted-foreground)] hover:text-emerald-600" title="Verify">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                      <button onClick={() => handleDeletePublication(r)} className="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-950/30 text-[var(--muted-foreground)] hover:text-red-600">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        title="Remove faculty profile?"
        message={`This will permanently remove "${deleteTarget?.name}"'s faculty profile.`}
        confirmLabel="Remove"
        loading={deleting}
        onConfirm={handleDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
}
