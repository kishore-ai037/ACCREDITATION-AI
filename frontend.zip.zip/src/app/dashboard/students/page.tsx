"use client";

import { useCallback, useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  Plus, Search, Pencil, Trash2, GraduationCap, Users, TrendingUp,
  AlertTriangle, Filter, Briefcase,
} from "lucide-react";
import PageHeader from "@/components/ui/PageHeader";
import MiniStat from "@/components/ui/MiniStat";
import Modal from "@/components/ui/Modal";
import ConfirmDialog from "@/components/ui/ConfirmDialog";
import Pagination from "@/components/ui/Pagination";
import StatusBadge from "@/components/ui/StatusBadge";
import { LoadingState, ErrorState, EmptyState, InlineError } from "@/components/ui/DataState";
import { FieldWrapper, TextInput, Select, FormActions } from "@/components/ui/FormField";
import { useToast } from "@/components/ui/Toast";
import { useAuth } from "@/context/AuthContext";
import { studentsApi, departmentsApi, placementsApi, StudentInput, PlacementInput } from "@/lib/api";
import { Student, Department, StudentStats, PlacementStatus } from "@/lib/api/types";
import { getErrorMessage } from "@/lib/utils";

const emptyForm: StudentInput = {
  department_id: "",
  roll_number: "",
  name: "",
  email: "",
  phone: "",
  gender: "",
  batch_year: new Date().getFullYear(),
  year_of_study: 1,
  semester: 1,
  section: "",
  lateral_entry: false,
  category: "",
  cgpa: undefined,
  arrear_count: 0,
};

export default function StudentsPage() {
  const { user } = useAuth();
  const { showToast } = useToast();
  const canManage = ["admin", "principal", "hod", "iqac_coordinator"].includes(user?.role || "");

  const [students, setStudents] = useState<Student[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [stats, setStats] = useState<StudentStats | null>(null);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [page, setPage] = useState(1);
  const limit = 10;

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [deptFilter, setDeptFilter] = useState("");
  const [showFilters, setShowFilters] = useState(false);

  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Student | null>(null);
  const [form, setForm] = useState<StudentInput>(emptyForm);
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const [deleteTarget, setDeleteTarget] = useState<Student | null>(null);
  const [deleting, setDeleting] = useState(false);

  const [placementTarget, setPlacementTarget] = useState<Student | null>(null);
  const [placementForm, setPlacementForm] = useState<PlacementInput>({ status: "not_placed" });
  const [placementSaving, setPlacementSaving] = useState(false);

  useEffect(() => {
    departmentsApi.list().then((r) => setDepartments(r.data)).catch(() => {});
    studentsApi.stats().then(setStats).catch(() => {});
  }, []);

  const load = useCallback(() => {
    setLoading(true);
    setError(null);
    studentsApi
      .list({ page, limit, search: search || undefined, department_id: deptFilter || undefined })
      .then((r) => {
        setStudents(r.data);
        setTotal(r.total);
        setTotalPages(r.totalPages);
      })
      .catch((err) => setError(getErrorMessage(err, "Could not load students.")))
      .finally(() => setLoading(false));
  }, [page, search, deptFilter]);

  useEffect(() => {
    const t = setTimeout(load, 250);
    return () => clearTimeout(t);
  }, [load]);

  useEffect(() => setPage(1), [search, deptFilter]);

  const openCreate = () => {
    setEditing(null);
    setForm({ ...emptyForm, department_id: departments[0]?.id || "" });
    setFormError(null);
    setModalOpen(true);
  };

  const openEdit = (s: Student) => {
    setEditing(s);
    setForm({
      department_id: s.department_id,
      roll_number: s.roll_number,
      name: s.name,
      email: s.email || "",
      phone: s.phone || "",
      gender: s.gender || "",
      date_of_birth: s.date_of_birth ? s.date_of_birth.slice(0, 10) : undefined,
      batch_year: s.batch_year,
      year_of_study: s.year_of_study || 1,
      semester: s.semester || 1,
      section: s.section || "",
      lateral_entry: s.lateral_entry,
      category: s.category || "",
      cgpa: s.cgpa || undefined,
      arrear_count: s.arrear_count,
    });
    setFormError(null);
    setModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setSaving(true);
    try {
      const payload = {
        ...form,
        batch_year: Number(form.batch_year),
        year_of_study: form.year_of_study ? Number(form.year_of_study) : undefined,
        semester: form.semester ? Number(form.semester) : undefined,
        cgpa: form.cgpa ? Number(form.cgpa) : undefined,
        arrear_count: form.arrear_count ? Number(form.arrear_count) : 0,
      };
      if (editing) {
        await studentsApi.update(editing.id, payload);
        showToast("Student updated successfully.");
      } else {
        await studentsApi.create(payload);
        showToast("Student added successfully.");
      }
      setModalOpen(false);
      load();
      studentsApi.stats().then(setStats).catch(() => {});
    } catch (err) {
      setFormError(getErrorMessage(err, "Could not save student."));
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await studentsApi.remove(deleteTarget.id);
      showToast("Student removed.");
      setDeleteTarget(null);
      load();
      studentsApi.stats().then(setStats).catch(() => {});
    } catch (err) {
      showToast(getErrorMessage(err, "Could not delete student."), "error");
    } finally {
      setDeleting(false);
    }
  };

  const openPlacement = (s: Student) => {
    setPlacementTarget(s);
    setPlacementForm({
      status: (s.placement_status as PlacementStatus) || "not_placed",
      company_name: s.company_name || "",
      package_lpa: s.package_lpa || undefined,
      job_role: s.job_role || "",
      batch_year: s.batch_year,
    });
  };

  const handlePlacementSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!placementTarget) return;
    setPlacementSaving(true);
    try {
      await placementsApi.upsertForStudent(placementTarget.id, {
        ...placementForm,
        package_lpa: placementForm.package_lpa ? Number(placementForm.package_lpa) : undefined,
      });
      showToast("Placement record updated.");
      setPlacementTarget(null);
      load();
    } catch (err) {
      showToast(getErrorMessage(err, "Could not update placement."), "error");
    } finally {
      setPlacementSaving(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto">
      <PageHeader
        title="Students"
        subtitle="Manage student records, academics, and placements"
        actions={
          canManage && (
            <button
              onClick={openCreate}
              className="inline-flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold px-4 py-2.5 rounded-xl transition shadow-lg shadow-blue-600/20"
            >
              <Plus className="w-4 h-4" /> Add Student
            </button>
          )
        }
      />

      {stats && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <MiniStat label="Total Students" value={stats.total_students} icon={Users} color="blue" />
          <MiniStat label="Active" value={stats.active_students} icon={GraduationCap} color="emerald" />
          <MiniStat label="Avg CGPA" value={Number(stats.avg_cgpa || 0).toFixed(2)} icon={TrendingUp} color="indigo" />
          <MiniStat label="With Arrears" value={stats.students_with_arrears} icon={AlertTriangle} color="amber" />
        </div>
      )}

      <div className="bg-[var(--card)] border border-[var(--border)] rounded-2xl overflow-hidden">
        <div className="p-4 border-b border-[var(--border)] flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--muted-foreground)]" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by name or roll number…"
              className="w-full pl-9 pr-3 py-2 text-sm rounded-xl border border-[var(--border)] bg-[var(--muted)] text-[var(--foreground)] placeholder:text-[var(--muted-foreground)] focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <button
            onClick={() => setShowFilters((v) => !v)}
            className="inline-flex items-center gap-1.5 text-xs font-medium px-3 py-2 rounded-xl border border-[var(--border)] text-[var(--foreground)] hover:bg-[var(--muted)] transition"
          >
            <Filter className="w-3.5 h-3.5" /> Filters
          </button>
          {showFilters && (
            <Select value={deptFilter} onChange={(e) => setDeptFilter(e.target.value)} className="!w-auto max-w-[220px]">
              <option value="">All Departments</option>
              {departments.map((d) => (
                <option key={d.id} value={d.id}>{d.name}</option>
              ))}
            </Select>
          )}
        </div>

        {loading ? (
          <LoadingState label="Loading students…" />
        ) : error ? (
          <ErrorState message={error} onRetry={load} />
        ) : students.length === 0 ? (
          <EmptyState
            title="No students found"
            message={search || deptFilter ? "Try adjusting your search or filters." : "Add your first student to get started."}
            icon={GraduationCap}
          />
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-[var(--border)] text-left">
                    <th className="px-4 py-3 text-[11px] font-semibold text-[var(--muted-foreground)] uppercase">Student</th>
                    <th className="px-4 py-3 text-[11px] font-semibold text-[var(--muted-foreground)] uppercase">Department</th>
                    <th className="px-4 py-3 text-[11px] font-semibold text-[var(--muted-foreground)] uppercase">Batch</th>
                    <th className="px-4 py-3 text-[11px] font-semibold text-[var(--muted-foreground)] uppercase">CGPA</th>
                    <th className="px-4 py-3 text-[11px] font-semibold text-[var(--muted-foreground)] uppercase">Placement</th>
                    <th className="px-4 py-3 text-[11px] font-semibold text-[var(--muted-foreground)] uppercase text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[var(--border)]">
                  {students.map((s) => (
                    <tr key={s.id} className="hover:bg-[var(--muted)] transition">
                      <td className="px-4 py-3">
                        <div className="font-medium text-[var(--foreground)]">{s.name}</div>
                        <div className="text-[11px] text-[var(--muted-foreground)]">{s.roll_number}</div>
                      </td>
                      <td className="px-4 py-3 text-[var(--foreground)]">{s.department || "—"}</td>
                      <td className="px-4 py-3 text-[var(--foreground)]">{s.batch_year}</td>
                      <td className="px-4 py-3 text-[var(--foreground)]">{s.cgpa ?? "—"}</td>
                      <td className="px-4 py-3">
                        <button onClick={() => canManage && openPlacement(s)} className={canManage ? "cursor-pointer" : "cursor-default"}>
                          <StatusBadge status={s.placement_status || "not_placed"} />
                        </button>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-end gap-1">
                          {canManage && (
                            <>
                              <button onClick={() => openPlacement(s)} className="p-1.5 rounded-lg hover:bg-[var(--muted)] text-[var(--muted-foreground)] hover:text-[var(--foreground)]" title="Placement">
                                <Briefcase className="w-3.5 h-3.5" />
                              </button>
                              <button onClick={() => openEdit(s)} className="p-1.5 rounded-lg hover:bg-[var(--muted)] text-[var(--muted-foreground)] hover:text-[var(--foreground)]">
                                <Pencil className="w-3.5 h-3.5" />
                              </button>
                              <button onClick={() => setDeleteTarget(s)} className="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-950/30 text-[var(--muted-foreground)] hover:text-red-600">
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="px-4">
              <Pagination page={page} totalPages={totalPages} total={total} limit={limit} onPageChange={setPage} />
            </div>
          </>
        )}
      </div>

      {/* Create / Edit modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editing ? "Edit Student" : "Add Student"}
        maxWidth="max-w-2xl"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          {formError && <InlineError message={formError} />}
          <div className="grid grid-cols-2 gap-3">
            <FieldWrapper label="Full Name" required>
              <TextInput required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </FieldWrapper>
            <FieldWrapper label="Roll Number" required>
              <TextInput required value={form.roll_number} onChange={(e) => setForm({ ...form, roll_number: e.target.value })} />
            </FieldWrapper>
            <FieldWrapper label="Department" required>
              <Select required value={form.department_id} onChange={(e) => setForm({ ...form, department_id: e.target.value })}>
                <option value="">Select department</option>
                {departments.map((d) => (
                  <option key={d.id} value={d.id}>{d.name}</option>
                ))}
              </Select>
            </FieldWrapper>
            <FieldWrapper label="Batch Year" required>
              <TextInput type="number" required value={form.batch_year} onChange={(e) => setForm({ ...form, batch_year: Number(e.target.value) })} />
            </FieldWrapper>
            <FieldWrapper label="Email">
              <TextInput type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </FieldWrapper>
            <FieldWrapper label="Phone">
              <TextInput value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            </FieldWrapper>
            <FieldWrapper label="Gender">
              <Select value={form.gender} onChange={(e) => setForm({ ...form, gender: e.target.value })}>
                <option value="">—</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
              </Select>
            </FieldWrapper>
            <FieldWrapper label="Section">
              <TextInput value={form.section} onChange={(e) => setForm({ ...form, section: e.target.value })} />
            </FieldWrapper>
            <FieldWrapper label="Year of Study">
              <Select value={form.year_of_study} onChange={(e) => setForm({ ...form, year_of_study: Number(e.target.value) })}>
                {[1, 2, 3, 4].map((y) => <option key={y} value={y}>Year {y}</option>)}
              </Select>
            </FieldWrapper>
            <FieldWrapper label="Semester">
              <Select value={form.semester} onChange={(e) => setForm({ ...form, semester: Number(e.target.value) })}>
                {[1, 2, 3, 4, 5, 6, 7, 8].map((s) => <option key={s} value={s}>Sem {s}</option>)}
              </Select>
            </FieldWrapper>
            <FieldWrapper label="CGPA">
              <TextInput type="number" step="0.01" min="0" max="10" value={form.cgpa ?? ""} onChange={(e) => setForm({ ...form, cgpa: e.target.value ? Number(e.target.value) : undefined })} />
            </FieldWrapper>
            <FieldWrapper label="Arrear Count">
              <TextInput type="number" min="0" value={form.arrear_count ?? 0} onChange={(e) => setForm({ ...form, arrear_count: Number(e.target.value) })} />
            </FieldWrapper>
          </div>
          <FormActions onCancel={() => setModalOpen(false)} loading={saving} submitLabel={editing ? "Save Changes" : "Add Student"} />
        </form>
      </Modal>

      {/* Placement modal */}
      <Modal
        open={!!placementTarget}
        onClose={() => setPlacementTarget(null)}
        title="Placement Details"
        subtitle={placementTarget?.name}
      >
        <form onSubmit={handlePlacementSubmit} className="space-y-4">
          <FieldWrapper label="Status" required>
            <Select
              required
              value={placementForm.status}
              onChange={(e) => setPlacementForm({ ...placementForm, status: e.target.value as PlacementStatus })}
            >
              <option value="not_placed">Not Placed</option>
              <option value="placed">Placed</option>
              <option value="higher_studies">Higher Studies</option>
              <option value="entrepreneur">Entrepreneur</option>
            </Select>
          </FieldWrapper>
          {placementForm.status === "placed" && (
            <div className="grid grid-cols-2 gap-3">
              <FieldWrapper label="Company Name" className="col-span-2">
                <TextInput value={placementForm.company_name ?? ""} onChange={(e) => setPlacementForm({ ...placementForm, company_name: e.target.value })} />
              </FieldWrapper>
              <FieldWrapper label="Package (LPA)">
                <TextInput type="number" step="0.1" value={placementForm.package_lpa ?? ""} onChange={(e) => setPlacementForm({ ...placementForm, package_lpa: e.target.value ? Number(e.target.value) : undefined })} />
              </FieldWrapper>
              <FieldWrapper label="Job Role">
                <TextInput value={placementForm.job_role ?? ""} onChange={(e) => setPlacementForm({ ...placementForm, job_role: e.target.value })} />
              </FieldWrapper>
            </div>
          )}
          {placementForm.status === "higher_studies" && (
            <FieldWrapper label="Institution / Program">
              <TextInput value={placementForm.higher_studies ?? ""} onChange={(e) => setPlacementForm({ ...placementForm, higher_studies: e.target.value })} />
            </FieldWrapper>
          )}
          <FormActions onCancel={() => setPlacementTarget(null)} loading={placementSaving} submitLabel="Save" />
        </form>
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        title="Remove student?"
        message={`This will permanently remove "${deleteTarget?.name}" and their academic records.`}
        confirmLabel="Remove"
        loading={deleting}
        onConfirm={handleDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
}
