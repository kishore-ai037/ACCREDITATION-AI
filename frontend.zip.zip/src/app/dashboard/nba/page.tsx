"use client";

import { useCallback, useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Plus, GraduationCap, Pencil, Trash2, Building2, Filter } from "lucide-react";
import PageHeader from "@/components/ui/PageHeader";
import MiniStat from "@/components/ui/MiniStat";
import Modal from "@/components/ui/Modal";
import ConfirmDialog from "@/components/ui/ConfirmDialog";
import { LoadingState, ErrorState, EmptyState, InlineError } from "@/components/ui/DataState";
import { FieldWrapper, TextInput, Select, FormActions } from "@/components/ui/FormField";
import { useToast } from "@/components/ui/Toast";
import { useAuth } from "@/context/AuthContext";
import { criteriaApi, departmentsApi, NbaInput } from "@/lib/api";
import { NbaCriteria, NbaOverviewRow, Department } from "@/lib/api/types";
import { cn, getErrorMessage } from "@/lib/utils";

const emptyForm: NbaInput = {
  department_id: "",
  criterion_no: "",
  criterion_name: "",
  max_marks: 100,
  obtained_marks: 0,
  tier: 1,
  cycle_year: "",
};

function getColor(val: number) {
  if (val >= 80) return "bg-emerald-500";
  if (val >= 60) return "bg-blue-500";
  if (val >= 40) return "bg-amber-500";
  return "bg-red-500";
}

export default function NbaPage() {
  const { user } = useAuth();
  const { showToast } = useToast();
  const canManage = ["admin", "principal", "hod", "iqac_coordinator"].includes(user?.role || "");

  const [criteria, setCriteria] = useState<NbaCriteria[]>([]);
  const [overview, setOverview] = useState<NbaOverviewRow[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [deptFilter, setDeptFilter] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<NbaCriteria | null>(null);
  const [form, setForm] = useState<NbaInput>(emptyForm);
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const [deleteTarget, setDeleteTarget] = useState<NbaCriteria | null>(null);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    departmentsApi.list().then((r) => setDepartments(r.data)).catch(() => {});
  }, []);

  const load = useCallback(() => {
    setLoading(true);
    setError(null);
    Promise.all([
      criteriaApi.listNba({ department_id: deptFilter || undefined }),
      criteriaApi.nbaOverview(),
    ])
      .then(([c, o]) => {
        setCriteria(c.data);
        setOverview(o);
      })
      .catch((err) => setError(getErrorMessage(err, "Could not load NBA criteria.")))
      .finally(() => setLoading(false));
  }, [deptFilter]);

  useEffect(() => { load(); }, [load]);

  const openCreate = () => {
    setEditing(null);
    setForm({ ...emptyForm, department_id: deptFilter || departments[0]?.id || "" });
    setFormError(null);
    setModalOpen(true);
  };

  const openEdit = (c: NbaCriteria) => {
    setEditing(c);
    setForm({
      department_id: c.department_id,
      criterion_no: c.criterion_no,
      criterion_name: c.criterion_name,
      max_marks: c.max_marks || 100,
      obtained_marks: c.obtained_marks,
      tier: c.tier,
      cycle_year: c.cycle_year || "",
      notes: c.notes || "",
    });
    setFormError(null);
    setModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setSaving(true);
    try {
      const payload = {
        ...form,
        max_marks: Number(form.max_marks),
        obtained_marks: Number(form.obtained_marks),
        tier: Number(form.tier),
      };
      if (editing) {
        await criteriaApi.updateNba(editing.id, payload);
        showToast("Criterion updated.");
      } else {
        await criteriaApi.createNba(payload);
        showToast("Criterion created.");
      }
      setModalOpen(false);
      load();
    } catch (err) {
      setFormError(getErrorMessage(err, "Could not save criterion."));
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await criteriaApi.removeNba(deleteTarget.id);
      showToast("Criterion removed.");
      setDeleteTarget(null);
      load();
    } catch (err) {
      showToast(getErrorMessage(err, "Could not delete criterion."), "error");
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto">
      <PageHeader
        title="NBA / OBE Accreditation"
        subtitle="Track outcome-based education criteria by department"
        actions={
          canManage && (
            <button
              onClick={openCreate}
              className="inline-flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold px-4 py-2.5 rounded-xl transition shadow-lg shadow-blue-600/20"
            >
              <Plus className="w-4 h-4" /> Add Criterion
            </button>
          )
        }
      />

      {loading ? (
        <LoadingState label="Loading NBA data…" />
      ) : error ? (
        <ErrorState message={error} onRetry={load} />
      ) : (
        <>
          {overview.length > 0 && (
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              {overview.slice(0, 4).map((d) => (
                <MiniStat key={d.department_code} label={d.department} value={`${Math.round(d.avg_completion)}%`} icon={Building2} color="blue" />
              ))}
            </div>
          )}

          <div className="bg-[var(--card)] border border-[var(--border)] rounded-2xl overflow-hidden">
            <div className="p-4 border-b border-[var(--border)] flex items-center gap-3">
              <Filter className="w-4 h-4 text-[var(--muted-foreground)]" />
              <Select value={deptFilter} onChange={(e) => setDeptFilter(e.target.value)} className="!w-auto max-w-[240px]">
                <option value="">All Departments</option>
                {departments.map((d) => (
                  <option key={d.id} value={d.id}>{d.name}</option>
                ))}
              </Select>
            </div>

            {criteria.length === 0 ? (
              <EmptyState title="No NBA criteria yet" message="Add department-level criteria to start tracking." icon={GraduationCap} />
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4">
                {criteria.map((c, i) => (
                  <motion.div
                    key={c.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.03 }}
                    className="border border-[var(--border)] rounded-2xl p-4 group"
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-bold w-8 h-6 bg-[var(--muted)] rounded text-[var(--muted-foreground)] flex items-center justify-center shrink-0">
                            {c.criterion_no}
                          </span>
                          <span className="text-sm font-semibold text-[var(--foreground)] truncate">{c.criterion_name}</span>
                        </div>
                        <div className="text-[11px] text-[var(--muted-foreground)] mt-1">{c.department} · Tier {c.tier}</div>
                      </div>
                      {canManage && (
                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition shrink-0">
                          <button onClick={() => openEdit(c)} className="p-1.5 rounded-lg hover:bg-[var(--muted)] text-[var(--muted-foreground)] hover:text-[var(--foreground)]">
                            <Pencil className="w-3.5 h-3.5" />
                          </button>
                          <button onClick={() => setDeleteTarget(c)} className="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-950/30 text-[var(--muted-foreground)] hover:text-red-600">
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </div>
                    <div className="flex items-center justify-between mb-1.5 mt-3">
                      <span className="text-[11px] text-[var(--muted-foreground)]">{c.obtained_marks} / {c.max_marks || 0} marks</span>
                      <span className="text-xs font-bold text-[var(--foreground)]">{Math.round(c.completion_pct)}%</span>
                    </div>
                    <div className="h-2 bg-[var(--muted)] rounded-full overflow-hidden">
                      <div className={cn("h-full rounded-full", getColor(c.completion_pct))} style={{ width: `${c.completion_pct}%` }} />
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        </>
      )}

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? "Edit Criterion" : "Add NBA Criterion"} maxWidth="max-w-lg">
        <form onSubmit={handleSubmit} className="space-y-4">
          {formError && <InlineError message={formError} />}
          <div className="grid grid-cols-2 gap-3">
            <FieldWrapper label="Department" required className="col-span-2">
              <Select required value={form.department_id} onChange={(e) => setForm({ ...form, department_id: e.target.value })}>
                <option value="">Select department</option>
                {departments.map((d) => (
                  <option key={d.id} value={d.id}>{d.name}</option>
                ))}
              </Select>
            </FieldWrapper>
            <FieldWrapper label="Criterion No." required>
              <TextInput required value={form.criterion_no} onChange={(e) => setForm({ ...form, criterion_no: e.target.value })} placeholder="2.1" />
            </FieldWrapper>
            <FieldWrapper label="Tier">
              <Select value={form.tier} onChange={(e) => setForm({ ...form, tier: Number(e.target.value) })}>
                <option value={1}>Tier 1</option>
                <option value={2}>Tier 2</option>
              </Select>
            </FieldWrapper>
            <FieldWrapper label="Criterion Name" required className="col-span-2">
              <TextInput required value={form.criterion_name} onChange={(e) => setForm({ ...form, criterion_name: e.target.value })} />
            </FieldWrapper>
            <FieldWrapper label="Max Marks">
              <TextInput type="number" value={form.max_marks} onChange={(e) => setForm({ ...form, max_marks: Number(e.target.value) })} />
            </FieldWrapper>
            <FieldWrapper label="Obtained Marks">
              <TextInput type="number" value={form.obtained_marks} onChange={(e) => setForm({ ...form, obtained_marks: Number(e.target.value) })} />
            </FieldWrapper>
            <FieldWrapper label="Cycle Year" className="col-span-2">
              <TextInput value={form.cycle_year} onChange={(e) => setForm({ ...form, cycle_year: e.target.value })} placeholder="2024-25" />
            </FieldWrapper>
          </div>
          <FormActions onCancel={() => setModalOpen(false)} loading={saving} submitLabel={editing ? "Save Changes" : "Add Criterion"} />
        </form>
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        title="Delete criterion?"
        message={`This will permanently remove criterion "${deleteTarget?.criterion_no}".`}
        confirmLabel="Delete"
        loading={deleting}
        onConfirm={handleDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
}
