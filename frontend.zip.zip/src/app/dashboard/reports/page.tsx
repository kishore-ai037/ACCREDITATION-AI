"use client";

import { useCallback, useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Plus, BarChart3, Download, Trash2, FileText, Loader2 } from "lucide-react";
import PageHeader from "@/components/ui/PageHeader";
import Modal from "@/components/ui/Modal";
import ConfirmDialog from "@/components/ui/ConfirmDialog";
import StatusBadge from "@/components/ui/StatusBadge";
import { LoadingState, ErrorState, EmptyState, InlineError } from "@/components/ui/DataState";
import { FieldWrapper, TextInput, TextArea, Select, FormActions } from "@/components/ui/FormField";
import { useToast } from "@/components/ui/Toast";
import { useAuth } from "@/context/AuthContext";
import { reportsApi, ReportGenerateInput } from "@/lib/api";
import { Report, ReportType } from "@/lib/api/types";
import { getErrorMessage, formatDate } from "@/lib/utils";

const emptyForm: ReportGenerateInput = { title: "", type: "naac_ssr", academic_year: "", description: "" };

const typeLabels: Record<ReportType, string> = {
  naac_ssr: "NAAC — Self Study Report",
  naac_iqar: "NAAC — IQAR",
  nba_sar: "NBA — Self Assessment Report",
  iqac_aqar: "IQAC — AQAR",
  custom: "Custom Report",
};

export default function ReportsPage() {
  const { user } = useAuth();
  const { showToast } = useToast();
  const canManage = ["admin", "principal", "iqac_coordinator"].includes(user?.role || "");

  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState<ReportGenerateInput>(emptyForm);
  const [formError, setFormError] = useState<string | null>(null);
  const [generating, setGenerating] = useState(false);

  const [deleteTarget, setDeleteTarget] = useState<Report | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [downloadingId, setDownloadingId] = useState<string | null>(null);

  const load = useCallback(() => {
    setLoading(true);
    setError(null);
    reportsApi
      .list({ limit: 50 })
      .then((r) => setReports(r.data))
      .catch((err) => setError(getErrorMessage(err, "Could not load reports.")))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => { load(); }, [load]);

  const openCreate = () => {
    setForm(emptyForm);
    setFormError(null);
    setModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setGenerating(true);
    try {
      await reportsApi.generate(form);
      showToast("Report generated successfully.");
      setModalOpen(false);
      load();
    } catch (err) {
      setFormError(getErrorMessage(err, "Could not generate report."));
    } finally {
      setGenerating(false);
    }
  };

  const handleDownload = async (r: Report) => {
    setDownloadingId(r.id);
    try {
      await reportsApi.download(r.id, `${r.title.replace(/[^a-z0-9]+/gi, "_")}.pdf`);
    } catch (err) {
      showToast(getErrorMessage(err, "Could not download report."), "error");
    } finally {
      setDownloadingId(null);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await reportsApi.remove(deleteTarget.id);
      showToast("Report deleted.");
      setDeleteTarget(null);
      load();
    } catch (err) {
      showToast(getErrorMessage(err, "Could not delete report."), "error");
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto">
      <PageHeader
        title="Reports"
        subtitle="Generate and download NAAC, NBA, and IQAC reports"
        actions={
          canManage && (
            <button
              onClick={openCreate}
              className="inline-flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold px-4 py-2.5 rounded-xl transition shadow-lg shadow-blue-600/20"
            >
              <Plus className="w-4 h-4" /> Generate Report
            </button>
          )
        }
      />

      <div className="bg-[var(--card)] border border-[var(--border)] rounded-2xl overflow-hidden">
        {loading ? (
          <LoadingState label="Loading reports…" />
        ) : error ? (
          <ErrorState message={error} onRetry={load} />
        ) : reports.length === 0 ? (
          <EmptyState title="No reports yet" message="Generate your first accreditation report." icon={BarChart3} />
        ) : (
          <div className="divide-y divide-[var(--border)]">
            {reports.map((r, i) => (
              <motion.div
                key={r.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.03 }}
                className="p-4 flex items-center justify-between gap-3 hover:bg-[var(--muted)] transition group"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950/40 flex items-center justify-center shrink-0">
                    <FileText className="w-5 h-5 text-blue-500" />
                  </div>
                  <div className="min-w-0">
                    <div className="font-semibold text-[var(--foreground)] text-sm truncate">{r.title}</div>
                    <div className="text-[11px] text-[var(--muted-foreground)] mt-0.5">
                      {typeLabels[r.type]} {r.academic_year ? `· ${r.academic_year}` : ""} · {formatDate(r.created_at)}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <StatusBadge status={r.status} />
                  {r.status === "completed" && (
                    <button
                      onClick={() => handleDownload(r)}
                      disabled={downloadingId === r.id}
                      className="p-2 rounded-lg hover:bg-blue-50 dark:hover:bg-blue-950/30 text-[var(--muted-foreground)] hover:text-blue-600 disabled:opacity-50"
                      title="Download"
                    >
                      {downloadingId === r.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Download className="w-3.5 h-3.5" />}
                    </button>
                  )}
                  {canManage && (
                    <button onClick={() => setDeleteTarget(r)} className="p-2 rounded-lg hover:bg-red-50 dark:hover:bg-red-950/30 text-[var(--muted-foreground)] hover:text-red-600">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title="Generate Report" maxWidth="max-w-lg">
        <form onSubmit={handleSubmit} className="space-y-4">
          {formError && <InlineError message={formError} />}
          <FieldWrapper label="Report Title" required>
            <TextInput required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Self Study Report 2024-25" />
          </FieldWrapper>
          <div className="grid grid-cols-2 gap-3">
            <FieldWrapper label="Report Type" required>
              <Select required value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value as ReportType })}>
                {Object.entries(typeLabels).map(([val, label]) => (
                  <option key={val} value={val}>{label}</option>
                ))}
              </Select>
            </FieldWrapper>
            <FieldWrapper label="Academic Year">
              <TextInput value={form.academic_year} onChange={(e) => setForm({ ...form, academic_year: e.target.value })} placeholder="2024-25" />
            </FieldWrapper>
          </div>
          <FieldWrapper label="Description">
            <TextArea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          </FieldWrapper>
          <FormActions onCancel={() => setModalOpen(false)} loading={generating} submitLabel="Generate" />
        </form>
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        title="Delete report?"
        message={`This will permanently remove "${deleteTarget?.title}".`}
        confirmLabel="Delete"
        loading={deleting}
        onConfirm={handleDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
}
