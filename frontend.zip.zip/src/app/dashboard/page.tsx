import DashboardHome from "@/components/dashboard/DashboardHome";

export const metadata = {
  title: "Dashboard – AccrediAI",
};

export default function DashboardPage() {
  return <DashboardHome />;
}
