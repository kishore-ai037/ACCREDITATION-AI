"use client";

import React, { createContext, useContext, useState, useCallback, useEffect } from "react";
import { User } from "@/types";
import { authApi, tokenStorage, onSessionExpired, ApiError, AuthUser, UserProfile } from "@/lib/api";

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<{ ok: boolean; error?: string }>;
  logout: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

function mapAuthUser(u: AuthUser | UserProfile): User {
  return {
    id: u.id,
    name: u.name,
    email: u.email,
    role: u.role,
    avatar: u.avatar_url ?? undefined,
    department: "department" in u ? (u.department ?? undefined) : undefined,
    departmentId: u.department_id,
    designation: u.designation,
    institution: u.institution,
    institutionId: u.institution_id,
  };
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const logout = useCallback(async () => {
    try {
      if (tokenStorage.getAccessToken()) {
        await authApi.logout();
      }
    } catch {
      // ignore — we clear local state regardless
    } finally {
      tokenStorage.clear();
      setUser(null);
    }
  }, []);

  const refreshProfile = useCallback(async () => {
    try {
      const profile = await authApi.me();
      setUser(mapAuthUser(profile));
    } catch {
      tokenStorage.clear();
      setUser(null);
    }
  }, []);

  // Restore session on first load
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const token = tokenStorage.getAccessToken();
      if (!token) {
        setIsLoading(false);
        return;
      }
      try {
        const profile = await authApi.me();
        if (!cancelled) setUser(mapAuthUser(profile));
      } catch {
        tokenStorage.clear();
      } finally {
        if (!cancelled) setIsLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  // React to forced session expiry from the API client (refresh failed)
  useEffect(() => {
    onSessionExpired(() => {
      setUser(null);
    });
    return () => onSessionExpired(null);
  }, []);

  const login = useCallback(async (email: string, password: string): Promise<{ ok: boolean; error?: string }> => {
    try {
      const result = await authApi.login(email, password);
      tokenStorage.setTokens(result.accessToken, result.refreshToken);
      setUser(mapAuthUser(result.user));
      return { ok: true };
    } catch (err) {
      const message = err instanceof ApiError ? err.message : "Unable to sign in. Please try again.";
      return { ok: false, error: message };
    }
  }, []);

  return (
    <AuthContext.Provider value={{ user, isAuthenticated: !!user, isLoading, login, logout, refreshProfile }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
