"use client";

import { useState, useEffect, useCallback } from "react";
import { useRouter } from "next/navigation";
import {
  Bell, Search, Sun, Moon, Menu, ChevronDown,
  LogOut, User, Settings, HelpCircle, Loader2,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useTheme } from "next-themes";
import { useAuth } from "@/context/AuthContext";
import { notificationsApi, AppNotification } from "@/lib/api";
import { cn, timeAgo } from "@/lib/utils";
import Link from "next/link";

const roleLabels: Record<string, string> = {
  admin: "Administrator",
  iqac_coordinator: "IQAC Coordinator",
  hod: "Head of Department",
  faculty: "Faculty",
  principal: "Principal",
  student: "Student",
};

interface TopNavProps {
  onMenuClick: () => void;
}

export default function TopNav({ onMenuClick }: TopNavProps) {
  const { user, logout } = useAuth();
  const { theme, setTheme } = useTheme();
  const router = useRouter();
  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [searchFocused, setSearchFocused] = useState(false);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [unread, setUnread] = useState(0);
  const [loadingNotifs, setLoadingNotifs] = useState(false);

  const loadUnread = useCallback(() => {
    notificationsApi
      .unreadCount()
      .then((r) => setUnread(r.count))
      .catch(() => {});
  }, []);

  useEffect(() => {
    loadUnread();
    const interval = setInterval(loadUnread, 60000);
    return () => clearInterval(interval);
  }, [loadUnread]);

  const openNotifications = () => {
    setShowNotifications((v) => !v);
    setShowProfile(false);
    if (!showNotifications) {
      setLoadingNotifs(true);
      notificationsApi
        .list({ limit: 8 })
        .then((r) => setNotifications(r.data))
        .catch(() => setNotifications([]))
        .finally(() => setLoadingNotifs(false));
    }
  };

  const handleMarkAllRead = async () => {
    try {
      await notificationsApi.markAllRead();
      setNotifications((n) => n.map((x) => ({ ...x, read: true })));
      setUnread(0);
    } catch {
      /* ignore */
    }
  };

  const handleLogout = async () => {
    await logout();
    router.push("/login");
  };

  const notifColors: Record<string, string> = {
    warning: "bg-amber-400",
    success: "bg-emerald-400",
    info: "bg-blue-400",
    error: "bg-red-400",
  };

  const initials = user?.name?.split(" ").map((n) => n[0]).slice(0, 2).join("") || "?";

  return (
    <header className="h-16 border-b border-[var(--border)] bg-[var(--card)] flex items-center px-4 gap-4 sticky top-0 z-30">
      {/* Mobile menu */}
      <button
        onClick={onMenuClick}
        className="lg:hidden p-2 rounded-lg hover:bg-[var(--muted)] text-[var(--muted-foreground)] hover:text-[var(--foreground)] transition"
      >
        <Menu className="w-5 h-5" />
      </button>

      {/* Search */}
      <div className={cn("relative flex-1 max-w-xl transition-all", searchFocused ? "max-w-2xl" : "")}>
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--muted-foreground)]" />
        <input
          type="text"
          placeholder="Search documents, criteria, faculty…"
          onFocus={() => setSearchFocused(true)}
          onBlur={() => setSearchFocused(false)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              const val = (e.target as HTMLInputElement).value.trim();
              if (val) router.push(`/dashboard/ai-search?q=${encodeURIComponent(val)}`);
            }
          }}
          className="w-full pl-10 pr-4 py-2 text-sm rounded-xl border border-[var(--border)] bg-[var(--muted)] text-[var(--foreground)] placeholder:text-[var(--muted-foreground)] focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent focus:bg-[var(--card)] transition"
        />
        {searchFocused && (
          <kbd className="absolute right-3 top-1/2 -translate-y-1/2 hidden sm:flex items-center gap-1 px-1.5 py-0.5 text-[10px] font-mono bg-[var(--border)] text-[var(--muted-foreground)] rounded">
            ⏎
          </kbd>
        )}
      </div>

      <div className="flex items-center gap-1 ml-auto">
        {/* Theme toggle */}
        <button
          onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          className="p-2 rounded-xl hover:bg-[var(--muted)] text-[var(--muted-foreground)] hover:text-[var(--foreground)] transition"
          title="Toggle theme"
        >
          {theme === "dark" ? <Sun className="w-4.5 h-4.5" /> : <Moon className="w-4.5 h-4.5" />}
        </button>

        {/* Notifications */}
        <div className="relative">
          <button
            onClick={openNotifications}
            className="relative p-2 rounded-xl hover:bg-[var(--muted)] text-[var(--muted-foreground)] hover:text-[var(--foreground)] transition"
          >
            <Bell className="w-4.5 h-4.5" />
            {unread > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-blue-500 rounded-full border-2 border-[var(--card)]" />
            )}
          </button>

          <AnimatePresence>
            {showNotifications && (
              <motion.div
                initial={{ opacity: 0, y: 8, scale: 0.97 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 8, scale: 0.97 }}
                transition={{ duration: 0.15 }}
                className="absolute right-0 top-full mt-2 w-80 bg-[var(--card)] border border-[var(--border)] rounded-2xl shadow-2xl overflow-hidden z-50"
              >
                <div className="p-4 border-b border-[var(--border)] flex items-center justify-between">
                  <span className="font-semibold text-[var(--foreground)] text-sm">Notifications</span>
                  {unread > 0 && (
                    <span className="text-xs bg-blue-100 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 px-2 py-0.5 rounded-full font-medium">
                      {unread} new
                    </span>
                  )}
                </div>
                <div className="max-h-80 overflow-y-auto divide-y divide-[var(--border)]">
                  {loadingNotifs ? (
                    <div className="p-6 flex justify-center">
                      <Loader2 className="w-4 h-4 animate-spin text-[var(--muted-foreground)]" />
                    </div>
                  ) : notifications.length === 0 ? (
                    <div className="p-6 text-center text-xs text-[var(--muted-foreground)]">
                      You&apos;re all caught up.
                    </div>
                  ) : (
                    notifications.map((n) => (
                      <div
                        key={n.id}
                        className={cn(
                          "p-3.5 hover:bg-[var(--muted)] transition cursor-pointer",
                          !n.read && "bg-blue-50/50 dark:bg-blue-950/10"
                        )}
                      >
                        <div className="flex gap-2.5">
                          <div className={cn("w-2 h-2 rounded-full mt-1.5 shrink-0", notifColors[n.type])} />
                          <div className="min-w-0">
                            <div className="font-medium text-[var(--foreground)] text-xs leading-tight">
                              {n.title}
                            </div>
                            <div className="text-[var(--muted-foreground)] text-xs mt-0.5 leading-relaxed">
                              {n.message}
                            </div>
                            <div className="text-[var(--muted-foreground)] text-[10px] mt-1">
                              {timeAgo(n.created_at)}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
                <div className="p-3 border-t border-[var(--border)]">
                  <button
                    onClick={handleMarkAllRead}
                    className="w-full text-center text-xs text-blue-600 hover:text-blue-700 font-medium transition"
                  >
                    Mark all as read
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Profile */}
        <div className="relative ml-1">
          <button
            onClick={() => { setShowProfile(!showProfile); setShowNotifications(false); }}
            className="flex items-center gap-2 pl-2 pr-3 py-1.5 rounded-xl hover:bg-[var(--muted)] transition"
          >
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white text-xs font-bold">
              {initials}
            </div>
            <div className="hidden sm:block text-left">
              <div className="text-xs font-semibold text-[var(--foreground)] leading-tight max-w-[120px] truncate">{user?.name}</div>
              <div className="text-[10px] text-[var(--muted-foreground)]">{user?.role ? roleLabels[user.role] : ""}</div>
            </div>
            <ChevronDown className="w-3.5 h-3.5 text-[var(--muted-foreground)] hidden sm:block" />
          </button>

          <AnimatePresence>
            {showProfile && (
              <motion.div
                initial={{ opacity: 0, y: 8, scale: 0.97 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 8, scale: 0.97 }}
                transition={{ duration: 0.15 }}
                className="absolute right-0 top-full mt-2 w-60 bg-[var(--card)] border border-[var(--border)] rounded-2xl shadow-2xl overflow-hidden z-50"
              >
                <div className="p-4 border-b border-[var(--border)]">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white font-bold mb-2">
                    {initials}
                  </div>
                  <div className="font-semibold text-[var(--foreground)] text-sm">{user?.name}</div>
                  <div className="text-[var(--muted-foreground)] text-xs mt-0.5">{user?.email}</div>
                  {(user?.department || user?.designation) && (
                    <div className="text-[10px] mt-1 text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/40 px-2 py-0.5 rounded-full inline-block">
                      {user?.designation || user?.department}
                    </div>
                  )}
                </div>
                <div className="p-2">
                  <Link
                    href="/dashboard/settings"
                    onClick={() => setShowProfile(false)}
                    className="w-full flex items-center gap-3 px-3 py-2 rounded-xl hover:bg-[var(--muted)] text-[var(--foreground)] text-sm transition text-left"
                  >
                    <User className="w-4 h-4 text-[var(--muted-foreground)]" />
                    My Profile
                  </Link>
                  <Link
                    href="/dashboard/settings"
                    onClick={() => setShowProfile(false)}
                    className="w-full flex items-center gap-3 px-3 py-2 rounded-xl hover:bg-[var(--muted)] text-[var(--foreground)] text-sm transition text-left"
                  >
                    <Settings className="w-4 h-4 text-[var(--muted-foreground)]" />
                    Settings
                  </Link>
                  <button className="w-full flex items-center gap-3 px-3 py-2 rounded-xl hover:bg-[var(--muted)] text-[var(--foreground)] text-sm transition text-left">
                    <HelpCircle className="w-4 h-4 text-[var(--muted-foreground)]" />
                    Help & Support
                  </button>
                </div>
                <div className="p-2 border-t border-[var(--border)]">
                  <button
                    onClick={handleLogout}
                    className="w-full flex items-center gap-3 px-3 py-2 rounded-xl hover:bg-red-50 dark:hover:bg-red-950/30 text-red-600 text-sm transition text-left"
                  >
                    <LogOut className="w-4 h-4" />
                    Sign out
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </header>
  );
}
