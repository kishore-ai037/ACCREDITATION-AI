"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  LayoutDashboard, FileText, Sparkles, Award, GraduationCap,
  ShieldCheck, Users, BookOpen, Building2, BarChart3,
  Settings, ChevronLeft, ChevronRight, ShieldCheckIcon, X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/context/AuthContext";
import { navItems } from "@/lib/data";
import { NavItem } from "@/types";
import { dashboardApi, documentsApi } from "@/lib/api";

const iconMap: Record<string, React.FC<{ className?: string }>> = {
  LayoutDashboard, FileText, Sparkles, Award, GraduationCap,
  ShieldCheck, Users, BookOpen, Building2, BarChart3, Settings,
};

interface SidebarProps {
  collapsed: boolean;
  onToggle: () => void;
  mobileOpen: boolean;
  onMobileClose: () => void;
}

function NavLink({ item, collapsed }: { item: NavItem; collapsed: boolean }) {
  const pathname = usePathname();
  const { user } = useAuth();
  const Icon = iconMap[item.icon] || LayoutDashboard;

  if (item.roles && user && !item.roles.includes(user.role)) return null;

  const isActive = pathname === item.href;

  return (
    <Link
      href={item.href}
      className={cn(
        "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all group relative",
        isActive
          ? "bg-blue-600 text-white shadow-lg shadow-blue-600/30"
          : "text-slate-400 hover:text-white hover:bg-slate-800"
      )}
    >
      <Icon className="w-5 h-5 shrink-0" />
      <AnimatePresence>
        {!collapsed && (
          <motion.span
            initial={{ opacity: 0, width: 0 }}
            animate={{ opacity: 1, width: "auto" }}
            exit={{ opacity: 0, width: 0 }}
            className="whitespace-nowrap overflow-hidden"
          >
            {item.label}
          </motion.span>
        )}
      </AnimatePresence>
      {item.badge && !collapsed && (
        <span className="ml-auto bg-blue-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full min-w-[18px] text-center">
          {item.badge}
        </span>
      )}
      {collapsed && (
        <div className="absolute left-full ml-3 px-2.5 py-1.5 bg-slate-700 text-white text-xs rounded-lg opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50 transition-opacity">
          {item.label}
          {item.badge && (
            <span className="ml-1.5 bg-blue-500 text-white text-[10px] px-1 rounded-full">
              {item.badge}
            </span>
          )}
        </div>
      )}
    </Link>
  );
}

export default function Sidebar({ collapsed, onToggle, mobileOpen, onMobileClose }: SidebarProps) {
  const [pendingDocs, setPendingDocs] = useState<number | null>(null);
  const [naacCompletion, setNaacCompletion] = useState<number | null>(null);

  useEffect(() => {
    documentsApi
      .stats()
      .then((s) => setPendingDocs(s.pending))
      .catch(() => {});
    dashboardApi
      .summary()
      .then((s) => setNaacCompletion(Math.round(s.naac_completion_pct)))
      .catch(() => {});
  }, []);

  const items: NavItem[] = navItems.map((item) =>
    item.href === "/dashboard/documents" ? { ...item, badge: pendingDocs ?? undefined } : item
  );

  const sidebarContent = (
    <div className="flex flex-col h-full bg-[#0f172a]">
      {/* Header */}
      <div className={cn("flex items-center h-16 px-4 border-b border-slate-800", collapsed ? "justify-center" : "justify-between")}>
        <AnimatePresence>
          {!collapsed && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex items-center gap-2.5"
            >
              <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center shrink-0">
                <ShieldCheckIcon className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="text-white font-bold text-sm leading-tight">AccrediAI</div>
                <div className="text-slate-500 text-[10px]">v2.4.1</div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        {collapsed && (
          <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center">
            <ShieldCheckIcon className="w-5 h-5 text-white" />
          </div>
        )}
        <button
          onClick={onToggle}
          className="hidden lg:flex w-7 h-7 rounded-lg bg-slate-800 hover:bg-slate-700 items-center justify-center text-slate-400 hover:text-white transition"
        >
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
        <button onClick={onMobileClose} className="lg:hidden text-slate-400 hover:text-white">
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto py-4 px-2 space-y-1">
        {items.map((item) => (
          <NavLink key={item.href} item={item} collapsed={collapsed} />
        ))}
      </nav>

      {/* Footer */}
      {!collapsed && naacCompletion !== null && (
        <div className="p-4 border-t border-slate-800">
          <div className="bg-blue-600/10 border border-blue-600/20 rounded-xl p-3">
            <div className="text-blue-400 text-xs font-semibold mb-1">NAAC Progress</div>
            <div className="text-slate-300 text-xs mb-2">Current accreditation cycle</div>
            <div className="h-1.5 bg-slate-700 rounded-full overflow-hidden">
              <div className="h-full bg-blue-500 rounded-full" style={{ width: `${naacCompletion}%` }} />
            </div>
            <div className="text-slate-400 text-[10px] mt-1">{naacCompletion}% criteria complete</div>
          </div>
        </div>
      )}
    </div>
  );

  return (
    <>
      {/* Desktop sidebar */}
      <motion.aside
        animate={{ width: collapsed ? 72 : 256 }}
        transition={{ duration: 0.25, ease: "easeInOut" }}
        className="hidden lg:flex flex-col h-screen sticky top-0 shrink-0 overflow-hidden"
      >
        {sidebarContent}
      </motion.aside>

      {/* Mobile overlay */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={onMobileClose}
              className="lg:hidden fixed inset-0 bg-black/60 z-40"
            />
            <motion.aside
              initial={{ x: -280 }}
              animate={{ x: 0 }}
              exit={{ x: -280 }}
              transition={{ type: "spring", damping: 30, stiffness: 300 }}
              className="lg:hidden fixed left-0 top-0 h-full w-64 z-50 overflow-hidden"
            >
              {sidebarContent}
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
