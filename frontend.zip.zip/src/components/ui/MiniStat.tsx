"use client";

import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface MiniStatProps {
  label: string;
  value: string | number;
  icon: LucideIcon;
  color?: "blue" | "emerald" | "amber" | "red" | "indigo" | "purple";
}

const colorMap: Record<string, string> = {
  blue: "bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400",
  emerald: "bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400",
  amber: "bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400",
  red: "bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400",
  indigo: "bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400",
  purple: "bg-purple-50 dark:bg-purple-950/40 text-purple-600 dark:text-purple-400",
};

export default function MiniStat({ label, value, icon: Icon, color = "blue" }: MiniStatProps) {
  return (
    <div className="bg-[var(--card)] border border-[var(--border)] rounded-2xl p-4 flex items-center gap-3">
      <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center shrink-0", colorMap[color])}>
        <Icon className="w-5 h-5" />
      </div>
      <div className="min-w-0">
        <div className="text-lg font-bold text-[var(--foreground)] leading-tight truncate">{value}</div>
        <div className="text-[11px] text-[var(--muted-foreground)] truncate">{label}</div>
      </div>
    </div>
  );
}
