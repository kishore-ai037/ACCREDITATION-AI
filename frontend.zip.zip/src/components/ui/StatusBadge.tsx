"use client";

import { cn } from "@/lib/utils";

const STYLE_MAP: Record<string, string> = {
  // document / generic statuses
  draft: "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300",
  pending: "bg-amber-50 text-amber-600 dark:bg-amber-950/40 dark:text-amber-400",
  approved: "bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400",
  rejected: "bg-red-50 text-red-600 dark:bg-red-950/40 dark:text-red-400",
  archived: "bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400",
  completed: "bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400",
  generating: "bg-amber-50 text-amber-600 dark:bg-amber-950/40 dark:text-amber-400",
  failed: "bg-red-50 text-red-600 dark:bg-red-950/40 dark:text-red-400",
  running: "bg-blue-50 text-blue-600 dark:bg-blue-950/40 dark:text-blue-400",
  // placement
  placed: "bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400",
  not_placed: "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300",
  higher_studies: "bg-indigo-50 text-indigo-600 dark:bg-indigo-950/40 dark:text-indigo-400",
  entrepreneur: "bg-purple-50 text-purple-600 dark:bg-purple-950/40 dark:text-purple-400",
  // iqac action plan
  planned: "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300",
  in_progress: "bg-blue-50 text-blue-600 dark:bg-blue-950/40 dark:text-blue-400",
  delayed: "bg-red-50 text-red-600 dark:bg-red-950/40 dark:text-red-400",
  // priority
  high: "bg-red-50 text-red-600 dark:bg-red-950/40 dark:text-red-400",
  medium: "bg-amber-50 text-amber-600 dark:bg-amber-950/40 dark:text-amber-400",
  low: "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300",
  // active
  active: "bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400",
  inactive: "bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400",
};

function labelize(value: string) {
  return value
    .split("_")
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(" ");
}

export default function StatusBadge({ status, className }: { status: string; className?: string }) {
  const style = STYLE_MAP[status] || "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300";
  return (
    <span
      className={cn(
        "inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold whitespace-nowrap",
        style,
        className
      )}
    >
      {labelize(status)}
    </span>
  );
}
