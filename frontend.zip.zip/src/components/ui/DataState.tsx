"use client";

import { motion } from "framer-motion";
import { Loader2, AlertTriangle, Inbox, RefreshCw } from "lucide-react";
import { LucideIcon } from "lucide-react";

export function LoadingState({ label = "Loading…" }: { label?: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-[var(--muted-foreground)]">
      <Loader2 className="w-6 h-6 animate-spin mb-3 text-blue-500" />
      <p className="text-sm">{label}</p>
    </div>
  );
}

export function ErrorState({
  message = "Something went wrong while loading data.",
  onRetry,
}: {
  message?: string;
  onRetry?: () => void;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col items-center justify-center py-16 text-center px-4"
    >
      <div className="w-12 h-12 rounded-2xl bg-red-50 dark:bg-red-950/40 flex items-center justify-center mb-3">
        <AlertTriangle className="w-6 h-6 text-red-500" />
      </div>
      <p className="text-sm text-[var(--foreground)] font-medium mb-1">Unable to load data</p>
      <p className="text-xs text-[var(--muted-foreground)] max-w-sm mb-4">{message}</p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="inline-flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-lg bg-[var(--muted)] hover:bg-[var(--secondary)] text-[var(--foreground)] transition"
        >
          <RefreshCw className="w-3.5 h-3.5" /> Retry
        </button>
      )}
    </motion.div>
  );
}

export function EmptyState({
  title = "Nothing here yet",
  message = "No records found.",
  icon: Icon = Inbox,
  action,
}: {
  title?: string;
  message?: string;
  icon?: LucideIcon;
  action?: React.ReactNode;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col items-center justify-center py-16 text-center px-4"
    >
      <div className="w-12 h-12 rounded-2xl bg-[var(--muted)] flex items-center justify-center mb-3">
        <Icon className="w-6 h-6 text-[var(--muted-foreground)]" />
      </div>
      <p className="text-sm text-[var(--foreground)] font-medium mb-1">{title}</p>
      <p className="text-xs text-[var(--muted-foreground)] max-w-sm mb-4">{message}</p>
      {action}
    </motion.div>
  );
}

export function InlineError({ message }: { message: string }) {
  return (
    <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 text-sm">
      {message}
    </div>
  );
}
