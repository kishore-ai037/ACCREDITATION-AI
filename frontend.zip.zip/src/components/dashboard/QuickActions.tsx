"use client";

import { motion } from "framer-motion";
import { useRouter } from "next/navigation";
import { Upload, Sparkles, FileSearch, Plus, Download, RefreshCw } from "lucide-react";

const actions = [
  { icon: Upload, label: "Upload Document", desc: "Add evidence files", color: "bg-blue-600 hover:bg-blue-700 text-white", shadow: "shadow-blue-600/30", href: "/dashboard/documents" },
  { icon: Sparkles, label: "AI Evidence Search", desc: "Auto-map to criteria", color: "bg-indigo-600 hover:bg-indigo-700 text-white", shadow: "shadow-indigo-600/30", href: "/dashboard/ai-search" },
  { icon: FileSearch, label: "Review Documents", desc: "Approve pending items", color: "bg-[var(--muted)] hover:bg-[var(--secondary)] text-[var(--foreground)]", shadow: "", href: "/dashboard/documents" },
  { icon: Plus, label: "New Report", desc: "Generate NAAC/NBA", color: "bg-[var(--muted)] hover:bg-[var(--secondary)] text-[var(--foreground)]", shadow: "", href: "/dashboard/reports" },
  { icon: Download, label: "Reports & Exports", desc: "Download generated files", color: "bg-[var(--muted)] hover:bg-[var(--secondary)] text-[var(--foreground)]", shadow: "", href: "/dashboard/reports" },
  { icon: RefreshCw, label: "Manage Faculty", desc: "Update faculty records", color: "bg-[var(--muted)] hover:bg-[var(--secondary)] text-[var(--foreground)]", shadow: "", href: "/dashboard/faculty" },
];

export default function QuickActions() {
  const router = useRouter();
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
      className="bg-[var(--card)] border border-[var(--border)] rounded-2xl p-5"
    >
      <div className="mb-4">
        <h3 className="font-semibold text-[var(--foreground)]">Quick Actions</h3>
        <p className="text-xs text-[var(--muted-foreground)] mt-0.5">Common tasks at a glance</p>
      </div>
      <div className="grid grid-cols-2 gap-2">
        {actions.map((a, i) => {
          const Icon = a.icon;
          return (
            <motion.button
              key={a.label}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.35 + i * 0.05 }}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => router.push(a.href)}
              className={`flex items-center gap-2.5 p-3 rounded-xl transition text-left ${a.color} ${a.shadow ? `shadow-lg ${a.shadow}` : ""}`}
            >
              <Icon className="w-4 h-4 shrink-0" />
              <div className="min-w-0">
                <div className="text-xs font-semibold leading-tight truncate">{a.label}</div>
                <div className="text-[10px] opacity-70 leading-tight mt-0.5 truncate">{a.desc}</div>
              </div>
            </motion.button>
          );
        })}
      </div>
    </motion.div>
  );
}
