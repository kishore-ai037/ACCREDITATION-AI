"use client";

import { useEffect, useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { useAuth } from "@/context/AuthContext";
import StatCardComponent from "./StatCard";
import NAACProgress from "./NAACProgress";
import RecentActivities from "./RecentActivities";
import QuickActions from "./QuickActions";
import DocumentTrendChart from "./DocumentTrendChart";
import { Sparkles, Clock, AlertCircle, Loader2 } from "lucide-react";
import { dashboardApi, DashboardSummary } from "@/lib/api";
import { getErrorMessage } from "@/lib/utils";
import { ErrorState } from "@/components/ui/DataState";
import { StatCard as StatCardType } from "@/types";

export default function DashboardHome() {
  const { user } = useAuth();
  const router = useRouter();
  const [summary, setSummary] = useState<DashboardSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(() => {
    setLoading(true);
    setError(null);
    dashboardApi
      .summary()
      .then(setSummary)
      .catch((err) => setError(getErrorMessage(err, "Could not load dashboard summary.")))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const now = new Date();
  const hour = now.getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";
  const firstName = user?.name?.split(" ")[0] || "there";

  const statCards: StatCardType[] = summary
    ? [
        {
          title: "NAAC Score",
          value: summary.naac_score !== null ? Number(summary.naac_score).toFixed(2) : "—",
          change: 0,
          changeLabel: summary.institution?.naac_grade ? `Grade ${summary.institution.naac_grade}` : "current cycle",
          icon: "Award",
          color: "blue",
        },
        {
          title: "Documents Uploaded",
          value: summary.documents?.total ?? 0,
          change: 0,
          changeLabel: `${summary.documents?.approved ?? 0} approved`,
          icon: "FileText",
          color: "indigo",
        },
        {
          title: "Criteria Completed",
          value: `${Math.round(summary.naac_completion_pct)}%`,
          change: 0,
          changeLabel: "of NAAC criteria",
          icon: "CheckCircle2",
          color: "emerald",
        },
        {
          title: "Pending Reviews",
          value: summary.pending_reviews,
          change: 0,
          changeLabel: "documents awaiting review",
          icon: "ClipboardList",
          color: "amber",
        },
      ]
    : [];

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto flex items-center justify-center py-24">
        <Loader2 className="w-6 h-6 animate-spin text-blue-500" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-7xl mx-auto">
        <ErrorState message={error} onRetry={load} />
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Welcome header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col sm:flex-row sm:items-center justify-between gap-4"
      >
        <div>
          <h1 className="text-xl font-bold text-[var(--foreground)]">
            {greeting}, {firstName} 👋
          </h1>
          <p className="text-sm text-[var(--muted-foreground)] mt-0.5">
            {summary?.institution?.name || user?.institution} · {new Date().toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {summary?.institution?.naac_grade && (
            <div className="flex items-center gap-1.5 text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800/50 px-3 py-1.5 rounded-xl text-xs font-medium">
              <Clock className="w-3.5 h-3.5" />
              NAAC Grade {summary.institution.naac_grade}
            </div>
          )}
          {summary && summary.pending_reviews > 0 && (
            <div className="flex items-center gap-1.5 text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800/50 px-3 py-1.5 rounded-xl text-xs font-medium">
              <AlertCircle className="w-3.5 h-3.5" />
              {summary.pending_reviews} document{summary.pending_reviews === 1 ? "" : "s"} pending review
            </div>
          )}
        </div>
      </motion.div>

      {/* AI banner */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="relative overflow-hidden bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl p-5 text-white"
      >
        <div className="absolute top-0 right-0 w-64 h-full opacity-10">
          <div className="w-48 h-48 rounded-full bg-white absolute -top-10 -right-10" />
          <div className="w-32 h-32 rounded-full bg-white absolute bottom-0 right-16" />
        </div>
        <div className="relative flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Sparkles className="w-4 h-4" />
              <span className="text-xs font-semibold uppercase tracking-wider opacity-80">AI Insight</span>
            </div>
            <p className="font-semibold text-sm leading-relaxed max-w-lg">
              Run AI Evidence Search to automatically map untagged documents to NAAC and NBA criteria.
            </p>
          </div>
          <button
            onClick={() => router.push("/dashboard/ai-search")}
            className="shrink-0 bg-white text-blue-600 font-semibold text-sm px-4 py-2 rounded-xl hover:bg-blue-50 transition whitespace-nowrap"
          >
            Review & Map →
          </button>
        </div>
      </motion.div>

      {/* Stat cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {statCards.map((card, i) => (
          <StatCardComponent key={card.title} card={card} index={i} />
        ))}
      </div>

      {/* Main grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Chart + Activities */}
        <div className="lg:col-span-2 space-y-4">
          <DocumentTrendChart />
          <RecentActivities />
        </div>

        {/* Sidebar widgets */}
        <div className="space-y-4">
          <QuickActions />
          <NAACProgress />
        </div>
      </div>
    </div>
  );
}
