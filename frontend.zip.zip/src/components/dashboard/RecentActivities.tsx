"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Upload, CheckCircle, AlertTriangle, Eye, MessageSquare, Loader2, XCircle, Plus, Trash2, Sparkles } from "lucide-react";
import { cn, timeAgo } from "@/lib/utils";
import { dashboardApi, RecentActivityItem } from "@/lib/api";
import { EmptyState } from "@/components/ui/DataState";

const typeConfig: Record<string, { icon: React.FC<{ className?: string }>; color: string }> = {
  upload: { icon: Upload, color: "bg-blue-100 text-blue-600 dark:bg-blue-950/50 dark:text-blue-400" },
  approve: { icon: CheckCircle, color: "bg-emerald-100 text-emerald-600 dark:bg-emerald-950/50 dark:text-emerald-400" },
  reject: { icon: XCircle, color: "bg-red-100 text-red-600 dark:bg-red-950/50 dark:text-red-400" },
  review: { icon: Eye, color: "bg-indigo-100 text-indigo-600 dark:bg-indigo-950/50 dark:text-indigo-400" },
  comment: { icon: MessageSquare, color: "bg-purple-100 text-purple-600 dark:bg-purple-950/50 dark:text-purple-400" },
  create: { icon: Plus, color: "bg-blue-100 text-blue-600 dark:bg-blue-950/50 dark:text-blue-400" },
  update: { icon: Eye, color: "bg-indigo-100 text-indigo-600 dark:bg-indigo-950/50 dark:text-indigo-400" },
  delete: { icon: Trash2, color: "bg-red-100 text-red-600 dark:bg-red-950/50 dark:text-red-400" },
  ai_map: { icon: Sparkles, color: "bg-indigo-100 text-indigo-600 dark:bg-indigo-950/50 dark:text-indigo-400" },
  login: { icon: CheckCircle, color: "bg-emerald-100 text-emerald-600 dark:bg-emerald-950/50 dark:text-emerald-400" },
  logout: { icon: AlertTriangle, color: "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300" },
};

export default function RecentActivities() {
  const [activities, setActivities] = useState<RecentActivityItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    dashboardApi
      .recentActivity(10)
      .then(setActivities)
      .catch(() => setActivities([]))
      .finally(() => setLoading(false));
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.4 }}
      className="bg-[var(--card)] border border-[var(--border)] rounded-2xl p-5"
    >
      <div className="flex items-center justify-between mb-5">
        <div>
          <h3 className="font-semibold text-[var(--foreground)]">Recent Activity</h3>
          <p className="text-xs text-[var(--muted-foreground)] mt-0.5">System-wide updates</p>
        </div>
      </div>
      {loading ? (
        <div className="flex justify-center py-8">
          <Loader2 className="w-5 h-5 animate-spin text-[var(--muted-foreground)]" />
        </div>
      ) : activities.length === 0 ? (
        <EmptyState title="No activity yet" message="Actions across the platform will show up here." />
      ) : (
        <div className="space-y-3">
          {activities.map((act, i) => {
            const config = typeConfig[act.action] || typeConfig.update;
            const Icon = config.icon;
            return (
              <motion.div
                key={act.id}
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.45 + i * 0.05 }}
                className="flex gap-3 p-3 rounded-xl hover:bg-[var(--muted)] transition group"
              >
                <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center shrink-0", config.color)}>
                  <Icon className="w-3.5 h-3.5" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-xs text-[var(--foreground)] leading-relaxed">
                    <span className="font-semibold">{act.user_name}</span>{" "}
                    <span className="text-[var(--muted-foreground)]">{act.description}</span>
                  </p>
                  <p className="text-[10px] text-[var(--muted-foreground)] mt-0.5">{timeAgo(act.created_at)}</p>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </motion.div>
  );
}
