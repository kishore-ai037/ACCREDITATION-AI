"use client";

import { motion } from "framer-motion";
import {
  Award, FileText, CheckCircle2, ClipboardList,
  TrendingUp, TrendingDown,
} from "lucide-react";
import { StatCard } from "@/types";
import { cn } from "@/lib/utils";

const iconMap: Record<string, React.FC<{ className?: string }>> = {
  Award, FileText, CheckCircle2, ClipboardList,
};

const colorMap: Record<string, { bg: string; icon: string; trend: string }> = {
  blue: {
    bg: "from-blue-500 to-blue-600",
    icon: "text-blue-500",
    trend: "bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400",
  },
  indigo: {
    bg: "from-indigo-500 to-indigo-600",
    icon: "text-indigo-500",
    trend: "bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400",
  },
  emerald: {
    bg: "from-emerald-500 to-emerald-600",
    icon: "text-emerald-500",
    trend: "bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400",
  },
  amber: {
    bg: "from-amber-500 to-amber-600",
    icon: "text-amber-500",
    trend: "bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400",
  },
};

interface StatCardProps {
  card: StatCard;
  index: number;
}

export default function StatCardComponent({ card, index }: StatCardProps) {
  const Icon = iconMap[card.icon] || Award;
  const colors = colorMap[card.color] || colorMap.blue;
  const isPositive = card.change > 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.08, duration: 0.4 }}
      className="bg-[var(--card)] border border-[var(--border)] rounded-2xl p-5 hover:shadow-lg hover:shadow-blue-900/5 transition-all group"
    >
      <div className="flex items-start justify-between mb-4">
        <div className={cn("w-11 h-11 rounded-xl bg-gradient-to-br flex items-center justify-center shadow-lg", colors.bg)}>
          <Icon className="w-5 h-5 text-white" />
        </div>
        {card.change !== 0 && (
          <span
            className={cn(
              "flex items-center gap-1 text-xs font-semibold px-2 py-1 rounded-lg",
              colors.trend
            )}
          >
            {isPositive ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
            {isPositive ? "+" : ""}{card.change}%
          </span>
        )}
      </div>
      <div className="text-2xl font-bold text-[var(--foreground)] mb-1">{card.value}</div>
      <div className="text-sm font-medium text-[var(--foreground)] opacity-80">{card.title}</div>
      <div className="text-xs text-[var(--muted-foreground)] mt-0.5">{card.changeLabel}</div>
    </motion.div>
  );
}
