"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, Legend,
} from "recharts";
import { Loader2 } from "lucide-react";
import { dashboardApi, DocumentTrendPoint } from "@/lib/api";
import { EmptyState } from "@/components/ui/DataState";

export default function DocumentTrendChart() {
  const [data, setData] = useState<DocumentTrendPoint[]>([]);
  const [loading, setLoading] = useState(true);
  const [months, setMonths] = useState(6);

  useEffect(() => {
    setLoading(true);
    dashboardApi
      .documentTrend(months)
      .then(setData)
      .catch(() => setData([]))
      .finally(() => setLoading(false));
  }, [months]);

  const hasData = data.some((d) => d.uploaded > 0 || d.reviewed > 0);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.25 }}
      className="bg-[var(--card)] border border-[var(--border)] rounded-2xl p-5"
    >
      <div className="flex items-center justify-between mb-5">
        <div>
          <h3 className="font-semibold text-[var(--foreground)]">Document Activity</h3>
          <p className="text-xs text-[var(--muted-foreground)] mt-0.5">Uploads vs. reviewed</p>
        </div>
        <select
          value={months}
          onChange={(e) => setMonths(Number(e.target.value))}
          className="text-xs border border-[var(--border)] bg-[var(--muted)] text-[var(--foreground)] rounded-lg px-2 py-1 focus:outline-none"
        >
          <option value={6}>Last 6 months</option>
          <option value={12}>Last year</option>
        </select>
      </div>
      <div className="h-48 flex items-center justify-center">
        {loading ? (
          <Loader2 className="w-5 h-5 animate-spin text-[var(--muted-foreground)]" />
        ) : !hasData ? (
          <EmptyState title="No document activity yet" message="Upload and review documents to see trends here." />
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
              <defs>
                <linearGradient id="uploadGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="reviewGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} allowDecimals={false} />
              <Tooltip
                contentStyle={{
                  background: "var(--card)",
                  border: "1px solid var(--border)",
                  borderRadius: 12,
                  fontSize: 12,
                  color: "var(--foreground)",
                }}
              />
              <Legend wrapperStyle={{ fontSize: 11, color: "var(--muted-foreground)" }} />
              <Area type="monotone" dataKey="uploaded" name="Uploaded" stroke="#3b82f6" strokeWidth={2} fill="url(#uploadGrad)" dot={false} />
              <Area type="monotone" dataKey="reviewed" name="Reviewed" stroke="#6366f1" strokeWidth={2} fill="url(#reviewGrad)" dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        )}
      </div>
    </motion.div>
  );
}
