"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { criteriaApi, NaacCriteria } from "@/lib/api";
import { EmptyState } from "@/components/ui/DataState";

function getColor(val: number) {
  if (val >= 80) return "bg-emerald-500";
  if (val >= 60) return "bg-blue-500";
  if (val >= 40) return "bg-amber-500";
  return "bg-red-500";
}

function getLabel(val: number) {
  if (val >= 80) return "text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40";
  if (val >= 60) return "text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/40";
  if (val >= 40) return "text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40";
  return "text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950/40";
}

export default function NAACProgress() {
  const [criteria, setCriteria] = useState<NaacCriteria[]>([]);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    criteriaApi
      .naacOverview()
      .then((r) => setCriteria(r.criteria.slice(0, 7)))
      .catch(() => setCriteria([]))
      .finally(() => setLoading(false));
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.35 }}
      className="bg-[var(--card)] border border-[var(--border)] rounded-2xl p-5"
    >
      <div className="flex items-center justify-between mb-5">
        <div>
          <h3 className="font-semibold text-[var(--foreground)]">NAAC Criteria Progress</h3>
          <p className="text-xs text-[var(--muted-foreground)] mt-0.5">Current accreditation cycle</p>
        </div>
        <button
          onClick={() => router.push("/dashboard/naac")}
          className="text-xs bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 px-2.5 py-1 rounded-lg font-medium hover:bg-blue-100 dark:hover:bg-blue-900/40 transition"
        >
          View all →
        </button>
      </div>
      {loading ? (
        <div className="flex justify-center py-8">
          <Loader2 className="w-5 h-5 animate-spin text-[var(--muted-foreground)]" />
        </div>
      ) : criteria.length === 0 ? (
        <EmptyState title="No NAAC criteria yet" message="Add criteria on the NAAC page to track progress." />
      ) : (
        <div className="space-y-4">
          {criteria.map((c, i) => (
            <motion.div
              key={c.id}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 + i * 0.05 }}
            >
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-2 min-w-0">
                  <span className="text-[10px] font-bold w-7 h-5 bg-[var(--muted)] rounded text-[var(--muted-foreground)] flex items-center justify-center shrink-0">
                    {c.criterion_no}
                  </span>
                  <span className="text-xs text-[var(--foreground)] font-medium truncate">{c.criterion_name}</span>
                </div>
                <span className={cn("text-[10px] font-bold px-2 py-0.5 rounded-full shrink-0", getLabel(c.completion_pct))}>
                  {Math.round(c.completion_pct)}%
                </span>
              </div>
              <div className="h-2 bg-[var(--muted)] rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${c.completion_pct}%` }}
                  transition={{ delay: 0.5 + i * 0.05, duration: 0.6, ease: "easeOut" }}
                  className={cn("h-full rounded-full", getColor(c.completion_pct))}
                />
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </motion.div>
  );
}
