"use client";

import { FileText, Image as ImageIcon, FileWarning, ExternalLink, Download } from "lucide-react";
import Modal from "@/components/ui/Modal";
import StatusBadge from "@/components/ui/StatusBadge";
import { AppDocument } from "@/lib/api/types";
import { getDocumentDownloadUrl } from "@/lib/api/documents";
import { formatFileSize, formatDate } from "@/lib/utils";

interface DocumentPreviewModalProps {
  document: AppDocument | null;
  open: boolean;
  onClose: () => void;
}

type PreviewKind = "pdf" | "image" | "word" | "unsupported";

function getPreviewKind(doc: AppDocument): PreviewKind {
  const type = (doc.file_type || "").toLowerCase();
  const name = (doc.file_name || "").toLowerCase();

  if (type === "application/pdf" || name.endsWith(".pdf")) return "pdf";
  if (type.startsWith("image/") || /\.(png|jpe?g|webp|gif)$/.test(name)) return "image";
  if (
    type.includes("msword") ||
    type.includes("wordprocessingml") ||
    name.endsWith(".doc") ||
    name.endsWith(".docx")
  ) {
    return "word";
  }
  return "unsupported";
}

/**
 * DocumentPreviewModal
 *
 * Read-only preview surface for a single document. Reuses the existing
 * `Modal`, `StatusBadge`, and formatting helpers so it matches the rest of
 * the app's design system. Does not call any new APIs, does not touch
 * upload logic, and does not modify existing Documents page behavior on
 * its own — it is wired in separately as an additional "Preview" action.
 */
export default function DocumentPreviewModal({ document, open, onClose }: DocumentPreviewModalProps) {
  if (!document) {
    return (
      <Modal open={open} onClose={onClose} title="Document Preview" maxWidth="max-w-3xl">
        <div />
      </Modal>
    );
  }

  const kind = getPreviewKind(document);
  const fileUrl = getDocumentDownloadUrl(document);

  return (
    <Modal open={open} onClose={onClose} title={document.title} subtitle="Document preview" maxWidth="max-w-3xl">
      <div className="space-y-4">
        {/* Metadata */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div>
            <span className="text-[var(--muted-foreground)]">Status</span>
            <div className="mt-1">
              <StatusBadge status={document.status} />
            </div>
          </div>
          <div>
            <span className="text-[var(--muted-foreground)]">File Size</span>
            <div className="text-[var(--foreground)] font-medium mt-1">{formatFileSize(document.file_size)}</div>
          </div>
          <div>
            <span className="text-[var(--muted-foreground)]">Uploaded By</span>
            <div className="text-[var(--foreground)] font-medium mt-1 truncate">
              {document.uploaded_by_name || "—"}
            </div>
          </div>
          <div>
            <span className="text-[var(--muted-foreground)]">Uploaded On</span>
            <div className="text-[var(--foreground)] font-medium mt-1">{formatDate(document.created_at)}</div>
          </div>
          {document.criterion_type && (
            <div className="col-span-2 sm:col-span-4">
              <span className="text-[var(--muted-foreground)]">Criterion</span>
              <div className="text-[var(--foreground)] font-medium mt-1 uppercase">
                {document.criterion_type} {document.criterion_ref}
              </div>
            </div>
          )}
        </div>

        {/* Preview area */}
        <div className="rounded-xl border border-[var(--border)] bg-[var(--muted)] overflow-hidden">
          {!fileUrl ? (
            <div className="flex flex-col items-center justify-center gap-2 text-center p-10">
              <FileWarning className="w-8 h-8 text-[var(--muted-foreground)]" />
              <p className="text-sm font-medium text-[var(--foreground)]">Preview unavailable</p>
              <p className="text-xs text-[var(--muted-foreground)] max-w-xs">
                The file location for this document could not be resolved.
              </p>
            </div>
          ) : kind === "pdf" ? (
            <iframe
              src={fileUrl}
              title={document.title}
              className="w-full h-[60vh] sm:h-[65vh] bg-white"
            />
          ) : kind === "image" ? (
            <div className="flex items-center justify-center p-4 max-h-[65vh] overflow-auto">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={fileUrl}
                alt={document.title}
                className="max-w-full max-h-[60vh] object-contain rounded-lg"
              />
            </div>
          ) : kind === "word" ? (
            <div className="flex flex-col items-center justify-center gap-3 text-center p-10">
              <FileText className="w-8 h-8 text-blue-500" />
              <p className="text-sm font-medium text-[var(--foreground)]">
                Word documents can&apos;t be previewed inline.
              </p>
              <p className="text-xs text-[var(--muted-foreground)] max-w-xs">
                Open or download the file to view its contents.
              </p>
              <a
                href={fileUrl}
                target="_blank"
                rel="noopener noreferrer"
                download={document.file_name}
                className="inline-flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold px-4 py-2 rounded-xl transition"
              >
                <Download className="w-3.5 h-3.5" /> Open / Download
              </a>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center gap-2 text-center p-10">
              <ImageIcon className="w-8 h-8 text-[var(--muted-foreground)]" />
              <p className="text-sm font-medium text-[var(--foreground)]">Preview not supported</p>
              <p className="text-xs text-[var(--muted-foreground)] max-w-xs">
                This file type can&apos;t be previewed here. You can still open or download it directly.
              </p>
              <a
                href={fileUrl}
                target="_blank"
                rel="noopener noreferrer"
                download={document.file_name}
                className="inline-flex items-center gap-1.5 text-xs font-semibold px-4 py-2 rounded-xl border border-[var(--border)] text-[var(--foreground)] hover:bg-[var(--card)] transition"
              >
                <ExternalLink className="w-3.5 h-3.5" /> Open File
              </a>
            </div>
          )}
        </div>
      </div>
    </Modal>
  );
}
