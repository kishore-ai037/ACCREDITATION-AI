import React, { useState } from 'react';

export default function SplitScreenDocuments() {
  const [selectedCriteria, setSelectedCriteria] = useState('3.3.1');
  const [aiAnalysis, setAiAnalysis] = useState({
    docType: 'NAAC Evidence',
    academicYear: '2025-2026',
    metadata: 'Faculty Name: Dr. Anitha K., Dept: CSE',
    gapWarning: 'AI Notice: Missing Controller of Examination Signature on Page 2'
  });

  return (
    <div className="flex h-screen bg-[#0f172a] text-white overflow-hidden">
      {/* LEFT SIDE PANEL: The Evidence Viewer */}
      <div className="w-1/2 border-r border-slate-700 p-4 flex flex-col justify-center items-center bg-[#1e293b]">
        <div className="text-slate-400 mb-2 font-medium">📄 Evidence Document Viewer</div>
        <div className="w-full h-full border-2 border-dashed border-slate-600 rounded-lg flex items-center justify-center bg-[#0f172a] p-4 text-center">
          <span className="text-slate-500">
            [ Live Document PDF / Image Render Area ] <br />
            <span className="text-xs text-slate-600">Faculty can scroll and check the original upload here</span>
          </span>
        </div>
      </div>

      {/* RIGHT SIDE PANEL: The AI Extraction Suite */}
      <div className="w-1/2 p-6 flex flex-col justify-between bg-[#0f172a]">
        <div>
          <h2 className="text-xl font-bold mb-6 text-blue-400">🤖 AI Extraction Workspace</h2>
          
          {/* Document Type Dropdown */}
          <div className="mb-4">
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Document Type</label>
            <select className="w-full bg-[#1e293b] border border-slate-700 rounded p-2 text-sm focus:outline-none focus:border-blue-500">
              <option>{aiAnalysis.docType}</option>
              <option>NBA Evidence</option>
              <option>Internal Marks Sheet</option>
            </select>
          </div>

          {/* AI Suggested Mapping Panel */}
          <div className="bg-[#1e293b] p-4 rounded-lg border border-slate-700 mb-4">
            <div className="text-xs font-semibold text-blue-400 uppercase tracking-wider mb-3">🎯 AI Suggested Mapping</div>
            
            <div className="mb-3">
              <label className="block text-xs text-slate-400 mb-1">Course / Clause Alignment</label>
              <select 
                value={selectedCriteria} 
                onChange={(e) => setSelectedCriteria(e.target.value)}
                className="w-full bg-[#0f172a] border border-slate-700 rounded p-2 text-sm text-slate-200"
              >
                <option value="3.3.1">Criterion 3.3.1 (Publications Logs)</option>
                <option value="PO1">NBA PO1 (Engineering Knowledge)</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3 mb-2">
              <div>
                <label className="block text-xs text-slate-400 mb-1">Academic Year</label>
                <input type="text" value={aiAnalysis.academicYear} readOnly className="w-full bg-[#0f172a] border border-slate-700 rounded p-2 text-sm text-slate-300" />
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1">Extracted Metadata</label>
                <input type="text" value="Auto-Verified" readOnly className="w-full bg-[#0f172a] border border-slate-700 rounded p-2 text-sm text-emerald-400" />
              </div>
            </div>
            <p className="text-xs text-slate-400 mt-2 italic">{aiAnalysis.metadata}</p>
          </div>

          {/* Data Gap Analysis Section */}
          <div className="bg-amber-950/40 border border-amber-800/60 p-4 rounded-lg">
            <div className="text-xs font-semibold text-amber-400 uppercase tracking-wider mb-1">⚠️ Data Gap Check</div>
            <p className="text-sm text-amber-200/90">{aiAnalysis.gapWarning}</p>
          </div>
        </div>

        {/* Form Interactive Action Buttons */}
        <div className="border-t border-slate-800 pt-4 flex gap-4">
          <button className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-medium py-2.5 px-4 rounded transition-colors">
            ✏️ Modify Fields
          </button>
          <button className="flex-1 bg-rose-950 hover:bg-rose-900 border border-rose-800 text-rose-200 text-sm font-medium py-2.5 px-4 rounded transition-colors">
            ❌ Reject with Comments
          </button>
          <button className="flex-1 bg-blue-600 hover:bg-blue-500 text-white text-sm font-medium py-2.5 px-4 rounded transition-colors shadow-lg shadow-blue-600/20">
            👍 Confirm & Push
          </button>
        </div>
      </div>
    </div>
  );
}