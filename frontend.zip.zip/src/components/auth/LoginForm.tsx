"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { Eye, EyeOff, Sparkles, ShieldCheck, ArrowRight, Loader2 } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { UserRole } from "@/types";

const ROLES: { label: string; value: UserRole; desc: string }[] = [
  { label: "Admin / Principal", value: "admin", desc: "Full system access" },
  { label: "IQAC Coordinator", value: "iqac_coordinator", desc: "Quality assurance oversight" },
  { label: "Head of Department", value: "hod", desc: "Departmental management" },
  { label: "Faculty", value: "faculty", desc: "Document upload & review" },
];

const DEMO_CREDS: Record<UserRole, string> = {
  admin: "admin@accredi.ai",
  iqac_coordinator: "iqac@accredi.ai",
  hod: "hod@accredi.ai",
  faculty: "faculty@accredi.ai",
  principal: "admin@accredi.ai",
  student: "faculty@accredi.ai",
};
const DEMO_PASSWORD = "Admin@123";

export default function LoginForm() {
  const { login } = useAuth();
  const router = useRouter();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<UserRole>("admin");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const fillDemo = () => {
    setEmail(DEMO_CREDS[role]);
    setPassword(DEMO_PASSWORD);
    setError("");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    const result = await login(email, password);
    setLoading(false);
    if (result.ok) {
      router.push("/dashboard");
    } else {
      setError(result.error || "Invalid credentials. Use the demo button to auto-fill.");
    }
  };

  return (
    <div className="min-h-screen flex">
      {/* Left panel */}
      <div className="hidden lg:flex flex-col justify-between w-[52%] bg-[#0f172a] p-12 relative overflow-hidden">
        {/* Decorative blobs */}
        <div className="absolute top-[-80px] left-[-80px] w-[400px] h-[400px] rounded-full bg-blue-600/20 blur-3xl pointer-events-none" />
        <div className="absolute bottom-[-60px] right-[-60px] w-[300px] h-[300px] rounded-full bg-indigo-500/20 blur-3xl pointer-events-none" />

        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-16">
            <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center">
              <ShieldCheck className="w-6 h-6 text-white" />
            </div>
            <span className="text-white text-xl font-bold tracking-tight">AccrediAI</span>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: "easeOut" }}
          >
            <h1 className="text-4xl font-bold text-white leading-tight mb-5">
              Accreditation,<br />
              <span className="text-blue-400">reimagined</span> with AI.
            </h1>
            <p className="text-slate-400 text-lg leading-relaxed max-w-md">
              Streamline NAAC, NBA, and IQAC processes with intelligent evidence mapping, automated gap analysis, and real-time compliance tracking.
            </p>
          </motion.div>
        </div>

        <div className="relative z-10 grid grid-cols-2 gap-4">
          {[
            { label: "Documents Managed", value: "1.2L+" },
            { label: "Institutions", value: "340+" },
            { label: "NAAC A+ Outcomes", value: "87%" },
            { label: "Hours Saved / Cycle", value: "2,400+" },
          ].map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 + i * 0.1 }}
              className="bg-white/5 border border-white/10 rounded-xl p-4"
            >
              <div className="text-2xl font-bold text-white">{s.value}</div>
              <div className="text-slate-400 text-sm mt-0.5">{s.label}</div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Right panel */}
      <div className="flex-1 flex items-center justify-center p-6 bg-[var(--background)]">
        <motion.div
          initial={{ opacity: 0, scale: 0.97 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-md"
        >
          {/* Mobile logo */}
          <div className="flex lg:hidden items-center gap-2 mb-8">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5 text-white" />
            </div>
            <span className="text-[var(--foreground)] font-bold text-lg">AccrediAI</span>
          </div>

          <div className="mb-8">
            <h2 className="text-2xl font-bold text-[var(--foreground)]">Welcome back</h2>
            <p className="text-[var(--muted-foreground)] mt-1 text-sm">Sign in to your institution portal</p>
          </div>

          {/* Role selector */}
          <div className="mb-6">
            <label className="block text-xs font-semibold text-[var(--muted-foreground)] uppercase tracking-wider mb-2">
              Sign in as
            </label>
            <div className="grid grid-cols-2 gap-2">
              {ROLES.map((r) => (
                <button
                  key={r.value}
                  type="button"
                  onClick={() => { setRole(r.value); setError(""); }}
                  className={`text-left p-3 rounded-xl border text-sm transition-all ${
                    role === r.value
                      ? "border-blue-500 bg-blue-50 dark:bg-blue-950/50 text-blue-700 dark:text-blue-300"
                      : "border-[var(--border)] bg-[var(--card)] text-[var(--foreground)] hover:border-blue-300"
                  }`}
                >
                  <div className="font-medium leading-tight">{r.label}</div>
                  <div className="text-[10px] mt-0.5 opacity-60">{r.desc}</div>
                </button>
              ))}
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-[var(--foreground)] mb-1.5">
                Email address
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@institution.ac.in"
                required
                className="w-full px-4 py-2.5 rounded-xl border border-[var(--border)] bg-[var(--card)] text-[var(--foreground)] placeholder:text-[var(--muted-foreground)] focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition text-sm"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-[var(--foreground)] mb-1.5">
                Password
              </label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  className="w-full px-4 py-2.5 pr-10 rounded-xl border border-[var(--border)] bg-[var(--card)] text-[var(--foreground)] placeholder:text-[var(--muted-foreground)] focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition text-sm"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[var(--muted-foreground)] hover:text-[var(--foreground)] transition"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <AnimatePresence>
              {error && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="p-3 rounded-xl bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 text-sm"
                >
                  {error}
                </motion.div>
              )}
            </AnimatePresence>

            <div className="flex items-center justify-between text-sm">
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" className="rounded" />
                <span className="text-[var(--muted-foreground)]">Remember me</span>
              </label>
              <button type="button" className="text-blue-600 hover:text-blue-700 font-medium transition">
                Forgot password?
              </button>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white font-semibold rounded-xl transition flex items-center justify-center gap-2 shadow-lg shadow-blue-600/25"
            >
              {loading ? (
                <><Loader2 className="w-4 h-4 animate-spin" /> Signing in…</>
              ) : (
                <>Sign in <ArrowRight className="w-4 h-4" /></>
              )}
            </button>

            <button
              type="button"
              onClick={fillDemo}
              className="w-full py-2.5 px-4 border border-[var(--border)] bg-[var(--card)] text-[var(--foreground)] font-medium rounded-xl transition hover:bg-[var(--muted)] flex items-center justify-center gap-2 text-sm"
            >
              <Sparkles className="w-4 h-4 text-blue-500" />
              Auto-fill demo credentials
            </button>
          </form>

          <p className="mt-6 text-center text-xs text-[var(--muted-foreground)]">
            Protected by AccrediAI Security · ISO 27001 Compliant
          </p>
        </motion.div>
      </div>
    </div>
  );
}
