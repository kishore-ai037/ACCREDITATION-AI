#!/usr/bin/env node
/**
 * build-phase2.js
 * AccrediAI – Phase 2: Faculty Profiles & Document Upload
 *
 * Run from project root:
 *   node build-phase2.js
 *
 * Assumes Phase 0 foundation exists:
 *   src/config/database.ts   → pool export + query/queryOne/queryMany helpers
 *   src/middleware/auth.ts   → authenticate (sets req.user)
 *   src/middleware/rbac.ts   → authorize(...roles)
 *   src/middleware/validate.ts → validationResult guard
 *   src/utils/response.ts    → sendSuccess / sendCreated / sendError / sendNotFound
 *   src/utils/AppError.ts    → class AppError extends Error
 *   src/utils/pagination.ts  → parsePagination / buildPaginatedResponse
 *   src/utils/upload.ts      → multer instance exported as `upload`
 */

const fs   = require('fs');
const path = require('path');

// ── helpers ───────────────────────────────────────────────────────────────────

function write(relPath, content) {
  const abs = path.join(__dirname, relPath);
  fs.mkdirSync(path.dirname(abs), { recursive: true });
  fs.writeFileSync(abs, content.trimStart(), 'utf8');
  console.log(`  ✓  ${relPath}`);
}

console.log('\n🚀  AccrediAI – Phase 2: Faculty & Documents\n');

// ══════════════════════════════════════════════════════════════════════════════
// 1.  backend/src/models/faculty.model.ts
// ══════════════════════════════════════════════════════════════════════════════

write('backend/src/models/faculty.model.ts', `
import { PoolClient } from 'pg';
import { query, queryOne, queryMany } from '../config/database';
import { AppError } from '../utils/AppError';

// ── Name-format constants ────────────────────────────────────────────────────
// Acceptable pattern:  [Salutation] [First Name] [Last Name] [Initial]
// Salutations         : Dr. | Prof. | Mr. | Mrs. | Ms. | Er.
// First / Last name   : 2-40 alpha chars (unicode letters allowed)
// Initials (optional) : one or more single-letters each followed by a dot

export const SALUTATIONS = ['Dr.', 'Prof.', 'Mr.', 'Mrs.', 'Ms.', 'Er.'] as const;
export type  Salutation   = typeof SALUTATIONS[number];

export const FACULTY_NAME_REGEX =
  /^(Dr\\.|Prof\\.|Mr\\.|Mrs\\.|Ms\\.|Er\\.)\\s[A-Za-z]{2,40}\\s[A-Za-z]{2,40}(\\s[A-Z]\\.)?(\\s[A-Z]\\.)*$/u;

export type EmploymentType = 'permanent' | 'contract' | 'visiting' | 'adjunct';
export type Designation =
  | 'Professor'
  | 'Associate Professor'
  | 'Assistant Professor'
  | 'Senior Lecturer'
  | 'Lecturer'
  | 'Lab Instructor';

export interface FacultyRow {
  id: string;
  user_id: string;
  institution_id: string;
  department_id: string | null;
  employee_code: string | null;
  salutation: Salutation;
  full_name: string;                // stored canonical form
  first_name: string;
  last_name: string;
  initials: string | null;
  gender: 'male' | 'female' | 'other' | null;
  date_of_birth: Date | null;
  date_of_joining: Date | null;
  designation: Designation;
  employment_type: EmploymentType;
  qualification: string | null;
  specialization: string | null;
  experience_years: number;         // total teaching
  industry_exp_years: number;
  experience_log: ExperienceEntry[];
  ugc_net: boolean;
  gate_score: number | null;
  phd_guide: boolean;
  phd_students_guided: number;
  publications_count: number;
  patents_count: number;
  awards_count: number;
  fdp_attended: number;
  fdp_organized: number;
  orcid_id: string | null;
  scopus_id: string | null;
  google_scholar_url: string | null;
  profile_complete: boolean;
  profile_pct: number;
  avatar_url: string | null;
  is_active: boolean;
  created_at: Date;
  updated_at: Date;
}

export interface ExperienceEntry {
  institution: string;
  designation: string;
  from_date: string;     // ISO date string
  to_date: string | null;
  is_current: boolean;
  years: number;         // computed on insert/update
}

// ── helpers ───────────────────────────────────────────────────────────────────

/** Parse a canonical name string → components. Throws if format invalid. */
export function parseFacultyName(raw: string): {
  salutation: Salutation;
  firstName: string;
  lastName: string;
  initials: string | null;
} {
  const trimmed = raw.trim().replace(/\\s+/g, ' ');
  if (!FACULTY_NAME_REGEX.test(trimmed)) {
    throw new AppError(
      'Name must follow the format: [Salutation] [First Name] [Last Name] [Initial(s)]. ' +
      'Valid salutations: Dr. Prof. Mr. Mrs. Ms. Er.',
      422
    );
  }
  const parts = trimmed.split(' ');
  const salutation = parts[0] as Salutation;
  const firstName  = parts[1];
  const lastName   = parts[2];
  const initials   = parts.slice(3).join(' ') || null;
  return { salutation, firstName, lastName, initials };
}

/** Derive canonical full_name from parts. */
export function buildFullName(
  salutation: Salutation,
  firstName: string,
  lastName: string,
  initials: string | null
): string {
  return [salutation, firstName, lastName, initials]
    .filter(Boolean)
    .join(' ');
}

/** Compute total years from experience_log entries. */
export function computeTotalExperience(log: ExperienceEntry[]): number {
  return log.reduce((sum, e) => {
    const from = new Date(e.from_date).getTime();
    const to   = e.is_current
      ? Date.now()
      : e.to_date
        ? new Date(e.to_date).getTime()
        : Date.now();
    const years = Math.max(0, (to - from) / (1000 * 60 * 60 * 24 * 365.25));
    return sum + years;
  }, 0);
}

/** Compute profile completion percentage based on key fields present. */
function computeProfilePct(data: Partial<FacultyRow>): number {
  const fields: (keyof FacultyRow)[] = [
    'employee_code', 'gender', 'date_of_birth', 'date_of_joining',
    'qualification', 'specialization', 'ugc_net', 'orcid_id',
    'google_scholar_url', 'avatar_url',
  ];
  const filled = fields.filter(f => data[f] != null && data[f] !== '').length;
  const base   = 50; // name/dept always present
  return Math.round(base + (filled / fields.length) * 50);
}

// ── SQL helpers ───────────────────────────────────────────────────────────────

const SELECT_FACULTY = \`
  SELECT f.*,
         u.email,
         u.phone,
         u.is_active,
         d.name  AS department_name,
         d.code  AS department_code
  FROM   faculty f
  JOIN   users u ON u.id = f.user_id
  LEFT JOIN departments d ON d.id = f.department_id
\`;

// ── Model ─────────────────────────────────────────────────────────────────────

export class FacultyModel {

  // ── Create ─────────────────────────────────────────────────────────────────

  static async create(
    data: {
      userId: string;
      institutionId: string;
      nameRaw: string;
      departmentId?: string;
      employeeCode?: string;
      designation: Designation;
      employmentType: EmploymentType;
      qualification?: string;
      specialization?: string;
    },
    client?: PoolClient
  ): Promise<FacultyRow> {
    const { salutation, firstName, lastName, initials } = parseFacultyName(data.nameRaw);
    const fullName = buildFullName(salutation, firstName, lastName, initials);

    // Duplicate employee-code guard
    if (data.employeeCode) {
      const dup = await queryOne<{ id: string }>(
        'SELECT id FROM faculty WHERE institution_id = $1 AND employee_code = $2',
        [data.institutionId, data.employeeCode]
      );
      if (dup) throw new AppError('Employee code already exists in this institution.', 409);
    }

    const pct = computeProfilePct({
      employee_code: data.employeeCode,
      qualification: data.qualification,
      specialization: data.specialization,
      department_id: data.departmentId,
    });

    const row = await queryOne<FacultyRow>(\`
      INSERT INTO faculty (
        user_id, institution_id, department_id, employee_code,
        salutation, full_name, first_name, last_name, initials,
        designation, employment_type, qualification, specialization,
        experience_years, industry_exp_years, experience_log,
        ugc_net, phd_guide, phd_students_guided,
        publications_count, patents_count, awards_count,
        fdp_attended, fdp_organized, profile_complete, profile_pct,
        is_active
      ) VALUES (
        $1,$2,$3,$4,
        $5,$6,$7,$8,$9,
        $10,$11,$12,$13,
        0,0,'[]'::jsonb,
        false,false,0,
        0,0,0,
        0,0,false,$14,
        true
      )
      RETURNING *
    \`, [
      data.userId, data.institutionId, data.departmentId ?? null, data.employeeCode ?? null,
      salutation, fullName, firstName, lastName, initials,
      data.designation, data.employmentType, data.qualification ?? null, data.specialization ?? null,
      pct,
    ]);

    return row!;
  }

  // ── Find by id (scoped to institution) ────────────────────────────────────

  static async findById(id: string, institutionId: string): Promise<FacultyRow | null> {
    return queryOne<FacultyRow>(
      \`\${SELECT_FACULTY} WHERE f.id = $1 AND f.institution_id = $2\`,
      [id, institutionId]
    );
  }

  // ── Find by user_id ───────────────────────────────────────────────────────

  static async findByUserId(userId: string, institutionId: string): Promise<FacultyRow | null> {
    return queryOne<FacultyRow>(
      \`\${SELECT_FACULTY} WHERE f.user_id = $1 AND f.institution_id = $2\`,
      [userId, institutionId]
    );
  }

  // ── Paginated list ────────────────────────────────────────────────────────

  static async findAll(opts: {
    institutionId: string;
    departmentId?: string;
    employmentType?: EmploymentType;
    designation?: Designation;
    search?: string;
    isActive?: boolean;
    limit: number;
    offset: number;
  }): Promise<{ rows: FacultyRow[]; total: number }> {
    const conditions: string[] = ['f.institution_id = $1'];
    const params: unknown[]    = [opts.institutionId];
    let   idx = 2;

    if (opts.departmentId !== undefined) {
      conditions.push(\`f.department_id = $\${idx++}\`);
      params.push(opts.departmentId);
    }
    if (opts.employmentType) {
      conditions.push(\`f.employment_type = $\${idx++}\`);
      params.push(opts.employmentType);
    }
    if (opts.designation) {
      conditions.push(\`f.designation = $\${idx++}\`);
      params.push(opts.designation);
    }
    if (opts.isActive !== undefined) {
      conditions.push(\`f.is_active = $\${idx++}\`);
      params.push(opts.isActive);
    }
    if (opts.search) {
      conditions.push(
        \`(f.full_name ILIKE $\${idx} OR f.employee_code ILIKE $\${idx} OR u.email ILIKE $\${idx})\`
      );
      params.push(\`%\${opts.search}%\`); idx++;
    }

    const where = conditions.join(' AND ');

    const [rows, countRes] = await Promise.all([
      queryMany<FacultyRow>(
        \`\${SELECT_FACULTY} WHERE \${where}
         ORDER BY f.full_name
         LIMIT $\${idx} OFFSET $\${idx + 1}\`,
        [...params, opts.limit, opts.offset]
      ),
      queryOne<{ count: string }>(
        \`SELECT COUNT(*) AS count FROM faculty f JOIN users u ON u.id = f.user_id WHERE \${where}\`,
        params
      ),
    ]);

    return { rows, total: parseInt(countRes?.count ?? '0', 10) };
  }

  // ── Update core profile ───────────────────────────────────────────────────

  static async update(
    id: string,
    institutionId: string,
    patch: Partial<{
      nameRaw: string;
      departmentId: string;
      employeeCode: string;
      designation: Designation;
      employmentType: EmploymentType;
      qualification: string;
      specialization: string;
      gender: 'male' | 'female' | 'other';
      dateOfBirth: string;
      dateOfJoining: string;
      ugcNet: boolean;
      gateScore: number;
      phdGuide: boolean;
      phdStudentsGuided: number;
      publicationsCount: number;
      patentsCount: number;
      awardsCount: number;
      fdpAttended: number;
      fdpOrganized: number;
      orcidId: string;
      scopusId: string;
      googleScholarUrl: string;
      avatarUrl: string;
    }>
  ): Promise<FacultyRow> {
    const sets: string[]    = [];
    const params: unknown[] = [];
    let   idx = 1;

    const push = (col: string, val: unknown) => {
      sets.push(\`\${col} = $\${idx++}\`);
      params.push(val);
    };

    if (patch.nameRaw !== undefined) {
      const { salutation, firstName, lastName, initials } = parseFacultyName(patch.nameRaw);
      push('salutation',  salutation);
      push('full_name',   buildFullName(salutation, firstName, lastName, initials));
      push('first_name',  firstName);
      push('last_name',   lastName);
      push('initials',    initials);
    }

    const colMap: Record<string, string> = {
      departmentId: 'department_id', employeeCode: 'employee_code',
      designation: 'designation', employmentType: 'employment_type',
      qualification: 'qualification', specialization: 'specialization',
      gender: 'gender', dateOfBirth: 'date_of_birth', dateOfJoining: 'date_of_joining',
      ugcNet: 'ugc_net', gateScore: 'gate_score', phdGuide: 'phd_guide',
      phdStudentsGuided: 'phd_students_guided', publicationsCount: 'publications_count',
      patentsCount: 'patents_count', awardsCount: 'awards_count',
      fdpAttended: 'fdp_attended', fdpOrganized: 'fdp_organized',
      orcidId: 'orcid_id', scopusId: 'scopus_id',
      googleScholarUrl: 'google_scholar_url', avatarUrl: 'avatar_url',
    };

    for (const [key, col] of Object.entries(colMap)) {
      const val = (patch as Record<string, unknown>)[key];
      if (val !== undefined) push(col, val);
    }

    if (sets.length === 0) throw new AppError('No updatable fields supplied.', 400);

    // Recompute profile_pct after patching
    sets.push(\`profile_pct = GREATEST(50, LEAST(100,
      50 + (
        (CASE WHEN employee_code   IS NOT NULL THEN 1 ELSE 0 END) +
        (CASE WHEN gender          IS NOT NULL THEN 1 ELSE 0 END) +
        (CASE WHEN date_of_birth   IS NOT NULL THEN 1 ELSE 0 END) +
        (CASE WHEN date_of_joining IS NOT NULL THEN 1 ELSE 0 END) +
        (CASE WHEN qualification   IS NOT NULL THEN 1 ELSE 0 END) +
        (CASE WHEN specialization  IS NOT NULL THEN 1 ELSE 0 END) +
        (CASE WHEN orcid_id        IS NOT NULL THEN 1 ELSE 0 END) +
        (CASE WHEN google_scholar_url IS NOT NULL THEN 1 ELSE 0 END) +
        (CASE WHEN avatar_url      IS NOT NULL THEN 1 ELSE 0 END)
      ) * 50 / 9
    ))\`);

    sets.push(\`profile_complete = (profile_pct >= 80)\`);

    params.push(id, institutionId);

    const row = await queryOne<FacultyRow>(\`
      UPDATE faculty SET \${sets.join(', ')}, updated_at = NOW()
      WHERE id = $\${idx} AND institution_id = $\${idx + 1}
      RETURNING *
    \`, params);

    if (!row) throw new AppError('Faculty record not found.', 404);
    return row;
  }

  // ── Experience log management ─────────────────────────────────────────────

  static async addExperience(
    id: string,
    institutionId: string,
    entry: Omit<ExperienceEntry, 'years'>
  ): Promise<FacultyRow> {
    const faculty = await this.findById(id, institutionId);
    if (!faculty) throw new AppError('Faculty not found.', 404);

    const from  = new Date(entry.from_date).getTime();
    const to    = entry.is_current ? Date.now()
      : entry.to_date ? new Date(entry.to_date).getTime() : Date.now();
    const years = Math.max(0, (to - from) / (1000 * 60 * 60 * 24 * 365.25));

    const newEntry: ExperienceEntry = { ...entry, years: parseFloat(years.toFixed(2)) };
    const log: ExperienceEntry[]    = [
      ...(faculty.experience_log as ExperienceEntry[]),
      newEntry,
    ];
    const totalYears = computeTotalExperience(log);

    const row = await queryOne<FacultyRow>(\`
      UPDATE faculty
      SET experience_log   = $1::jsonb,
          experience_years = $2,
          updated_at       = NOW()
      WHERE id = $3 AND institution_id = $4
      RETURNING *
    \`, [JSON.stringify(log), totalYears, id, institutionId]);

    return row!;
  }

  static async removeExperience(
    id: string,
    institutionId: string,
    entryIndex: number
  ): Promise<FacultyRow> {
    const faculty = await this.findById(id, institutionId);
    if (!faculty) throw new AppError('Faculty not found.', 404);

    const log = (faculty.experience_log as ExperienceEntry[]).filter((_, i) => i !== entryIndex);
    const totalYears = computeTotalExperience(log);

    const row = await queryOne<FacultyRow>(\`
      UPDATE faculty
      SET experience_log   = $1::jsonb,
          experience_years = $2,
          updated_at       = NOW()
      WHERE id = $3 AND institution_id = $4
      RETURNING *
    \`, [JSON.stringify(log), totalYears, id, institutionId]);

    return row!;
  }

  // ── Department dynamic re-mapping ─────────────────────────────────────────
  // Called when a department is merged/renamed; updates all affected faculty.

  static async remapDepartment(
    fromDeptId: string,
    toDeptId: string,
    institutionId: string
  ): Promise<number> {
    const res = await query(\`
      UPDATE faculty
      SET department_id = $1, updated_at = NOW()
      WHERE department_id = $2 AND institution_id = $3
    \`, [toDeptId, fromDeptId, institutionId]);
    return res.rowCount ?? 0;
  }

  // ── Soft delete / reactivate ──────────────────────────────────────────────

  static async setActive(id: string, institutionId: string, active: boolean): Promise<void> {
    const res = await query(\`
      UPDATE faculty SET is_active = $1, updated_at = NOW()
      WHERE id = $2 AND institution_id = $3
    \`, [active, id, institutionId]);
    if ((res.rowCount ?? 0) === 0) throw new AppError('Faculty not found.', 404);
    // Mirror on linked user
    await query(\`
      UPDATE users u
      SET is_active = $1
      FROM faculty f
      WHERE f.user_id = u.id AND f.id = $2
    \`, [active, id]);
  }

  // ── Stats for dashboard ───────────────────────────────────────────────────

  static async stats(institutionId: string, departmentId?: string) {
    const where = departmentId
      ? 'institution_id = $1 AND department_id = $2'
      : 'institution_id = $1';
    const params: unknown[] = departmentId
      ? [institutionId, departmentId]
      : [institutionId];

    return queryOne<Record<string, unknown>>(\`
      SELECT
        COUNT(*)                                           AS total,
        COUNT(*) FILTER (WHERE is_active)                 AS active,
        COUNT(*) FILTER (WHERE employment_type = 'permanent') AS permanent,
        COUNT(*) FILTER (WHERE ugc_net = true)            AS ugc_net_qualified,
        COUNT(*) FILTER (WHERE phd_guide = true)          AS phd_guides,
        COALESCE(AVG(experience_years),0)::NUMERIC(5,2)   AS avg_experience,
        COALESCE(SUM(publications_count),0)               AS total_publications,
        COALESCE(SUM(patents_count),0)                    AS total_patents,
        COALESCE(AVG(profile_pct),0)::NUMERIC(5,2)        AS avg_profile_pct
      FROM faculty
      WHERE \${where}
    \`, params);
  }
}
`);

// ══════════════════════════════════════════════════════════════════════════════
// 2.  backend/src/services/faculty.service.ts
// ══════════════════════════════════════════════════════════════════════════════

write('backend/src/services/faculty.service.ts', `
import { Request } from 'express';
import {
  FacultyModel,
  FacultyRow,
  ExperienceEntry,
  Designation,
  EmploymentType,
} from '../models/faculty.model';
import { parsePagination, buildPaginatedResponse } from '../utils/pagination';
import { AppError } from '../utils/AppError';
import { queryOne } from '../config/database';

// ── Create faculty profile ─────────────────────────────────────────────────

export async function createFacultyProfile(
  userId: string,
  institutionId: string,
  body: {
    nameRaw: string;
    departmentId?: string;
    employeeCode?: string;
    designation: Designation;
    employmentType: EmploymentType;
    qualification?: string;
    specialization?: string;
  }
): Promise<FacultyRow> {
  // A user can only have one faculty profile
  const existing = await FacultyModel.findByUserId(userId, institutionId);
  if (existing) throw new AppError('Faculty profile already exists for this user.', 409);

  // Validate department belongs to institution
  if (body.departmentId) {
    const dept = await queryOne<{ id: string }>(
      'SELECT id FROM departments WHERE id = $1 AND institution_id = $2',
      [body.departmentId, institutionId]
    );
    if (!dept) throw new AppError('Department not found in this institution.', 404);
  }

  return FacultyModel.create({ userId, institutionId, ...body });
}

// ── Get faculty profile (with role guard) ─────────────────────────────────

export async function getFacultyById(
  id: string,
  institutionId: string
): Promise<FacultyRow> {
  const row = await FacultyModel.findById(id, institutionId);
  if (!row) throw new AppError('Faculty not found.', 404);
  return row;
}

// ── Own profile lookup (for faculty role) ────────────────────────────────

export async function getOwnProfile(
  userId: string,
  institutionId: string
): Promise<FacultyRow> {
  const row = await FacultyModel.findByUserId(userId, institutionId);
  if (!row) throw new AppError('Faculty profile not created yet.', 404);
  return row;
}

// ── List with full filter + pagination ────────────────────────────────────

export async function listFaculty(req: Request, institutionId: string) {
  const { page, limit, offset } = parsePagination(req);
  const q = req.query;

  const { rows, total } = await FacultyModel.findAll({
    institutionId,
    departmentId:   q.department_id as string | undefined,
    employmentType: q.employment_type as EmploymentType | undefined,
    designation:    q.designation    as Designation    | undefined,
    search:         q.search         as string | undefined,
    isActive:       q.active !== undefined ? q.active === 'true' : undefined,
    limit,
    offset,
  });

  return buildPaginatedResponse(rows, total, { page, limit, offset });
}

// ── Update profile ────────────────────────────────────────────────────────

export async function updateFacultyProfile(
  id: string,
  institutionId: string,
  requesterId: string,
  requesterRole: string,
  body: Record<string, unknown>
): Promise<FacultyRow> {
  const faculty = await FacultyModel.findById(id, institutionId);
  if (!faculty) throw new AppError('Faculty not found.', 404);

  // Faculty can only update their own profile
  if (requesterRole === 'faculty' && faculty.user_id !== requesterId) {
    throw new AppError('You can only update your own profile.', 403);
  }

  // Validate new department if provided
  if (body.departmentId) {
    const dept = await queryOne<{ id: string }>(
      'SELECT id FROM departments WHERE id = $1 AND institution_id = $2',
      [body.departmentId, institutionId]
    );
    if (!dept) throw new AppError('Department not found.', 404);
  }

  return FacultyModel.update(id, institutionId, {
    nameRaw:           body.nameRaw           as string | undefined,
    departmentId:      body.departmentId       as string | undefined,
    employeeCode:      body.employeeCode       as string | undefined,
    designation:       body.designation        as Designation | undefined,
    employmentType:    body.employmentType      as EmploymentType | undefined,
    qualification:     body.qualification      as string | undefined,
    specialization:    body.specialization     as string | undefined,
    gender:            body.gender             as 'male' | 'female' | 'other' | undefined,
    dateOfBirth:       body.dateOfBirth        as string | undefined,
    dateOfJoining:     body.dateOfJoining      as string | undefined,
    ugcNet:            body.ugcNet             as boolean | undefined,
    gateScore:         body.gateScore          as number | undefined,
    phdGuide:          body.phdGuide           as boolean | undefined,
    phdStudentsGuided: body.phdStudentsGuided  as number | undefined,
    publicationsCount: body.publicationsCount  as number | undefined,
    patentsCount:      body.patentsCount       as number | undefined,
    awardsCount:       body.awardsCount        as number | undefined,
    fdpAttended:       body.fdpAttended        as number | undefined,
    fdpOrganized:      body.fdpOrganized       as number | undefined,
    orcidId:           body.orcidId            as string | undefined,
    scopusId:          body.scopusId           as string | undefined,
    googleScholarUrl:  body.googleScholarUrl   as string | undefined,
    avatarUrl:         body.avatarUrl          as string | undefined,
  });
}

// ── Experience tracking ───────────────────────────────────────────────────

export async function addExperienceEntry(
  id: string,
  institutionId: string,
  entry: Omit<ExperienceEntry, 'years'>
): Promise<FacultyRow> {
  // from_date must be in the past
  const from = new Date(entry.from_date);
  if (isNaN(from.getTime())) throw new AppError('Invalid from_date.', 422);
  if (from > new Date()) throw new AppError('from_date cannot be in the future.', 422);

  if (!entry.is_current && entry.to_date) {
    const to = new Date(entry.to_date);
    if (isNaN(to.getTime())) throw new AppError('Invalid to_date.', 422);
    if (to <= from) throw new AppError('to_date must be after from_date.', 422);
  }

  return FacultyModel.addExperience(id, institutionId, entry);
}

export async function removeExperienceEntry(
  id: string,
  institutionId: string,
  entryIndex: number
): Promise<FacultyRow> {
  if (!Number.isInteger(entryIndex) || entryIndex < 0) {
    throw new AppError('Invalid experience entry index.', 422);
  }
  return FacultyModel.removeExperience(id, institutionId, entryIndex);
}

// ── Department re-mapping (admin/principal only) ──────────────────────────

export async function remapFacultyDepartment(
  fromDeptId: string,
  toDeptId: string,
  institutionId: string
): Promise<{ affected: number }> {
  if (fromDeptId === toDeptId) {
    throw new AppError('Source and destination departments must differ.', 400);
  }

  // Validate both departments belong to institution
  const [from, to] = await Promise.all([
    queryOne<{ id: string }>('SELECT id FROM departments WHERE id=$1 AND institution_id=$2', [fromDeptId, institutionId]),
    queryOne<{ id: string }>('SELECT id FROM departments WHERE id=$1 AND institution_id=$2', [toDeptId,   institutionId]),
  ]);
  if (!from) throw new AppError('Source department not found.', 404);
  if (!to)   throw new AppError('Destination department not found.', 404);

  const affected = await FacultyModel.remapDepartment(fromDeptId, toDeptId, institutionId);
  return { affected };
}

// ── Activate / deactivate ─────────────────────────────────────────────────

export async function setFacultyActive(
  id: string,
  institutionId: string,
  active: boolean
): Promise<void> {
  return FacultyModel.setActive(id, institutionId, active);
}

// ── Dashboard stats ───────────────────────────────────────────────────────

export async function getFacultyStats(
  institutionId: string,
  departmentId?: string
) {
  return FacultyModel.stats(institutionId, departmentId);
}
`);

// ══════════════════════════════════════════════════════════════════════════════
// 3.  backend/src/validators/faculty.validator.ts
// ══════════════════════════════════════════════════════════════════════════════

write('backend/src/validators/faculty.validator.ts', `
import { body, param, query } from 'express-validator';
import { SALUTATIONS } from '../models/faculty.model';

const DESIGNATIONS = [
  'Professor', 'Associate Professor', 'Assistant Professor',
  'Senior Lecturer', 'Lecturer', 'Lab Instructor',
] as const;

const EMPLOYMENT_TYPES = ['permanent', 'contract', 'visiting', 'adjunct'] as const;

// ── Reusable field validators ─────────────────────────────────────────────────

const nameRawField = () =>
  body('nameRaw')
    .trim()
    .notEmpty().withMessage('Faculty name is required.')
    .matches(
      /^(Dr\\.|Prof\\.|Mr\\.|Mrs\\.|Ms\\.|Er\\.)\\s[A-Za-z]{2,40}\\s[A-Za-z]{2,40}(\\s[A-Z]\\.)*(\\s[A-Z]\\.)*$/u
    )
    .withMessage(
      'Name must be: [Salutation] [First Name] [Last Name] [Optional Initials]. ' +
      'Valid salutations: ' + SALUTATIONS.join(', ')
    );

const designationField = () =>
  body('designation')
    .notEmpty().withMessage('Designation is required.')
    .isIn(DESIGNATIONS).withMessage(\`Designation must be one of: \${DESIGNATIONS.join(', ')}\`);

const employmentTypeField = (required = true) => {
  const v = body('employmentType');
  return (required ? v.notEmpty().withMessage('Employment type is required.') : v.optional())
    .isIn(EMPLOYMENT_TYPES)
    .withMessage(\`Employment type must be one of: \${EMPLOYMENT_TYPES.join(', ')}\`);
};

// ── Exported rule sets ────────────────────────────────────────────────────────

export const createFacultyRules = [
  nameRawField(),
  designationField(),
  employmentTypeField(),

  body('departmentId')
    .optional()
    .isUUID().withMessage('departmentId must be a valid UUID.'),

  body('employeeCode')
    .optional()
    .trim()
    .isLength({ min: 2, max: 30 })
    .withMessage('Employee code must be 2–30 characters.'),

  body('qualification')
    .optional()
    .trim()
    .isLength({ min: 2, max: 100 })
    .withMessage('Qualification must be 2–100 characters.'),

  body('specialization')
    .optional()
    .trim()
    .isLength({ min: 2, max: 100 })
    .withMessage('Specialization must be 2–100 characters.'),
];

export const updateFacultyRules = [
  body('nameRaw').optional().trim()
    .matches(
      /^(Dr\\.|Prof\\.|Mr\\.|Mrs\\.|Ms\\.|Er\\.)\\s[A-Za-z]{2,40}\\s[A-Za-z]{2,40}(\\s[A-Z]\\.)*(\\s[A-Z]\\.)*$/u
    )
    .withMessage('Name format invalid. Use [Salutation] [First] [Last] [Initials].'),

  body('designation').optional()
    .isIn(DESIGNATIONS).withMessage('Invalid designation.'),

  employmentTypeField(false),

  body('departmentId').optional()
    .isUUID().withMessage('departmentId must be a valid UUID.'),

  body('employeeCode').optional().trim()
    .isLength({ min: 2, max: 30 }).withMessage('Employee code must be 2–30 characters.'),

  body('gender').optional()
    .isIn(['male', 'female', 'other']).withMessage('gender must be male | female | other.'),

  body('dateOfBirth').optional()
    .isISO8601().withMessage('dateOfBirth must be ISO 8601 (YYYY-MM-DD).')
    .custom(v => {
      const d = new Date(v);
      const age = (Date.now() - d.getTime()) / (1000 * 60 * 60 * 24 * 365.25);
      if (age < 18 || age > 80) throw new Error('Age must be between 18 and 80.');
      return true;
    }),

  body('dateOfJoining').optional()
    .isISO8601().withMessage('dateOfJoining must be ISO 8601 (YYYY-MM-DD).'),

  body('ugcNet').optional()
    .isBoolean().withMessage('ugcNet must be a boolean.'),

  body('gateScore').optional()
    .isFloat({ min: 0, max: 1000 }).withMessage('gateScore must be 0–1000.'),

  body('phdGuide').optional()
    .isBoolean().withMessage('phdGuide must be a boolean.'),

  body('phdStudentsGuided').optional()
    .isInt({ min: 0 }).withMessage('phdStudentsGuided must be a non-negative integer.'),

  body('publicationsCount').optional()
    .isInt({ min: 0 }).withMessage('publicationsCount must be ≥ 0.'),

  body('patentsCount').optional()
    .isInt({ min: 0 }).withMessage('patentsCount must be ≥ 0.'),

  body('awardsCount').optional()
    .isInt({ min: 0 }).withMessage('awardsCount must be ≥ 0.'),

  body('fdpAttended').optional()
    .isInt({ min: 0 }).withMessage('fdpAttended must be ≥ 0.'),

  body('fdpOrganized').optional()
    .isInt({ min: 0 }).withMessage('fdpOrganized must be ≥ 0.'),

  body('orcidId').optional().trim()
    .matches(/^\\d{4}-\\d{4}-\\d{4}-\\d{3}[\\dX]$/)
    .withMessage('ORCID iD must be in format 0000-0000-0000-000X.'),

  body('scopusId').optional().trim()
    .isLength({ min: 3, max: 20 }).withMessage('Scopus ID must be 3–20 characters.'),

  body('googleScholarUrl').optional().trim()
    .isURL({ protocols: ['https'], host_whitelist: ['scholar.google.com'] })
    .withMessage('Google Scholar URL must be a valid https://scholar.google.com URL.'),
];

export const addExperienceRules = [
  body('institution').trim().notEmpty().withMessage('Institution name is required.'),

  body('designation').trim().notEmpty().withMessage('Designation is required.'),

  body('from_date')
    .notEmpty().withMessage('from_date is required.')
    .isISO8601().withMessage('from_date must be ISO 8601 (YYYY-MM-DD).'),

  body('is_current')
    .notEmpty().withMessage('is_current is required.')
    .isBoolean().withMessage('is_current must be boolean.'),

  body('to_date')
    .if(body('is_current').equals('false'))
    .notEmpty().withMessage('to_date is required when is_current is false.')
    .isISO8601().withMessage('to_date must be ISO 8601 (YYYY-MM-DD).'),
];

export const listFacultyRules = [
  query('department_id').optional().isUUID(),
  query('employment_type').optional().isIn(EMPLOYMENT_TYPES),
  query('designation').optional().isIn(DESIGNATIONS),
  query('active').optional().isBoolean(),
  query('search').optional().trim().isLength({ max: 100 }),
  query('page').optional().isInt({ min: 1 }),
  query('limit').optional().isInt({ min: 1, max: 100 }),
];

export const remapDeptRules = [
  body('fromDeptId').isUUID().withMessage('fromDeptId must be a UUID.'),
  body('toDeptId').isUUID().withMessage('toDeptId must be a UUID.'),
];

export const facultyIdParam = [
  param('id').isUUID().withMessage('Faculty id must be a valid UUID.'),
];

export const experienceIndexParam = [
  param('index')
    .isInt({ min: 0 })
    .withMessage('Experience entry index must be a non-negative integer.'),
];
`);

// ══════════════════════════════════════════════════════════════════════════════
// 4.  backend/src/controllers/faculty.controller.ts
// ══════════════════════════════════════════════════════════════════════════════

write('backend/src/controllers/faculty.controller.ts', `
import { Request, Response, NextFunction } from 'express';
import multer, { FileFilterCallback } from 'multer';
import path from 'path';
import fs from 'fs';
import { v4 as uuidv4 } from 'uuid';
import {
  createFacultyProfile,
  getFacultyById,
  getOwnProfile,
  listFaculty,
  updateFacultyProfile,
  addExperienceEntry,
  removeExperienceEntry,
  remapFacultyDepartment,
  setFacultyActive,
  getFacultyStats,
} from '../services/faculty.service';
import { sendSuccess, sendCreated, sendError } from '../utils/response';
import { AppError } from '../utils/AppError';

// ── Multi-file upload configuration ──────────────────────────────────────────
// Accepts: avatar (image), CV (pdf/doc/docx), certificates (image/pdf)
// All stored at  uploads/faculty/<faculty_id>/  with UUID-prefixed filenames.

const UPLOAD_BASE = path.resolve(process.cwd(), 'uploads', 'faculty');

function facultyStorage(subFolder: 'avatar' | 'cv' | 'certificates') {
  return multer.diskStorage({
    destination(_req: Request, _file, cb) {
      // We don't know faculty id yet at middleware time for create; use 'temp'
      const dir = path.join(UPLOAD_BASE, 'temp', subFolder);
      fs.mkdirSync(dir, { recursive: true });
      cb(null, dir);
    },
    filename(_req: Request, file, cb) {
      const ext = path.extname(file.originalname).toLowerCase();
      cb(null, \`\${uuidv4()}\${ext}\`);
    },
  });
}

const ALLOWED_IMAGE_MIME  = new Set(['image/jpeg', 'image/png', 'image/webp']);
const ALLOWED_DOC_MIME    = new Set([
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
]);
const ALLOWED_CERT_MIME   = new Set([...ALLOWED_IMAGE_MIME, 'application/pdf']);

function makeFilter(allowed: Set<string>) {
  return (_req: Request, file: Express.Multer.File, cb: FileFilterCallback) => {
    if (allowed.has(file.mimetype)) cb(null, true);
    else cb(new AppError(\`File type "\${file.mimetype}" not allowed.\`, 415));
  };
}

// Three separate multer instances so each accepts its own MIME set
export const uploadAvatar = multer({
  storage: facultyStorage('avatar'),
  fileFilter: makeFilter(ALLOWED_IMAGE_MIME),
  limits: { fileSize: 2 * 1024 * 1024, files: 1 },  // 2 MB
});

export const uploadCV = multer({
  storage: facultyStorage('cv'),
  fileFilter: makeFilter(ALLOWED_DOC_MIME),
  limits: { fileSize: 5 * 1024 * 1024, files: 1 },  // 5 MB
});

// Drag-and-drop dashboard multi-file: up to 10 certificates per batch
export const uploadCertificates = multer({
  storage: facultyStorage('certificates'),
  fileFilter: makeFilter(ALLOWED_CERT_MIME),
  limits: { fileSize: 5 * 1024 * 1024, files: 10 },
});

/** Move a file from temp/ to <faculty_id>/ and return the new relative URL. */
function relocateUpload(tmpPath: string, facultyId: string, subFolder: string): string {
  const destDir = path.join(UPLOAD_BASE, facultyId, subFolder);
  fs.mkdirSync(destDir, { recursive: true });
  const filename = path.basename(tmpPath);
  const destPath = path.join(destDir, filename);
  fs.renameSync(tmpPath, destPath);
  return \`/uploads/faculty/\${facultyId}/\${subFolder}/\${filename}\`;
}

// ── asyncHandler wrapper ───────────────────────────────────────────────────────

const asyncHandler =
  (fn: (req: Request, res: Response, next: NextFunction) => Promise<void>) =>
  (req: Request, res: Response, next: NextFunction) =>
    fn(req, res, next).catch(next);

// ── Controllers ───────────────────────────────────────────────────────────────

/** POST /faculty  — create a new faculty profile for the calling user */
export const createProfile = asyncHandler(async (req, res) => {
  const { userId, institutionId } = req.user!;
  const profile = await createFacultyProfile(userId, institutionId, req.body);
  sendCreated(res, profile, 'Faculty profile created.');
});

/** GET /faculty  — list with filters (admin / principal / iqac_coordinator / hod) */
export const getList = asyncHandler(async (req, res) => {
  const { institutionId } = req.user!;
  const result = await listFaculty(req, institutionId);
  sendSuccess(res, result, 'Faculty list fetched.');
});

/** GET /faculty/me  — own profile (faculty role) */
export const getMe = asyncHandler(async (req, res) => {
  const { userId, institutionId } = req.user!;
  const profile = await getOwnProfile(userId, institutionId);
  sendSuccess(res, profile, 'Own faculty profile fetched.');
});

/** GET /faculty/:id  — get by id */
export const getById = asyncHandler(async (req, res) => {
  const profile = await getFacultyById(req.params.id, req.user!.institutionId);
  sendSuccess(res, profile, 'Faculty profile fetched.');
});

/** PATCH /faculty/:id  — partial update */
export const update = asyncHandler(async (req, res) => {
  const { userId, institutionId, role } = req.user!;
  const profile = await updateFacultyProfile(
    req.params.id, institutionId, userId, role, req.body
  );
  sendSuccess(res, profile, 'Faculty profile updated.');
});

/** POST /faculty/:id/experience  — add experience entry */
export const addExperience = asyncHandler(async (req, res) => {
  const { institutionId } = req.user!;
  const profile = await addExperienceEntry(req.params.id, institutionId, req.body);
  sendSuccess(res, profile, 'Experience entry added.');
});

/** DELETE /faculty/:id/experience/:index  — remove experience entry */
export const removeExperience = asyncHandler(async (req, res) => {
  const { institutionId } = req.user!;
  const index = parseInt(req.params.index, 10);
  const profile = await removeExperienceEntry(req.params.id, institutionId, index);
  sendSuccess(res, profile, 'Experience entry removed.');
});

/** POST /faculty/:id/avatar  — upload / replace profile photo */
export const uploadAvatarHandler = asyncHandler(async (req, res) => {
  if (!req.file) throw new AppError('No file received.', 400);
  const { institutionId } = req.user!;
  const faculty = await getFacultyById(req.params.id, institutionId);
  const url = relocateUpload(req.file.path, faculty.id, 'avatar');
  const updated = await updateFacultyProfile(
    faculty.id, institutionId, req.user!.userId, req.user!.role,
    { avatarUrl: url }
  );
  sendSuccess(res, { avatarUrl: updated.avatar_url }, 'Avatar updated.');
});

/** POST /faculty/:id/cv  — upload CV document */
export const uploadCVHandler = asyncHandler(async (req, res) => {
  if (!req.file) throw new AppError('No file received.', 400);
  const { institutionId } = req.user!;
  const faculty = await getFacultyById(req.params.id, institutionId);
  const url = relocateUpload(req.file.path, faculty.id, 'cv');
  sendSuccess(res, { cvUrl: url }, 'CV uploaded.');
});

/** POST /faculty/:id/certificates  — bulk certificate upload (drag-and-drop) */
export const uploadCertificatesHandler = asyncHandler(async (req, res) => {
  const files = req.files as Express.Multer.File[] | undefined;
  if (!files || files.length === 0) throw new AppError('No files received.', 400);
  const { institutionId } = req.user!;
  const faculty = await getFacultyById(req.params.id, institutionId);
  const urls = files.map(f => relocateUpload(f.path, faculty.id, 'certificates'));
  sendSuccess(res, { certificateUrls: urls, count: urls.length }, 'Certificates uploaded.');
});

/** POST /faculty/remap-department  — bulk remap (admin / principal) */
export const remapDepartment = asyncHandler(async (req, res) => {
  const { institutionId } = req.user!;
  const { fromDeptId, toDeptId } = req.body as { fromDeptId: string; toDeptId: string };
  const result = await remapFacultyDepartment(fromDeptId, toDeptId, institutionId);
  sendSuccess(res, result, \`Department re-mapping complete (\${result.affected} faculty updated).\`);
});

/** PATCH /faculty/:id/deactivate  — soft-delete */
export const deactivate = asyncHandler(async (req, res) => {
  await setFacultyActive(req.params.id, req.user!.institutionId, false);
  sendSuccess(res, null, 'Faculty deactivated.');
});

/** PATCH /faculty/:id/reactivate */
export const reactivate = asyncHandler(async (req, res) => {
  await setFacultyActive(req.params.id, req.user!.institutionId, true);
  sendSuccess(res, null, 'Faculty reactivated.');
});

/** GET /faculty/stats */
export const stats = asyncHandler(async (req, res) => {
  const { institutionId } = req.user!;
  const deptId = req.query.department_id as string | undefined;
  const data = await getFacultyStats(institutionId, deptId);
  sendSuccess(res, data, 'Faculty statistics fetched.');
});
`);

// ══════════════════════════════════════════════════════════════════════════════
// 5.  backend/src/routes/faculty.routes.ts
// ══════════════════════════════════════════════════════════════════════════════

write('backend/src/routes/faculty.routes.ts', `
import { Router } from 'express';
import {
  createProfile,
  getList,
  getMe,
  getById,
  update,
  addExperience,
  removeExperience,
  uploadAvatarHandler, uploadAvatar,
  uploadCVHandler,     uploadCV,
  uploadCertificatesHandler, uploadCertificates,
  remapDepartment,
  deactivate,
  reactivate,
  stats,
} from '../controllers/faculty.controller';
import { authenticate } from '../middlewares/auth.middleware';
import { authorize }     from '../middlewares/rbac.middleware';
import { validate }      from '../middlewares/validate.middleware';
import {
  createFacultyRules,
  updateFacultyRules,
  addExperienceRules,
  listFacultyRules,
  remapDeptRules,
  facultyIdParam,
  experienceIndexParam,
} from '../validators/faculty.validator';

const router = Router();

// All routes require authentication
router.use(authenticate);

// ── Stats & bulk ops (no :id param — must come before /:id routes) ─────────

router.get(
  '/stats',
  authorize('admin', 'principal', 'iqac_coordinator', 'hod'),
  stats
);

router.post(
  '/remap-department',
  authorize('admin', 'principal'),
  remapDeptRules,
  validate,
  remapDepartment
);

// ── Own profile (faculty self-service) ────────────────────────────────────

router.get('/me', authorize('faculty'), getMe);

// ── List all (management roles) ───────────────────────────────────────────

router.get(
  '/',
  authorize('admin', 'principal', 'iqac_coordinator', 'hod'),
  listFacultyRules,
  validate,
  getList
);

// ── Create profile ────────────────────────────────────────────────────────
// Faculty creates own; admins can create on behalf of a user

router.post(
  '/',
  authorize('admin', 'principal', 'iqac_coordinator', 'hod', 'faculty'),
  createFacultyRules,
  validate,
  createProfile
);

// ── Single-faculty routes ─────────────────────────────────────────────────

router.get(
  '/:id',
  facultyIdParam, validate,
  authorize('admin', 'principal', 'iqac_coordinator', 'hod', 'faculty'),
  getById
);

router.patch(
  '/:id',
  facultyIdParam, validate,
  authorize('admin', 'principal', 'iqac_coordinator', 'hod', 'faculty'),
  updateFacultyRules,
  validate,
  update
);

router.patch(
  '/:id/deactivate',
  facultyIdParam, validate,
  authorize('admin', 'principal', 'hod'),
  deactivate
);

router.patch(
  '/:id/reactivate',
  facultyIdParam, validate,
  authorize('admin', 'principal', 'hod'),
  reactivate
);

// ── Experience log ────────────────────────────────────────────────────────

router.post(
  '/:id/experience',
  facultyIdParam, validate,
  authorize('admin', 'principal', 'iqac_coordinator', 'hod', 'faculty'),
  addExperienceRules,
  validate,
  addExperience
);

router.delete(
  '/:id/experience/:index',
  [...facultyIdParam, ...experienceIndexParam], validate,
  authorize('admin', 'principal', 'iqac_coordinator', 'hod', 'faculty'),
  removeExperience
);

// ── File upload endpoints (stream-safe multer middleware per route) ─────────

/**
 * POST /faculty/:id/avatar
 * Accepts:  image/jpeg, image/png, image/webp  ≤ 2 MB
 * multer runs as route middleware so errors are forwarded to next(err)
 * which the global error handler captures.
 */
router.post(
  '/:id/avatar',
  facultyIdParam, validate,
  authorize('admin', 'principal', 'iqac_coordinator', 'hod', 'faculty'),
  (req, res, next) => uploadAvatar.single('avatar')(req, res, next),
  uploadAvatarHandler
);

/**
 * POST /faculty/:id/cv
 * Accepts:  application/pdf, .doc, .docx  ≤ 5 MB
 */
router.post(
  '/:id/cv',
  facultyIdParam, validate,
  authorize('admin', 'principal', 'iqac_coordinator', 'hod', 'faculty'),
  (req, res, next) => uploadCV.single('cv')(req, res, next),
  uploadCVHandler
);

/**
 * POST /faculty/:id/certificates
 * Drag-and-drop batch upload: up to 10 files, images or PDF, ≤ 5 MB each.
 * multer field name: "certificates"
 */
router.post(
  '/:id/certificates',
  facultyIdParam, validate,
  authorize('admin', 'principal', 'iqac_coordinator', 'hod', 'faculty'),
  (req, res, next) => uploadCertificates.array('certificates', 10)(req, res, next),
  uploadCertificatesHandler
);

export default router;
`);

console.log('\n✅  Phase 2 files written successfully.\n');
console.log('Register the router in your app entry point:\n');
console.log("  import facultyRouter from './src/routes/faculty.routes';");
console.log("  app.use('/api/faculty', facultyRouter);\n");
console.log('New packages required (if not already installed):');
console.log('  npm install multer uuid');
console.log('  npm install -D @types/multer @types/uuid\n');
console.log('Make sure these Phase 0 files exist:');
[
  'src/config/database.ts     → pool, query, queryOne, queryMany',
  'src/middlewares/auth.middleware.ts  → authenticate (sets req.user)',
  'src/middlewares/rbac.middleware.ts  → authorize(...roles)',
  'src/middlewares/validate.middleware.ts → validate (express-validator guard)',
  'src/utils/response.ts      → sendSuccess, sendCreated, sendError',
  'src/utils/AppError.ts      → class AppError',
  'src/utils/pagination.ts    → parsePagination, buildPaginatedResponse',
].forEach(l => console.log(' ', l));
console.log('');