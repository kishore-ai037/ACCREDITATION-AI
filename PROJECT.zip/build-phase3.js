#!/usr/bin/env node
/**
 * build-phase3.js
 * AccrediAI — Phase 3: AI Engine Integration Layer
 *
 * Programmatically writes:
 *   1. backend/src/services/ai-parser.service.ts
 *   2. backend/src/controllers/ai.controller.ts
 *   3. backend/src/routes/ai.routes.ts
 *
 * Assumes the Phase 0 foundation already exists:
 *   backend/src/config/database.ts
 *   backend/src/middleware/auth.ts        (exports `authenticate`)
 *   backend/src/middleware/rbac.ts        (exports `authorize`)
 *   backend/src/middleware/validate.ts
 *   backend/src/utils/response.ts         (exports `sendResponse`)
 *   backend/src/utils/AppError.ts         (exports `AppError`)
 *   backend/src/utils/asyncHandler.ts     (exports `asyncHandler`)
 *
 * Run:  node build-phase3.js
 *
 * Additional runtime dependencies required by the generated code:
 *   npm install multer pdf-parse mammoth
 *   npm install -D @types/multer @types/pdf-parse
 *
 * Optional (only needed if AI_PROVIDER=openai is set at runtime):
 *   OPENAI_API_KEY environment variable
 */

const fs = require('fs');
const path = require('path');

const ROOT = path.join(process.cwd(), 'backend', 'src');

const DIRS = ['services', 'controllers', 'routes'].map((d) => path.join(ROOT, d));

function ensureDirs() {
  DIRS.forEach((dir) => {
    fs.mkdirSync(dir, { recursive: true });
    console.log(`[dir]  ensured ${dir}`);
  });
}

function writeFile(relativePath, content) {
  const fullPath = path.join(ROOT, relativePath);
  fs.mkdirSync(path.dirname(fullPath), { recursive: true });
  fs.writeFileSync(fullPath, content, { encoding: 'utf8' });
  console.log(`[file] written ${fullPath} (${content.length} bytes)`);
}

/* ========================================================================
 * 1. services/ai-parser.service.ts
 * ==================================================================== */
const AI_PARSER_SERVICE = `import pdfParse from 'pdf-parse';
import mammoth from 'mammoth';
import { AppError } from '../utils/AppError';

/**
 * Supported source mime types for document ingestion.
 */
export const SUPPORTED_MIME_TYPES = [
  'application/pdf',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/msword',
  'text/plain',
] as const;

export type SupportedMimeType = (typeof SUPPORTED_MIME_TYPES)[number];

/**
 * Faculty naming convention enforced across the platform:
 * [Salutation] [First Name] [Last Name] [Initial]
 * e.g. "Dr. Ramesh Kumar S" / "Prof. Anitha Devi R"
 */
const NAME_FORMAT_REGEX =
  /^(Dr|Mr|Mrs|Ms|Prof|Er)\\.?\\s+[A-Z][a-zA-Z]+\\s+[A-Z][a-zA-Z]+\\s+[A-Z]\\.?$/;

const SALUTATIONS = ['Dr.', 'Dr', 'Prof.', 'Prof', 'Mr.', 'Mr', 'Mrs.', 'Mrs', 'Ms.', 'Ms', 'Er.', 'Er'];

export interface EducationEntry {
  degree: string;
  institution: string | null;
  year: string | null;
  raw: string;
}

export interface ExperienceEntry {
  organization: string;
  designation: string | null;
  fromDate: string | null;
  toDate: string | null;
  durationMonths: number | null;
  raw: string;
}

export interface ResumeParseResult {
  rawTextExcerpt: string;
  fullTextLength: number;
  personalDetails: {
    fullName: string | null;
    salutation: string | null;
    firstName: string | null;
    lastName: string | null;
    initial: string | null;
    nameMatchesFacultyFormat: boolean;
    formattedSuggestion: string | null;
  };
  contact: {
    email: string | null;
    phone: string | null;
    address: string | null;
  };
  education: EducationEntry[];
  experience: ExperienceEntry[];
  totalExperienceMonths: number;
  skills: string[];
  certifications: string[];
  publications: string[];
  confidence: {
    name: number;
    email: number;
    phone: number;
    education: number;
    experience: number;
    skills: number;
  };
  extractedAt: string;
  provider: 'local-heuristic' | 'openai';
}

/* ------------------------------------------------------------------------
 * Text extraction from raw buffers
 * ---------------------------------------------------------------------- */
export async function extractTextFromBuffer(
  buffer: Buffer,
  mimeType: string
): Promise<string> {
  if (!buffer || buffer.length === 0) {
    throw new AppError('Empty file buffer received', 400);
  }

  switch (mimeType) {
    case 'application/pdf': {
      const result = await pdfParse(buffer);
      if (!result.text || result.text.trim().length === 0) {
        throw new AppError('Unable to extract readable text from PDF (possibly scanned/image-only)', 422);
      }
      return normalizeWhitespace(result.text);
    }

    case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document': {
      const result = await mammoth.extractRawText({ buffer });
      if (!result.value || result.value.trim().length === 0) {
        throw new AppError('Unable to extract readable text from DOCX file', 422);
      }
      return normalizeWhitespace(result.value);
    }

    case 'application/msword': {
      throw new AppError(
        'Legacy .doc format is not supported. Please upload .docx or .pdf.',
        415
      );
    }

    case 'text/plain': {
      return normalizeWhitespace(buffer.toString('utf8'));
    }

    default:
      throw new AppError(
        \`Unsupported mime type "\${mimeType}". Supported types: \${SUPPORTED_MIME_TYPES.join(', ')}\`,
        415
      );
  }
}

function normalizeWhitespace(text: string): string {
  return text
    .replace(/\\r\\n/g, '\\n')
    .replace(/[ \\t]+/g, ' ')
    .replace(/\\n{3,}/g, '\\n\\n')
    .trim();
}

/* ------------------------------------------------------------------------
 * Field extractors (local heuristic engine)
 * ---------------------------------------------------------------------- */
function extractEmail(text: string): { value: string | null; confidence: number } {
  const match = text.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}/);
  return { value: match ? match[0].toLowerCase() : null, confidence: match ? 0.95 : 0 };
}

function extractPhone(text: string): { value: string | null; confidence: number } {
  const match = text.match(/(?:\\+91[-\\s]?)?[6-9]\\d{9}\\b/) || text.match(/\\+?\\d[\\d\\s-]{8,14}\\d/);
  return { value: match ? match[0].replace(/\\s+/g, '') : null, confidence: match ? 0.85 : 0 };
}

function extractAddress(text: string): string | null {
  const line = text
    .split('\\n')
    .find((l) => /\\b(street|road|nagar|colony|district|pincode|pin code|city)\\b/i.test(l));
  return line ? line.trim() : null;
}

function extractName(text: string): {
  fullName: string | null;
  salutation: string | null;
  firstName: string | null;
  lastName: string | null;
  initial: string | null;
  nameMatchesFacultyFormat: boolean;
  formattedSuggestion: string | null;
  confidence: number;
} {
  const lines = text.split('\\n').map((l) => l.trim()).filter(Boolean).slice(0, 10);

  for (const line of lines) {
    for (const sal of SALUTATIONS) {
      const escaped = sal.replace('.', '\\\\.?');
      const pattern = new RegExp(\`^\${escaped}\\\\s+([A-Z][a-zA-Z]+)\\\\s+([A-Z][a-zA-Z]+)(?:\\\\s+([A-Z])\\\\.?)?\`);
      const match = line.match(pattern);
      if (match) {
        const salutation = sal.endsWith('.') ? sal : \`\${sal}.\`;
        const firstName = match[1];
        const lastName = match[2];
        const initial = match[3] || null;
        const fullName = initial
          ? \`\${salutation} \${firstName} \${lastName} \${initial}\`
          : \`\${salutation} \${firstName} \${lastName}\`;
        const nameMatchesFacultyFormat = NAME_FORMAT_REGEX.test(fullName);
        const formattedSuggestion = initial
          ? fullName
          : \`\${salutation} \${firstName} \${lastName} \${firstName.charAt(0)}\`;
        return {
          fullName,
          salutation,
          firstName,
          lastName,
          initial,
          nameMatchesFacultyFormat,
          formattedSuggestion,
          confidence: 0.9,
        };
      }
    }
  }

  // Fallback: first non-empty line that looks like a plain two/three-word name
  const fallbackLine = lines.find((l) => /^[A-Z][a-zA-Z]+(\\s+[A-Z][a-zA-Z]+){1,2}$/.test(l));
  if (fallbackLine) {
    const parts = fallbackLine.split(/\\s+/);
    const firstName = parts[0];
    const lastName = parts[1] || null;
    const initial = parts[2] ? parts[2].charAt(0) : null;
    return {
      fullName: fallbackLine,
      salutation: null,
      firstName,
      lastName,
      initial,
      nameMatchesFacultyFormat: false,
      formattedSuggestion: lastName
        ? \`Dr. \${firstName} \${lastName} \${(initial || firstName.charAt(0))}\`
        : null,
      confidence: 0.4,
    };
  }

  return {
    fullName: null,
    salutation: null,
    firstName: null,
    lastName: null,
    initial: null,
    nameMatchesFacultyFormat: false,
    formattedSuggestion: null,
    confidence: 0,
  };
}

const DEGREE_KEYWORDS = [
  'Ph\\\\.?D', 'M\\\\.?Tech', 'B\\\\.?Tech', 'M\\\\.?E', 'B\\\\.?E', 'M\\\\.?Sc', 'B\\\\.?Sc',
  'M\\\\.?A', 'B\\\\.?A', 'MBA', 'MCA', 'BCA', 'M\\\\.?Com', 'B\\\\.?Com', 'M\\\\.?Phil',
];

function extractEducation(text: string): { entries: EducationEntry[]; confidence: number } {
  const entries: EducationEntry[] = [];
  const degreePattern = new RegExp(\`(\${DEGREE_KEYWORDS.join('|')})\\\\.?\\\\s+(?:in\\\\s+)?([A-Za-z &,]+)?\`, 'gi');
  const lines = text.split('\\n');

  for (const line of lines) {
    degreePattern.lastIndex = 0;
    const match = degreePattern.exec(line);
    if (match) {
      const yearMatch = line.match(/\\b(19|20)\\d{2}\\b/);
      const institutionMatch = line.match(/(?:from|at)\\s+([A-Z][A-Za-z&.,\\s]+?)(?:,|\\(|$)/);
      entries.push({
        degree: match[1].replace(/\\\\/g, ''),
        institution: institutionMatch ? institutionMatch[1].trim() : null,
        year: yearMatch ? yearMatch[0] : null,
        raw: line.trim(),
      });
    }
  }

  return { entries, confidence: entries.length > 0 ? 0.75 : 0 };
}

const MONTH_MAP: Record<string, number> = {
  jan: 0, feb: 1, mar: 2, apr: 3, may: 4, jun: 5,
  jul: 6, aug: 7, sep: 8, oct: 9, nov: 10, dec: 11,
};

function parseApproxDate(token: string): Date | null {
  const cleaned = token.trim().toLowerCase();
  if (/present|current|till date|now/.test(cleaned)) {
    return new Date();
  }
  const monthYear = cleaned.match(/([a-z]{3,})\\.?\\s+(\\d{4})/);
  if (monthYear) {
    const monthKey = monthYear[1].slice(0, 3);
    const month = MONTH_MAP[monthKey];
    const year = parseInt(monthYear[2], 10);
    if (month !== undefined && !Number.isNaN(year)) {
      return new Date(year, month, 1);
    }
  }
  const yearOnly = cleaned.match(/\\b(19|20)\\d{2}\\b/);
  if (yearOnly) {
    return new Date(parseInt(yearOnly[0], 10), 0, 1);
  }
  return null;
}

function monthsBetween(from: Date, to: Date): number {
  return Math.max(
    0,
    (to.getFullYear() - from.getFullYear()) * 12 + (to.getMonth() - from.getMonth())
  );
}

function extractExperience(text: string): { entries: ExperienceEntry[]; totalMonths: number; confidence: number } {
  const entries: ExperienceEntry[] = [];
  const lines = text.split('\\n');

  const dateRangePattern =
    /([A-Za-z]{3,9}\\.?\\s+\\d{4}|\\d{4})\\s*(?:-|–|to)\\s*(present|current|till date|now|[A-Za-z]{3,9}\\.?\\s+\\d{4}|\\d{4})/i;

  for (const line of lines) {
    const rangeMatch = line.match(dateRangePattern);
    if (!rangeMatch) continue;

    const [, fromToken, toToken] = rangeMatch;
    const fromDate = parseApproxDate(fromToken);
    const toDate = parseApproxDate(toToken);
    const durationMonths = fromDate && toDate ? monthsBetween(fromDate, toDate) : null;

    const orgDesigMatch = line.match(/^(.*?)[-–—]\\s*(.*?)\\s*\\(?\\d{4}/) || line.match(/^([A-Za-z0-9&.,\\s]+)/);
    let organization = 'Unknown Organization';
    let designation: string | null = null;

    if (orgDesigMatch) {
      const segments = orgDesigMatch[0].split(/[-–—,]/).map((s) => s.trim()).filter(Boolean);
      if (segments.length >= 2) {
        organization = segments[0];
        designation = segments[1];
      } else if (segments.length === 1) {
        organization = segments[0];
      }
    }

    entries.push({
      organization,
      designation,
      fromDate: fromDate ? fromDate.toISOString().slice(0, 10) : null,
      toDate: toDate ? toDate.toISOString().slice(0, 10) : null,
      durationMonths,
      raw: line.trim(),
    });
  }

  const totalMonths = entries.reduce((sum, e) => sum + (e.durationMonths || 0), 0);

  return { entries, totalMonths, confidence: entries.length > 0 ? 0.7 : 0 };
}

function extractSectionList(text: string, headings: string[]): string[] {
  const lines = text.split('\\n');
  const results: string[] = [];
  let capturing = false;

  const headingPattern = new RegExp(\`^(\${headings.join('|')})\\\\s*:?\\\\s*$\`, 'i');
  const nextHeadingPattern = /^[A-Z][A-Za-z /&]+:?\\s*$/;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;

    if (headingPattern.test(line)) {
      capturing = true;
      continue;
    }

    if (capturing) {
      if (nextHeadingPattern.test(line) && line.length < 40 && !/^[\\d•\\-*]/.test(line)) {
        capturing = false;
        continue;
      }
      const cleaned = line.replace(/^[•\\-*\\d.)\\s]+/, '').trim();
      if (cleaned) results.push(cleaned);
    }
  }

  return results;
}

function extractSkills(text: string): { skills: string[]; confidence: number } {
  const skills = extractSectionList(text, ['Skills', 'Technical Skills', 'Core Competencies', 'Areas of Expertise']);
  const deduped = Array.from(new Set(skills.flatMap((s) => s.split(/,|\\|/).map((x) => x.trim()).filter(Boolean))));
  return { skills: deduped, confidence: deduped.length > 0 ? 0.65 : 0 };
}

function extractCertifications(text: string): string[] {
  return extractSectionList(text, ['Certifications', 'Certificates', 'Professional Certifications']);
}

function extractPublications(text: string): string[] {
  return extractSectionList(text, ['Publications', 'Research Publications', 'Papers Published']);
}

/* ------------------------------------------------------------------------
 * Local heuristic parse entry point
 * ---------------------------------------------------------------------- */
function parseResumeLocal(text: string): ResumeParseResult {
  const email = extractEmail(text);
  const phone = extractPhone(text);
  const name = extractName(text);
  const education = extractEducation(text);
  const experience = extractExperience(text);
  const skills = extractSkills(text);
  const certifications = extractCertifications(text);
  const publications = extractPublications(text);
  const address = extractAddress(text);

  return {
    rawTextExcerpt: text.slice(0, 500),
    fullTextLength: text.length,
    personalDetails: {
      fullName: name.fullName,
      salutation: name.salutation,
      firstName: name.firstName,
      lastName: name.lastName,
      initial: name.initial,
      nameMatchesFacultyFormat: name.nameMatchesFacultyFormat,
      formattedSuggestion: name.formattedSuggestion,
    },
    contact: {
      email: email.value,
      phone: phone.value,
      address,
    },
    education: education.entries,
    experience: experience.entries,
    totalExperienceMonths: experience.totalMonths,
    skills: skills.skills,
    certifications,
    publications,
    confidence: {
      name: name.confidence,
      email: email.confidence,
      phone: phone.confidence,
      education: education.confidence,
      experience: experience.confidence,
      skills: skills.confidence,
    },
    extractedAt: new Date().toISOString(),
    provider: 'local-heuristic',
  };
}

/* ------------------------------------------------------------------------
 * Optional remote provider (OpenAI) — used only when AI_PROVIDER=openai
 * ---------------------------------------------------------------------- */
const EXTRACTION_SCHEMA_PROMPT = \`You are a resume/document field extraction engine for a higher-education
accreditation system. Extract the following fields from the document text and
respond with ONLY a single valid JSON object, no markdown fences, no preamble:

{
  "fullName": string | null,
  "salutation": string | null,
  "firstName": string | null,
  "lastName": string | null,
  "initial": string | null,
  "email": string | null,
  "phone": string | null,
  "address": string | null,
  "education": [ { "degree": string, "institution": string | null, "year": string | null } ],
  "experience": [ { "organization": string, "designation": string | null, "fromDate": string | null, "toDate": string | null } ],
  "skills": string[],
  "certifications": string[],
  "publications": string[]
}

Faculty full names must be normalized to this exact pattern where possible:
"[Salutation] [First Name] [Last Name] [Initial]" (e.g. "Dr. Ramesh Kumar S").

Document text:
---
\`;

async function parseResumeWithOpenAI(text: string): Promise<ResumeParseResult> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    throw new AppError('OPENAI_API_KEY is not configured on the server', 500);
  }

  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: \`Bearer \${apiKey}\`,
    },
    body: JSON.stringify({
      model: 'gpt-4o-mini',
      temperature: 0,
      messages: [
        {
          role: 'user',
          content: \`\${EXTRACTION_SCHEMA_PROMPT}\${text.slice(0, 12000)}\`,
        },
      ],
    }),
  });

  if (!response.ok) {
    const errBody = await response.text();
    throw new AppError(\`AI provider request failed (\${response.status}): \${errBody}\`, 502);
  }

  const data = await response.json();
  const rawContent: string = data?.choices?.[0]?.message?.content ?? '';
  const cleaned = rawContent.replace(/^\\\`\\\`\\\`json/i, '').replace(/\\\`\\\`\\\`$/, '').trim();

  let parsed: any;
  try {
    parsed = JSON.parse(cleaned);
  } catch (err) {
    throw new AppError('AI provider returned a non-JSON or malformed response', 502);
  }

  const fullName: string | null = parsed.fullName ?? null;
  const nameMatchesFacultyFormat = fullName ? NAME_FORMAT_REGEX.test(fullName) : false;

  const education: EducationEntry[] = Array.isArray(parsed.education)
    ? parsed.education.map((e: any) => ({
        degree: e.degree ?? 'Unknown',
        institution: e.institution ?? null,
        year: e.year ?? null,
        raw: \`\${e.degree ?? ''} \${e.institution ?? ''} \${e.year ?? ''}\`.trim(),
      }))
    : [];

  const experience: ExperienceEntry[] = Array.isArray(parsed.experience)
    ? parsed.experience.map((e: any) => {
        const fromDate = e.fromDate ? parseApproxDate(e.fromDate) : null;
        const toDate = e.toDate ? parseApproxDate(e.toDate) : null;
        const durationMonths = fromDate && toDate ? monthsBetween(fromDate, toDate) : null;
        return {
          organization: e.organization ?? 'Unknown Organization',
          designation: e.designation ?? null,
          fromDate: e.fromDate ?? null,
          toDate: e.toDate ?? null,
          durationMonths,
          raw: \`\${e.organization ?? ''} \${e.designation ?? ''}\`.trim(),
        };
      })
    : [];

  const totalExperienceMonths = experience.reduce((sum, e) => sum + (e.durationMonths || 0), 0);

  return {
    rawTextExcerpt: text.slice(0, 500),
    fullTextLength: text.length,
    personalDetails: {
      fullName,
      salutation: parsed.salutation ?? null,
      firstName: parsed.firstName ?? null,
      lastName: parsed.lastName ?? null,
      initial: parsed.initial ?? null,
      nameMatchesFacultyFormat,
      formattedSuggestion: fullName,
    },
    contact: {
      email: parsed.email ?? null,
      phone: parsed.phone ?? null,
      address: parsed.address ?? null,
    },
    education,
    experience,
    totalExperienceMonths,
    skills: Array.isArray(parsed.skills) ? parsed.skills : [],
    certifications: Array.isArray(parsed.certifications) ? parsed.certifications : [],
    publications: Array.isArray(parsed.publications) ? parsed.publications : [],
    confidence: {
      name: fullName ? 0.9 : 0,
      email: parsed.email ? 0.9 : 0,
      phone: parsed.phone ? 0.85 : 0,
      education: education.length > 0 ? 0.85 : 0,
      experience: experience.length > 0 ? 0.85 : 0,
      skills: (parsed.skills || []).length > 0 ? 0.8 : 0,
    },
    extractedAt: new Date().toISOString(),
    provider: 'openai',
  };
}

/* ------------------------------------------------------------------------
 * Public service API
 * ---------------------------------------------------------------------- */
export async function parseDocumentBuffer(
  buffer: Buffer,
  mimeType: string
): Promise<ResumeParseResult> {
  const text = await extractTextFromBuffer(buffer, mimeType);
  const provider = (process.env.AI_PROVIDER || 'local').toLowerCase();

  if (provider === 'openai') {
    return parseResumeWithOpenAI(text);
  }
  return parseResumeLocal(text);
}

export function validateFacultyNameFormat(fullName: string): boolean {
  return NAME_FORMAT_REGEX.test(fullName.trim());
}

export const aiParserService = {
  extractTextFromBuffer,
  parseDocumentBuffer,
  validateFacultyNameFormat,
  SUPPORTED_MIME_TYPES,
};

export default aiParserService;
`;

/* ========================================================================
 * 2. controllers/ai.controller.ts
 * ==================================================================== */
const AI_CONTROLLER = `import { Request, Response } from 'express';
import multer from 'multer';
import { asyncHandler } from '../utils/asyncHandler';
import { sendResponse } from '../utils/response';
import { AppError } from '../utils/AppError';
import {
  aiParserService,
  SUPPORTED_MIME_TYPES,
  ResumeParseResult,
} from '../services/ai-parser.service';

const MAX_FILE_SIZE_BYTES = 10 * 1024 * 1024; // 10 MB per file
const MAX_FILES_PER_REQUEST = 10;

const storage = multer.memoryStorage();

function fileFilter(
  _req: Request,
  file: Express.Multer.File,
  callback: multer.FileFilterCallback
) {
  if ((SUPPORTED_MIME_TYPES as readonly string[]).includes(file.mimetype)) {
    callback(null, true);
    return;
  }
  callback(new AppError(\`Unsupported file type: \${file.mimetype}\`, 415));
}

/**
 * Multer middleware for single-file resume upload.
 */
export const uploadSingle = multer({
  storage,
  limits: { fileSize: MAX_FILE_SIZE_BYTES },
  fileFilter,
}).single('file');

/**
 * Multer middleware for the drag-and-drop multi-file dashboard.
 * Accepts up to MAX_FILES_PER_REQUEST files under the field name "files".
 */
export const uploadMultiple = multer({
  storage,
  limits: { fileSize: MAX_FILE_SIZE_BYTES, files: MAX_FILES_PER_REQUEST },
  fileFilter,
}).array('files', MAX_FILES_PER_REQUEST);

/**
 * POST /api/ai/parse-resume
 * Accepts a single file buffer (field name "file") and returns
 * a structured JSON extraction of resume/document fields.
 */
export const parseSingleResume = asyncHandler(async (req: Request, res: Response) => {
  if (!req.file) {
    throw new AppError('No file was uploaded. Attach a file under field name "file".', 400);
  }

  const result: ResumeParseResult = await aiParserService.parseDocumentBuffer(
    req.file.buffer,
    req.file.mimetype
  );

  sendResponse(res, 200, 'Document parsed successfully', {
    fileName: req.file.originalname,
    fileSizeBytes: req.file.size,
    mimeType: req.file.mimetype,
    parsed: result,
  });
});

/**
 * POST /api/ai/parse-documents
 * Multi-file stream handler for the drag-and-drop dashboard.
 * Each file is parsed independently; partial failures do not abort
 * the whole batch — every file gets its own success/error outcome.
 */
export const parseMultipleDocuments = asyncHandler(async (req: Request, res: Response) => {
  const files = (req.files as Express.Multer.File[]) || [];

  if (files.length === 0) {
    throw new AppError('No files were uploaded. Attach files under field name "files".', 400);
  }

  const settled = await Promise.allSettled(
    files.map(async (file) => {
      const parsed = await aiParserService.parseDocumentBuffer(file.buffer, file.mimetype);
      return {
        fileName: file.originalname,
        fileSizeBytes: file.size,
        mimeType: file.mimetype,
        parsed,
      };
    })
  );

  const successes = settled
    .map((outcome, index) => ({ outcome, index }))
    .filter(({ outcome }) => outcome.status === 'fulfilled')
    .map(({ outcome }) => (outcome as PromiseFulfilledResult<any>).value);

  const failures = settled
    .map((outcome, index) => ({ outcome, index }))
    .filter(({ outcome }) => outcome.status === 'rejected')
    .map(({ outcome, index }) => ({
      fileName: files[index].originalname,
      error:
        (outcome as PromiseRejectedResult).reason instanceof AppError
          ? (outcome as PromiseRejectedResult).reason.message
          : 'Failed to parse document',
    }));

  sendResponse(res, 207, 'Batch document parsing completed', {
    totalFiles: files.length,
    successCount: successes.length,
    failureCount: failures.length,
    results: successes,
    errors: failures,
  });
});

/**
 * GET /api/ai/supported-formats
 */
export const getSupportedFormats = asyncHandler(async (_req: Request, res: Response) => {
  sendResponse(res, 200, 'Supported formats retrieved', {
    mimeTypes: SUPPORTED_MIME_TYPES,
    maxFileSizeBytes: MAX_FILE_SIZE_BYTES,
    maxFilesPerRequest: MAX_FILES_PER_REQUEST,
  });
});

/**
 * GET /api/ai/health
 */
export const aiHealthCheck = asyncHandler(async (_req: Request, res: Response) => {
  sendResponse(res, 200, 'AI engine operational', {
    provider: (process.env.AI_PROVIDER || 'local').toLowerCase(),
    timestamp: new Date().toISOString(),
  });
});

export const aiController = {
  uploadSingle,
  uploadMultiple,
  parseSingleResume,
  parseMultipleDocuments,
  getSupportedFormats,
  aiHealthCheck,
};

export default aiController;
`;

/* ========================================================================
 * 3. routes/ai.routes.ts
 * ==================================================================== */
const AI_ROUTES = `import { Router, Request, Response, NextFunction } from 'express';
import { authenticate } from '../middleware/auth';
import { authorize } from '../middleware/rbac';
import {
  uploadSingle,
  uploadMultiple,
  parseSingleResume,
  parseMultipleDocuments,
  getSupportedFormats,
  aiHealthCheck,
} from '../controllers/ai.controller';
import { AppError } from '../utils/AppError';

const router = Router();

/**
 * Wraps a multer middleware instance so its callback-style errors
 * (file too large, unsupported type, too many files, etc.) are
 * forwarded into the standard Express error pipeline instead of
 * crashing the request.
 */
function handleUpload(middleware: (req: Request, res: Response, cb: (err: unknown) => void) => void) {
  return (req: Request, res: Response, next: NextFunction) => {
    middleware(req, res, (err: unknown) => {
      if (err) {
        if (err instanceof AppError) {
          return next(err);
        }
        const message =
          err && typeof err === 'object' && 'message' in err
            ? String((err as { message: unknown }).message)
            : 'File upload failed';
        return next(new AppError(message, 400));
      }
      next();
    });
  };
}

// All AI endpoints require an authenticated session.
router.use(authenticate);

/**
 * GET /api/ai/health
 * Any authenticated role may check AI engine status.
 */
router.get('/health', aiHealthCheck);

/**
 * GET /api/ai/supported-formats
 */
router.get('/supported-formats', getSupportedFormats);

/**
 * POST /api/ai/parse-resume
 * Single-file resume/document parsing.
 * Restricted to roles that manage faculty/student records.
 */
router.post(
  '/parse-resume',
  authorize(['admin', 'iqac_coordinator', 'hod', 'faculty']),
  handleUpload(uploadSingle),
  parseSingleResume
);

/**
 * POST /api/ai/parse-documents
 * Multi-file drag-and-drop batch parsing for the dashboard.
 * Restricted to elevated roles due to batch volume/cost.
 */
router.post(
  '/parse-documents',
  authorize(['admin', 'iqac_coordinator', 'hod']),
  handleUpload(uploadMultiple),
  parseMultipleDocuments
);

export default router;
`;

/* ========================================================================
 * Write everything
 * ==================================================================== */
function run() {
  console.log('AccrediAI — Phase 3: AI Engine Integration Layer');
  console.log('==================================================');
  ensureDirs();

  writeFile('services/ai-parser.service.ts', AI_PARSER_SERVICE);
  writeFile('controllers/ai.controller.ts', AI_CONTROLLER);
  writeFile('routes/ai.routes.ts', AI_ROUTES);

  console.log('==================================================');
  console.log('Phase 3 complete. Files written under backend/src/.');
  console.log('');
  console.log('Reminder — install runtime dependencies before building:');
  console.log('  npm install multer pdf-parse mammoth');
  console.log('  npm install -D @types/multer @types/pdf-parse');
  console.log('');
  console.log('Mount the router in your main app/router file, e.g.:');
  console.log("  import aiRoutes from './routes/ai.routes';");
  console.log("  app.use('/api/ai', aiRoutes);");
  console.log('');
  console.log('Set AI_PROVIDER=openai and OPENAI_API_KEY to use the remote');
  console.log('parsing path instead of the built-in local heuristic engine.');
}

run();