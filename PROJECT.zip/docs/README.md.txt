# Documentation

This folder contains all technical documentation for the AccrediAI project.

Contents

- System Architecture
- Database Schema
- ER Diagram
- API Documentation
- AI Workflow
- Project Architecture
- Security Architecture
- Deployment Guide