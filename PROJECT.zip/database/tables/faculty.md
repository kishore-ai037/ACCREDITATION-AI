# Faculty Table

## Table: faculty

| Field | Type | Description |
|-------|------|-------------|
| faculty_id | UUID | Primary Key |
| department_id | UUID | Foreign Key (Departments) |
| employee_id | VARCHAR(30) | College Employee ID |
| name | VARCHAR(100) | Faculty Name |
| designation | VARCHAR(100) | Assistant Professor / Associate Professor / Professor |
| qualification | VARCHAR(100) | Highest Qualification |
| specialization | VARCHAR(150) | Area of Specialization |
| experience | DECIMAL(4,1) | Years of Experience |
| email | VARCHAR(100) | Official Email |
| phone | VARCHAR(15) | Mobile Number |
| joining_date | DATE | Date of Joining |
| research_area | TEXT | Research Interests |
| publications | INTEGER | Total Publications |
| patents | INTEGER | Total Patents |
| projects | INTEGER | Research Projects |
| status | BOOLEAN | Active / Inactive |
| created_at | TIMESTAMP | Record Created Time |
| updated_at | TIMESTAMP | Last Updated Time |