# AI Analysis Table

## Table: ai_analysis

| Field | Type | Description |
|-------|------|-------------|
| analysis_id | UUID | Primary Key |
| document_id | UUID | Foreign Key (Documents) |
| ai_model | VARCHAR(100) | AI Model Used |
| extracted_text | TEXT | Extracted PDF Text |
| summary | TEXT | AI Generated Summary |
| keywords | TEXT | Important Keywords |
| criterion | VARCHAR(20) | NAAC Criterion |
| confidence_score | DECIMAL(5,2) | AI Confidence (%) |
| missing_evidence | TEXT | Missing Documents Identified |
| recommendations | TEXT | AI Suggestions |
| analyzed_at | TIMESTAMP | Analysis Time |