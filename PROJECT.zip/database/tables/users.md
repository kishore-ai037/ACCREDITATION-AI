# Users Table

## Table: users

| Field | Type | Description |
|-------|------|-------------|
| user_id | UUID | Primary Key |
| name | VARCHAR(100) | User Name |
| email | VARCHAR(100) | Email Address |
| password | VARCHAR(255) | Encrypted Password |
| role | VARCHAR(50) | Admin, IQAC, HOD, Faculty, etc. |
| department_id | UUID | Foreign Key (Departments) |
| phone | VARCHAR(15) | Mobile Number |
| status | BOOLEAN | Active / Inactive |
| created_at | TIMESTAMP | Record Created Time |
| updated_at | TIMESTAMP | Last Updated Time |