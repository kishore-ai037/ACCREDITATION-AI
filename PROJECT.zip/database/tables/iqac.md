# IQAC Table

## Table: iqac

| Field | Type | Description |
|-------|------|-------------|
| iqac_id | UUID | Primary Key |
| report_type | VARCHAR(50) | AQAR / SSR / Best Practice |
| title | VARCHAR(255) | Report Title |
| academic_year | VARCHAR(20) | Academic Year |
| document_id | UUID | Foreign Key (Documents) |
| criterion | VARCHAR(20) | NAAC Criterion (1-7) |
| status | VARCHAR(30) | Draft / Submitted / Approved |
| generated_by_ai | BOOLEAN | AI Generated |
| created_at | TIMESTAMP | Record Created Time |
| updated_at | TIMESTAMP | Last Updated Time |