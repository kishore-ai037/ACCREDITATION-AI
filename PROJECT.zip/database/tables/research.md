# Research Table

## Table: research

| Field | Type | Description |
|-------|------|-------------|
| research_id | UUID | Primary Key |
| faculty_id | UUID | Foreign Key (Faculty) |
| title | VARCHAR(255) | Research Title |
| type | VARCHAR(100) | Journal, Conference, Patent, Project |
| publisher | VARCHAR(255) | Publisher / Journal |
| year | INTEGER | Publication Year |
| doi | VARCHAR(255) | DOI / Reference |
| status | VARCHAR(50) | Published / Ongoing |
| created_at | TIMESTAMP | Record Created Time |
| updated_at | TIMESTAMP | Last Updated Time |