# Outcome Based Education (OBE)

## Table: obe

| Field | Type | Description |
|-------|------|-------------|
| obe_id | UUID | Primary Key |
| course_id | UUID | Foreign Key (Courses) |
| co_number | VARCHAR(10) | Course Outcome (CO1, CO2...) |
| co_description | TEXT | Course Outcome Description |
| po_number | VARCHAR(10) | Program Outcome (PO1, PO2...) |
| pso_number | VARCHAR(10) | Program Specific Outcome |
| mapping_level | INTEGER | CO-PO Mapping Level (1-3) |
| academic_year | VARCHAR(20) | Academic Year |
| created_at | TIMESTAMP | Record Created Time |
| updated_at | TIMESTAMP | Last Updated Time |