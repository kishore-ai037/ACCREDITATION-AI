# Students Table

## Table: students

| Field | Type | Description |
|-------|------|-------------|
| student_id | UUID | Primary Key |
| register_number | VARCHAR(30) | University Register Number |
| name | VARCHAR(100) | Student Name |
| department_id | UUID | Foreign Key (Departments) |
| batch | VARCHAR(20) | Academic Batch |
| year | INTEGER | Current Year |
| semester | INTEGER | Current Semester |
| section | VARCHAR(10) | Section |
| email | VARCHAR(100) | Student Email |
| phone | VARCHAR(15) | Mobile Number |
| cgpa | DECIMAL(3,2) | Current CGPA |
| placement_status | BOOLEAN | Placed / Not Placed |
| created_at | TIMESTAMP | Record Created Time |
| updated_at | TIMESTAMP | Last Updated Time |