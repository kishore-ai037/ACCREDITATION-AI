# Documents Table

## Table: documents

| Field | Type | Description |
|-------|------|-------------|
| document_id | UUID | Primary Key |
| title | VARCHAR(255) | Document Title |
| category | VARCHAR(100) | NAAC, NBA, IQAC, Research, OBE, etc. |
| department_id | UUID | Foreign Key (Departments) |
| uploaded_by | UUID | Foreign Key (Users) |
| file_name | VARCHAR(255) | Original File Name |
| file_path | TEXT | File Storage Path |
| file_type | VARCHAR(20) | PDF, DOCX, XLSX, TXT |
| document_year | INTEGER | Academic Year |
| ai_status | BOOLEAN | AI Analysis Completed |
| summary | TEXT | AI Generated Summary |
| uploaded_at | TIMESTAMP | Upload Time |
| updated_at | TIMESTAMP | Last Updated Time |