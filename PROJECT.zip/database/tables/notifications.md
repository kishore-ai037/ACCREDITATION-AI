# Notifications Table

## Table: notifications

| Field | Type | Description |
|-------|------|-------------|
| notification_id | UUID | Primary Key |
| user_id | UUID | Foreign Key (Users) |
| title | VARCHAR(255) | Notification Title |
| message | TEXT | Notification Message |
| type | VARCHAR(50) | Alert / Reminder / Warning |
| is_read | BOOLEAN | Read Status |
| created_at | TIMESTAMP | Notification Time |