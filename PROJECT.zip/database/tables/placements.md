# Placements Table

## Table: placements

| Field | Type | Description |
|-------|------|-------------|
| placement_id | UUID | Primary Key |
| student_id | UUID | Foreign Key (Students) |
| company_name | VARCHAR(255) | Company Name |
| job_role | VARCHAR(100) | Job Role |
| package_lpa | DECIMAL(5,2) | Salary (LPA) |
| placement_date | DATE | Placement Date |
| placement_type | VARCHAR(50) | Campus / Off Campus |
| created_at | TIMESTAMP | Record Created Time |
| updated_at | TIMESTAMP | Last Updated Time |