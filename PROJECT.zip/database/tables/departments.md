# Departments Table

## Table: departments

| Field | Type | Description |
|-------|------|-------------|
| department_id | UUID | Primary Key |
| department_name | VARCHAR(100) | Department Name |
| department_code | VARCHAR(20) | Department Code |
| hod_name | VARCHAR(100) | Head of Department |
| email | VARCHAR(100) | Department Email |
| phone | VARCHAR(15) | Contact Number |
| vision | TEXT | Department Vision |
| mission | TEXT | Department Mission |
| established_year | INTEGER | Year Established |
| ug_programs | INTEGER | Number of UG Programmes |
| pg_programs | INTEGER | Number of PG Programmes |
| research_center | BOOLEAN | Research Centre Available |
| accreditation | VARCHAR(100) | NBA/NAAC Status |
| status | BOOLEAN | Active / Inactive |
| created_at | TIMESTAMP | Record Created Time |
| updated_at | TIMESTAMP | Last Updated Time |