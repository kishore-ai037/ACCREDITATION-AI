# Courses Table

## Table: courses

| Field | Type | Description |
|-------|------|-------------|
| course_id | UUID | Primary Key |
| course_code | VARCHAR(20) | Course Code |
| course_name | VARCHAR(255) | Course Name |
| department_id | UUID | Foreign Key (Departments) |
| semester | INTEGER | Semester Number |
| credits | INTEGER | Course Credits |
| regulation | VARCHAR(20) | Regulation (2021, 2025, etc.) |
| created_at | TIMESTAMP | Record Created Time |
| updated_at | TIMESTAMP | Last Updated Time |