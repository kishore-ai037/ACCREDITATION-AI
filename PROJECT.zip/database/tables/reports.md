# Reports Table

## Table: reports

| Field | Type | Description |
|-------|------|-------------|
| report_id | UUID | Primary Key |
| report_name | VARCHAR(255) | Report Name |
| report_type | VARCHAR(100) | PDF / Excel / Word |
| generated_by | UUID | Foreign Key (Users) |
| generated_date | TIMESTAMP | Report Generation Time |
| download_count | INTEGER | Number of Downloads |
| created_at | TIMESTAMP | Record Created Time |