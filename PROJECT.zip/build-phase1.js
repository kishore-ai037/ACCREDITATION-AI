#!/usr/bin/env node
/**
 * build-phase1.js
 * Principal Backend Engineer — Phase 1 (Departments Module) generator.
 *
 * Assumes the following shared foundation already exists in the project
 * (built in Phase 0):
 *   backend/src/config/database.ts   -> exports `pool` (pg.Pool)
 *   backend/src/middleware/auth.ts   -> exports `authenticate`
 *   backend/src/middleware/rbac.ts   -> exports `authorize(...permissions)`
 *   backend/src/middleware/validate.ts -> exports `validate` (express-validator result handler)
 *   backend/src/middleware/asyncHandler.ts -> exports `asyncHandler`
 *   backend/src/utils/response.ts    -> exports `sendSuccess(res, data, message, meta?, statusCode?)`
 *   backend/src/utils/AppError.ts    -> exports class `AppError(message, statusCode)`
 *   backend/src/utils/pagination.ts  -> exports `getPagination`, `buildPaginationMeta`
 *
 * Run with:  node build-phase1.js
 */

const fs = require("fs");
const path = require("path");

const ROOT = path.resolve(__dirname, "backend", "src");

function writeFile(relativePath, content) {
  const fullPath = path.join(ROOT, relativePath);
  const dir = path.dirname(fullPath);
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(fullPath, content, { encoding: "utf8" });
  console.log("[created] " + path.relative(process.cwd(), fullPath));
}

// ─────────────────────────────────────────────────────────────────────────
// 1. department.model.ts
// ─────────────────────────────────────────────────────────────────────────
const modelContent = `import { Pool, PoolClient } from 'pg';
import { pool } from '../config/database';

export interface Department {
  id: string;
  institution_id: string;
  name: string;
  code: string;
  hod_name: string | null;
  established: number | null;
  intake: number;
  nba_accredited: boolean;
  nba_valid_till: string | null;
  description: string | null;
  is_active: boolean;
  created_at: Date;
  updated_at: Date;
}

export interface DepartmentWithStats extends Department {
  faculty_count: number;
  student_count: number;
  document_count: number;
}

export interface DepartmentCreateInput {
  institution_id: string;
  name: string;
  code: string;
  hod_name?: string;
  established?: number;
  intake?: number;
  nba_accredited?: boolean;
  nba_valid_till?: string;
  description?: string;
}

export interface DepartmentUpdateInput {
  name?: string;
  code?: string;
  hod_name?: string;
  established?: number;
  intake?: number;
  nba_accredited?: boolean;
  nba_valid_till?: string;
  description?: string;
  is_active?: boolean;
}

export interface DepartmentFilters {
  institution_id: string;
  search?: string;
  is_active?: boolean;
  nba_accredited?: boolean;
}

const TABLE = 'departments';

export class DepartmentModel {
  // ───────────────────────── Hooks ─────────────────────────

  private static beforeCreate(input: DepartmentCreateInput): DepartmentCreateInput {
    return {
      ...input,
      name: input.name.trim(),
      code: input.code.trim().toUpperCase(),
      hod_name: input.hod_name ? input.hod_name.trim() : undefined,
      description: input.description ? input.description.trim() : undefined,
      intake: input.intake ?? 60,
      nba_accredited: input.nba_accredited ?? false,
    };
  }

  private static beforeUpdate(input: DepartmentUpdateInput): DepartmentUpdateInput {
    const sanitized: DepartmentUpdateInput = { ...input };
    if (sanitized.name) sanitized.name = sanitized.name.trim();
    if (sanitized.code) sanitized.code = sanitized.code.trim().toUpperCase();
    if (sanitized.hod_name) sanitized.hod_name = sanitized.hod_name.trim();
    if (sanitized.description) sanitized.description = sanitized.description.trim();
    return sanitized;
  }

  // ───────────────────────── Index Slots ─────────────────────────
  /**
   * Ensures all performance-critical index "slots" exist for the departments
   * table. Idempotent (IF NOT EXISTS) — safe to call on every boot/migration.
   */
  static async ensureIndexes(client: Pool | PoolClient = pool): Promise<void> {
    await client.query(
      'CREATE UNIQUE INDEX IF NOT EXISTS idx_departments_institution_code ' +
      'ON ' + TABLE + ' (institution_id, code)'
    );

    await client.query(
      'CREATE INDEX IF NOT EXISTS idx_departments_institution_active ' +
      'ON ' + TABLE + ' (institution_id, is_active)'
    );

    await client.query(
      'CREATE INDEX IF NOT EXISTS idx_departments_nba ' +
      'ON ' + TABLE + ' (institution_id, nba_accredited)'
    );

    // Trigram index powers fast ILIKE search on name/code. Requires pg_trgm;
    // wrapped defensively in case the DB role lacks CREATE EXTENSION rights.
    try {
      await client.query('CREATE EXTENSION IF NOT EXISTS pg_trgm');
      await client.query(
        'CREATE INDEX IF NOT EXISTS idx_departments_name_trgm ' +
        'ON ' + TABLE + ' USING gin (name gin_trgm_ops)'
      );
    } catch (err) {
      console.warn('[DepartmentModel] Skipped pg_trgm index (insufficient privilege or extension unavailable):', (err as Error).message);
    }
  }

  // ───────────────────────── CRUD ─────────────────────────

  static async create(input: DepartmentCreateInput): Promise<Department> {
    const data = this.beforeCreate(input);
    const result = await pool.query<Department>(
      'INSERT INTO ' + TABLE +
      ' (institution_id, name, code, hod_name, established, intake, nba_accredited, nba_valid_till, description) ' +
      'VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *',
      [
        data.institution_id,
        data.name,
        data.code,
        data.hod_name ?? null,
        data.established ?? null,
        data.intake ?? 60,
        data.nba_accredited ?? false,
        data.nba_valid_till ?? null,
        data.description ?? null,
      ]
    );
    return result.rows[0];
  }

  static async findById(id: string, institution_id: string): Promise<Department | null> {
    const result = await pool.query<Department>(
      'SELECT * FROM ' + TABLE + ' WHERE id = $1 AND institution_id = $2 LIMIT 1',
      [id, institution_id]
    );
    return result.rows[0] ?? null;
  }

  static async findByCode(code: string, institution_id: string, excludeId?: string): Promise<Department | null> {
    const params: any[] = [code.trim().toUpperCase(), institution_id];
    let sql = 'SELECT * FROM ' + TABLE + ' WHERE code = $1 AND institution_id = $2';
    if (excludeId) {
      params.push(excludeId);
      sql += ' AND id <> $3';
    }
    const result = await pool.query<Department>(sql + ' LIMIT 1', params);
    return result.rows[0] ?? null;
  }

  static async findAll(
    filters: DepartmentFilters,
    page: number,
    limit: number
  ): Promise<{ rows: DepartmentWithStats[]; total: number }> {
    const conditions: string[] = ['d.institution_id = $1'];
    const params: any[] = [filters.institution_id];
    let idx = 2;

    if (filters.search) {
      conditions.push('(d.name ILIKE $' + idx + ' OR d.code ILIKE $' + idx + ')');
      params.push('%' + filters.search + '%');
      idx++;
    }
    if (typeof filters.is_active === 'boolean') {
      conditions.push('d.is_active = $' + idx);
      params.push(filters.is_active);
      idx++;
    }
    if (typeof filters.nba_accredited === 'boolean') {
      conditions.push('d.nba_accredited = $' + idx);
      params.push(filters.nba_accredited);
      idx++;
    }

    const whereClause = conditions.join(' AND ');
    const offset = (page - 1) * limit;
    const countParams = params.slice();

    const dataQueryParts = [
      'SELECT d.*,',
      'COALESCE(f.faculty_count, 0)::int AS faculty_count,',
      'COALESCE(s.student_count, 0)::int AS student_count,',
      'COALESCE(doc.document_count, 0)::int AS document_count',
      'FROM ' + TABLE + ' d',
      'LEFT JOIN (SELECT department_id, COUNT(*) AS faculty_count FROM faculty GROUP BY department_id) f ON f.department_id = d.id',
      'LEFT JOIN (SELECT department_id, COUNT(*) AS student_count FROM students GROUP BY department_id) s ON s.department_id = d.id',
      'LEFT JOIN (SELECT department_id, COUNT(*) AS document_count FROM documents WHERE department_id IS NOT NULL GROUP BY department_id) doc ON doc.department_id = d.id',
      'WHERE ' + whereClause,
      'ORDER BY d.name ASC',
      'LIMIT $' + idx + ' OFFSET $' + (idx + 1),
    ];
    params.push(limit, offset);

    const countQuery = 'SELECT COUNT(*)::int AS total FROM ' + TABLE + ' d WHERE ' + whereClause;

    const [dataResult, countResult] = await Promise.all([
      pool.query<DepartmentWithStats>(dataQueryParts.join(' '), params),
      pool.query<{ total: number }>(countQuery, countParams),
    ]);

    return { rows: dataResult.rows, total: countResult.rows[0]?.total ?? 0 };
  }

  static async update(id: string, institution_id: string, input: DepartmentUpdateInput): Promise<Department | null> {
    const data = this.beforeUpdate(input);
    const fields = Object.keys(data) as (keyof DepartmentUpdateInput)[];
    if (fields.length === 0) return this.findById(id, institution_id);

    const setClauses = fields.map((field, i) => field + ' = $' + (i + 3));
    const values = fields.map((field) => (data as any)[field]);

    const result = await pool.query<Department>(
      'UPDATE ' + TABLE + ' SET ' + setClauses.join(', ') + ', updated_at = NOW() ' +
      'WHERE id = $1 AND institution_id = $2 RETURNING *',
      [id, institution_id, ...values]
    );
    return result.rows[0] ?? null;
  }

  static async softDelete(id: string, institution_id: string): Promise<boolean> {
    const result = await pool.query(
      'UPDATE ' + TABLE + ' SET is_active = false, updated_at = NOW() WHERE id = $1 AND institution_id = $2',
      [id, institution_id]
    );
    return (result.rowCount ?? 0) > 0;
  }

  static async hardDelete(id: string, institution_id: string): Promise<boolean> {
    const result = await pool.query(
      'DELETE FROM ' + TABLE + ' WHERE id = $1 AND institution_id = $2',
      [id, institution_id]
    );
    return (result.rowCount ?? 0) > 0;
  }

  static async hasDependents(id: string): Promise<boolean> {
    const result = await pool.query<{ count: string }>(
      'SELECT ' +
      '(SELECT COUNT(*) FROM faculty WHERE department_id = $1) + ' +
      '(SELECT COUNT(*) FROM students WHERE department_id = $1) AS count',
      [id]
    );
    return Number(result.rows[0]?.count ?? 0) > 0;
  }

  static async getInstitutionStats(institution_id: string) {
    const result = await pool.query(
      'SELECT ' +
      'COUNT(*)::int AS total_departments, ' +
      "COUNT(*) FILTER (WHERE is_active)::int AS active_departments, " +
      'COUNT(*) FILTER (WHERE nba_accredited)::int AS nba_accredited_departments ' +
      'FROM ' + TABLE + ' WHERE institution_id = $1',
      [institution_id]
    );
    return result.rows[0];
  }
}
`;

// ─────────────────────────────────────────────────────────────────────────
// 2. department.service.ts
// ─────────────────────────────────────────────────────────────────────────
const serviceContent = `import {
  DepartmentModel,
  DepartmentCreateInput,
  DepartmentUpdateInput,
  DepartmentFilters,
} from '../models/department.model';
import { AppError } from '../utils/AppError';
import { getPagination, buildPaginationMeta } from '../utils/pagination';

interface ListDepartmentsQuery {
  institution_id: string;
  search?: string;
  is_active?: string | boolean;
  nba_accredited?: string | boolean;
  page?: string | number;
  limit?: string | number;
}

function toBoolean(value: unknown): boolean | undefined {
  if (typeof value === 'boolean') return value;
  if (value === 'true') return true;
  if (value === 'false') return false;
  return undefined;
}

export class DepartmentService {
  static async createDepartment(input: DepartmentCreateInput) {
    const existing = await DepartmentModel.findByCode(input.code, input.institution_id);
    if (existing) {
      throw new AppError(
        'Department code "' + input.code.toUpperCase() + '" already exists in this institution.',
        409
      );
    }
    return DepartmentModel.create(input);
  }

  static async listDepartments(query: ListDepartmentsQuery) {
    const { page, limit } = getPagination(query.page, query.limit);

    const filters: DepartmentFilters = {
      institution_id: query.institution_id,
      search: query.search ? query.search.trim() : undefined,
      is_active: toBoolean(query.is_active),
      nba_accredited: toBoolean(query.nba_accredited),
    };

    const { rows, total } = await DepartmentModel.findAll(filters, page, limit);

    return {
      data: rows,
      meta: buildPaginationMeta(total, page, limit),
    };
  }

  static async getDepartmentById(id: string, institution_id: string) {
    const department = await DepartmentModel.findById(id, institution_id);
    if (!department) {
      throw new AppError('Department not found.', 404);
    }
    return department;
  }

  static async updateDepartment(id: string, institution_id: string, input: DepartmentUpdateInput) {
    const existing = await DepartmentModel.findById(id, institution_id);
    if (!existing) {
      throw new AppError('Department not found.', 404);
    }

    if (input.code && input.code.trim().toUpperCase() !== existing.code) {
      const codeOwner = await DepartmentModel.findByCode(input.code, institution_id, id);
      if (codeOwner) {
        throw new AppError(
          'Department code "' + input.code.toUpperCase() + '" already exists in this institution.',
          409
        );
      }
    }

    const updated = await DepartmentModel.update(id, institution_id, input);
    if (!updated) {
      throw new AppError('Department could not be updated.', 500);
    }
    return updated;
  }

  static async deleteDepartment(id: string, institution_id: string, hardDelete = false) {
    const existing = await DepartmentModel.findById(id, institution_id);
    if (!existing) {
      throw new AppError('Department not found.', 404);
    }

    if (hardDelete) {
      const hasDependents = await DepartmentModel.hasDependents(id);
      if (hasDependents) {
        throw new AppError(
          'This department has faculty or students linked to it and cannot be permanently deleted. Deactivate it instead.',
          409
        );
      }
    }

    const deleted = hardDelete
      ? await DepartmentModel.hardDelete(id, institution_id)
      : await DepartmentModel.softDelete(id, institution_id);

    if (!deleted) {
      throw new AppError('Department could not be deleted.', 500);
    }
    return { id, deleted: true, hardDelete };
  }

  static async getDepartmentStats(institution_id: string) {
    return DepartmentModel.getInstitutionStats(institution_id);
  }
}
`;

// ─────────────────────────────────────────────────────────────────────────
// 3. department.validator.ts
// ─────────────────────────────────────────────────────────────────────────
const validatorContent = `import { body, param, query } from 'express-validator';

export const createDepartmentValidator = [
  body('name')
    .trim()
    .notEmpty().withMessage('Department name is required.')
    .isLength({ min: 2, max: 150 }).withMessage('Department name must be between 2 and 150 characters.'),
  body('code')
    .trim()
    .notEmpty().withMessage('Department code is required.')
    .isLength({ min: 2, max: 10 }).withMessage('Department code must be between 2 and 10 characters.')
    .matches(/^[A-Za-z0-9]+$/).withMessage('Department code must be alphanumeric.'),
  body('hod_name')
    .optional({ nullable: true })
    .trim()
    .isLength({ max: 150 }).withMessage('HoD name must not exceed 150 characters.'),
  body('established')
    .optional({ nullable: true })
    .isInt({ min: 1800, max: new Date().getFullYear() }).withMessage('Established year is invalid.'),
  body('intake')
    .optional({ nullable: true })
    .isInt({ min: 1, max: 2000 }).withMessage('Intake must be a positive number.'),
  body('nba_accredited')
    .optional({ nullable: true })
    .isBoolean().withMessage('nba_accredited must be a boolean.'),
  body('nba_valid_till')
    .optional({ nullable: true })
    .isISO8601().withMessage('nba_valid_till must be a valid date.'),
  body('description')
    .optional({ nullable: true })
    .trim()
    .isLength({ max: 1000 }).withMessage('Description must not exceed 1000 characters.'),
];

export const updateDepartmentValidator = [
  param('id').isUUID().withMessage('Invalid department id.'),
  body('name')
    .optional()
    .trim()
    .isLength({ min: 2, max: 150 }).withMessage('Department name must be between 2 and 150 characters.'),
  body('code')
    .optional()
    .trim()
    .isLength({ min: 2, max: 10 }).withMessage('Department code must be between 2 and 10 characters.')
    .matches(/^[A-Za-z0-9]+$/).withMessage('Department code must be alphanumeric.'),
  body('hod_name')
    .optional({ nullable: true })
    .trim()
    .isLength({ max: 150 }).withMessage('HoD name must not exceed 150 characters.'),
  body('established')
    .optional({ nullable: true })
    .isInt({ min: 1800, max: new Date().getFullYear() }).withMessage('Established year is invalid.'),
  body('intake')
    .optional({ nullable: true })
    .isInt({ min: 1, max: 2000 }).withMessage('Intake must be a positive number.'),
  body('nba_accredited')
    .optional({ nullable: true })
    .isBoolean().withMessage('nba_accredited must be a boolean.'),
  body('nba_valid_till')
    .optional({ nullable: true })
    .isISO8601().withMessage('nba_valid_till must be a valid date.'),
  body('description')
    .optional({ nullable: true })
    .trim()
    .isLength({ max: 1000 }).withMessage('Description must not exceed 1000 characters.'),
  body('is_active')
    .optional({ nullable: true })
    .isBoolean().withMessage('is_active must be a boolean.'),
];

export const departmentIdValidator = [
  param('id').isUUID().withMessage('Invalid department id.'),
];

export const listDepartmentsValidator = [
  query('page').optional().isInt({ min: 1 }).withMessage('page must be a positive integer.'),
  query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('limit must be between 1 and 100.'),
  query('search').optional().trim().isLength({ max: 100 }),
  query('is_active').optional().isBoolean(),
  query('nba_accredited').optional().isBoolean(),
];

export const deleteDepartmentValidator = [
  param('id').isUUID().withMessage('Invalid department id.'),
  query('hard').optional().isBoolean().withMessage('hard must be a boolean.'),
];
`;

// ─────────────────────────────────────────────────────────────────────────
// 4. department.controller.ts
// ─────────────────────────────────────────────────────────────────────────
const controllerContent = `import { Request, Response } from 'express';
import { asyncHandler } from '../middleware/asyncHandler';
import { sendSuccess } from '../utils/response';
import { DepartmentService } from '../services/department.service';

export const createDepartment = asyncHandler(async (req: Request, res: Response) => {
  const institution_id = req.user!.institution_id;
  const department = await DepartmentService.createDepartment({
    ...req.body,
    institution_id,
  });
  return sendSuccess(res, department, 'Department created successfully.', undefined, 201);
});

export const getDepartments = asyncHandler(async (req: Request, res: Response) => {
  const institution_id = req.user!.institution_id;
  const { data, meta } = await DepartmentService.listDepartments({
    ...(req.query as Record<string, string>),
    institution_id,
  });
  return sendSuccess(res, data, 'Departments fetched successfully.', meta);
});

export const getDepartmentById = asyncHandler(async (req: Request, res: Response) => {
  const institution_id = req.user!.institution_id;
  const department = await DepartmentService.getDepartmentById(req.params.id, institution_id);
  return sendSuccess(res, department, 'Department fetched successfully.');
});

export const updateDepartment = asyncHandler(async (req: Request, res: Response) => {
  const institution_id = req.user!.institution_id;
  const department = await DepartmentService.updateDepartment(req.params.id, institution_id, req.body);
  return sendSuccess(res, department, 'Department updated successfully.');
});

export const deleteDepartment = asyncHandler(async (req: Request, res: Response) => {
  const institution_id = req.user!.institution_id;
  const hardDelete = req.query.hard === 'true';
  const result = await DepartmentService.deleteDepartment(req.params.id, institution_id, hardDelete);
  return sendSuccess(res, result, 'Department deleted successfully.');
});

export const getDepartmentStats = asyncHandler(async (req: Request, res: Response) => {
  const institution_id = req.user!.institution_id;
  const stats = await DepartmentService.getDepartmentStats(institution_id);
  return sendSuccess(res, stats, 'Department statistics fetched successfully.');
});
`;

// ─────────────────────────────────────────────────────────────────────────
// 5. department.routes.ts
// ─────────────────────────────────────────────────────────────────────────
const routesContent = `import { Router } from 'express';
import { authenticate } from '../middleware/auth';
import { authorize } from '../middleware/rbac';
import { validate } from '../middleware/validate';
import {
  createDepartment,
  getDepartments,
  getDepartmentById,
  updateDepartment,
  deleteDepartment,
  getDepartmentStats,
} from '../controllers/department.controller';
import {
  createDepartmentValidator,
  updateDepartmentValidator,
  departmentIdValidator,
  listDepartmentsValidator,
  deleteDepartmentValidator,
} from '../validators/department.validator';

const router = Router();

router.use(authenticate);

router.get('/stats', authorize('department:read'), getDepartmentStats);

router.get('/', authorize('department:read'), listDepartmentsValidator, validate, getDepartments);

router.get('/:id', authorize('department:read'), departmentIdValidator, validate, getDepartmentById);

router.post('/', authorize('department:create'), createDepartmentValidator, validate, createDepartment);

router.put('/:id', authorize('department:update'), updateDepartmentValidator, validate, updateDepartment);

router.delete('/:id', authorize('department:delete'), deleteDepartmentValidator, validate, deleteDepartment);

export default router;
`;

// ─────────────────────────────────────────────────────────────────────────
// Execute
// ─────────────────────────────────────────────────────────────────────────
console.log("Building Phase 1 — Departments Module...\n");

writeFile(path.join("models", "department.model.ts"), modelContent);
writeFile(path.join("services", "department.service.ts"), serviceContent);
writeFile(path.join("validators", "department.validator.ts"), validatorContent);
writeFile(path.join("controllers", "department.controller.ts"), controllerContent);
writeFile(path.join("routes", "department.routes.ts"), routesContent);

console.log("\nPhase 1 (Departments Module) generated successfully.");
console.log("Next step: mount the router in your main routes index, e.g.");
console.log("  import departmentRoutes from './department.routes';");
console.log("  router.use('/departments', departmentRoutes);");