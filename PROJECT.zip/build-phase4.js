#!/usr/bin/env node
/**
 * build-phase4.js
 * AccrediAI — Phase 4: Core Platform Modules
 *
 * Programmatically writes complete Model-Service-Controller-Route files for:
 *   1. Student Records & Marksheets Verification
 *        models/student-record.model.ts
 *        services/student-record.service.ts
 *        controllers/student-record.controller.ts
 *        routes/student-record.routes.ts
 *   2. Research, Consultancy & Patents Mapping Engine
 *        models/research.model.ts
 *        services/research.service.ts
 *        controllers/research.controller.ts
 *        routes/research.routes.ts
 *   3. Placement Statistics, Recruiters Log & Training Module
 *        models/placement.model.ts        (PlacementModel, RecruiterModel, TrainingProgramModel)
 *        services/placement.service.ts    (PlacementService, RecruiterService, TrainingProgramService)
 *        controllers/placement.controller.ts
 *        routes/placement.routes.ts
 *   4. NAAC & NBA Attainment Compliance Loop + IQAC Audit Logs Engine
 *        models/compliance.model.ts        (ComplianceCriteriaModel, ComplianceRecordModel, AuditLogModel)
 *        services/compliance.service.ts
 *        controllers/compliance.controller.ts
 *        routes/compliance.routes.ts
 *
 * Assumes the Phase 0 foundation already exists:
 *   backend/src/config/database.ts        exports 'pool' (pg Pool; pool.query(text, params))
 *   backend/src/middleware/auth.ts        exports 'authenticate'
 *   backend/src/middleware/rbac.ts        exports 'authorize(roles: string[])'
 *   backend/src/utils/response.ts         exports 'sendResponse(res, statusCode, message, data)'
 *   backend/src/utils/AppError.ts         exports 'AppError' (message, statusCode)
 *   backend/src/utils/asyncHandler.ts     exports 'asyncHandler'
 *   backend/src/utils/pagination.ts       exports:
 *     getPagination(query): { page: number; limit: number }
 *     buildMeta(total: number, page: number, limit: number): { total, page, limit, totalPages }
 *   (matches the pagination utility already established in the Phase 1 script)
 *
 * Expected DB tables (raw SQL, no ORM — same pattern as Phase 1/2):
 *   student_records, research_records, placements, recruiters, training_programs,
 *   compliance_criteria, compliance_records, audit_logs
 *
 * Run:  node build-phase4.js
 *
 * Note: RBAC role strings used across these routes —
 *   admin, iqac_coordinator, hod, faculty, student, placement_officer
 * — adjust to match your actual role enum if it differs.
 */

const fs = require('fs');
const path = require('path');

const ROOT = path.join(process.cwd(), 'backend', 'src');
const DIRS = ['models', 'services', 'controllers', 'routes'].map((d) => path.join(ROOT, d));

function ensureDirs() {
  DIRS.forEach((dir) => {
    fs.mkdirSync(dir, { recursive: true });
    console.log('[dir]  ensured ' + dir);
  });
}

function writeFile(relativePath, content) {
  const fullPath = path.join(ROOT, relativePath);
  fs.mkdirSync(path.dirname(fullPath), { recursive: true });
  fs.writeFileSync(fullPath, content, { encoding: 'utf8' });
  console.log('[file] written ' + fullPath + ' (' + content.length + ' bytes)');
}

/* ---- models/student-record.model.ts ---- */
const STUDENT_RECORD_MODEL = `import { pool } from '../config/database';
import { AppError } from '../utils/AppError';

export type VerificationStatus = 'pending' | 'verified' | 'rejected';

export interface SubjectMark {
  subjectCode: string;
  subjectName: string;
  credits: number;
  marksObtained: number;
  maxMarks: number;
  grade: string;
}

export interface StudentRecordRow {
  id: number;
  student_id: number;
  academic_year: string;
  semester: number;
  subjects: SubjectMark[];
  sgpa: number;
  cgpa: number | null;
  marksheet_url: string | null;
  verification_status: VerificationStatus;
  verified_by: number | null;
  verified_at: Date | null;
  rejection_reason: string | null;
  created_at: Date;
  updated_at: Date;
  is_deleted: boolean;
}

export interface StudentRecordFilters {
  studentId?: number;
  academicYear?: string;
  semester?: number;
  verificationStatus?: VerificationStatus;
}

const GRADE_POINTS: Record<string, number> = {
  O: 10, 'A+': 9, A: 8, 'B+': 7, B: 6, C: 5, P: 4, F: 0,
};

export class StudentRecordModel {
  static computeSGPA(subjects: SubjectMark[]): number {
    if (!subjects || subjects.length === 0) return 0;
    let totalCredits = 0;
    let totalPoints = 0;
    for (const subject of subjects) {
      const gradePoint = GRADE_POINTS[subject.grade?.toUpperCase()] ?? 0;
      totalCredits += subject.credits;
      totalPoints += subject.credits * gradePoint;
    }
    if (totalCredits === 0) return 0;
    return Math.round((totalPoints / totalCredits) * 100) / 100;
  }

  static async findDuplicate(studentId: number, academicYear: string, semester: number) {
    const result = await pool.query(
      \`SELECT id FROM student_records WHERE student_id = $1 AND academic_year = $2 AND semester = $3 AND is_deleted = false\`,
      [studentId, academicYear, semester]
    );
    return result.rows[0] || null;
  }

  static async create(data: {
    studentId: number;
    academicYear: string;
    semester: number;
    subjects: SubjectMark[];
    marksheetUrl?: string;
  }): Promise<StudentRecordRow> {
    const sgpa = StudentRecordModel.computeSGPA(data.subjects);
    const result = await pool.query(
      \`INSERT INTO student_records
        (student_id, academic_year, semester, subjects, sgpa, marksheet_url, verification_status, created_at, updated_at, is_deleted)
       VALUES ($1, $2, $3, $4, $5, $6, 'pending', NOW(), NOW(), false)
       RETURNING *\`,
      [data.studentId, data.academicYear, data.semester, JSON.stringify(data.subjects), sgpa, data.marksheetUrl || null]
    );
    return result.rows[0];
  }

  static async findById(id: number): Promise<StudentRecordRow | null> {
    const result = await pool.query(
      \`SELECT * FROM student_records WHERE id = $1 AND is_deleted = false\`,
      [id]
    );
    return result.rows[0] || null;
  }

  static async findAll(filters: StudentRecordFilters, page: number, limit: number) {
    const conditions: string[] = ['is_deleted = false'];
    const params: any[] = [];
    let idx = 1;

    if (filters.studentId) {
      conditions.push(\`student_id = $\${idx++}\`);
      params.push(filters.studentId);
    }
    if (filters.academicYear) {
      conditions.push(\`academic_year = $\${idx++}\`);
      params.push(filters.academicYear);
    }
    if (filters.semester) {
      conditions.push(\`semester = $\${idx++}\`);
      params.push(filters.semester);
    }
    if (filters.verificationStatus) {
      conditions.push(\`verification_status = $\${idx++}\`);
      params.push(filters.verificationStatus);
    }

    const whereClause = conditions.join(' AND ');
    const offset = (page - 1) * limit;

    const countResult = await pool.query(
      \`SELECT COUNT(*)::int AS total FROM student_records WHERE \${whereClause}\`,
      params
    );

    const dataResult = await pool.query(
      \`SELECT * FROM student_records WHERE \${whereClause}
       ORDER BY academic_year DESC, semester DESC
       LIMIT $\${idx++} OFFSET $\${idx++}\`,
      [...params, limit, offset]
    );

    return { rows: dataResult.rows, total: countResult.rows[0].total };
  }

  static async update(id: number, data: Partial<{ subjects: SubjectMark[]; marksheetUrl: string }>) {
    const existing = await StudentRecordModel.findById(id);
    if (!existing) {
      throw new AppError('Student record not found', 404);
    }

    const subjects = data.subjects || existing.subjects;
    const sgpa = data.subjects ? StudentRecordModel.computeSGPA(subjects) : existing.sgpa;
    const resetsVerification = Boolean(data.subjects) && existing.verification_status === 'verified';

    const result = await pool.query(
      \`UPDATE student_records
       SET subjects = $1, sgpa = $2, marksheet_url = COALESCE($3, marksheet_url),
           verification_status = $4, verified_by = CASE WHEN $4 = 'pending' THEN NULL ELSE verified_by END,
           verified_at = CASE WHEN $4 = 'pending' THEN NULL ELSE verified_at END,
           updated_at = NOW()
       WHERE id = $5
       RETURNING *\`,
      [
        JSON.stringify(subjects),
        sgpa,
        data.marksheetUrl || null,
        resetsVerification ? 'pending' : existing.verification_status,
        id,
      ]
    );
    return result.rows[0];
  }

  static async setVerificationStatus(
    id: number,
    status: 'verified' | 'rejected',
    verifiedBy: number,
    rejectionReason?: string
  ) {
    const result = await pool.query(
      \`UPDATE student_records
       SET verification_status = $1, verified_by = $2, verified_at = NOW(),
           rejection_reason = $3, updated_at = NOW()
       WHERE id = $4 AND is_deleted = false
       RETURNING *\`,
      [status, verifiedBy, status === 'rejected' ? rejectionReason || null : null, id]
    );
    if (result.rowCount === 0) {
      throw new AppError('Student record not found', 404);
    }
    return result.rows[0];
  }

  static async softDelete(id: number) {
    const result = await pool.query(
      \`UPDATE student_records SET is_deleted = true, updated_at = NOW() WHERE id = $1 RETURNING id\`,
      [id]
    );
    if (result.rowCount === 0) {
      throw new AppError('Student record not found', 404);
    }
    return true;
  }

  static async getAcademicHistory(studentId: number) {
    const result = await pool.query(
      \`SELECT academic_year, semester, sgpa, verification_status
       FROM student_records
       WHERE student_id = $1 AND is_deleted = false AND verification_status = 'verified'
       ORDER BY academic_year ASC, semester ASC\`,
      [studentId]
    );

    let cumulativeCredits = 0;
    let cumulativePoints = 0;
    const history: Array<{ academicYear: string; semester: number; sgpa: number; cgpaAtThisPoint: number }> = [];

    for (const row of result.rows) {
      const record = await pool.query(
        \`SELECT subjects FROM student_records WHERE student_id = $1 AND academic_year = $2 AND semester = $3 AND is_deleted = false LIMIT 1\`,
        [studentId, row.academic_year, row.semester]
      );
      const subjects: SubjectMark[] = record.rows[0]?.subjects || [];
      const semesterCredits = subjects.reduce((sum, s) => sum + s.credits, 0);
      cumulativeCredits += semesterCredits;
      cumulativePoints += semesterCredits * row.sgpa;
      const cgpa = cumulativeCredits > 0 ? Math.round((cumulativePoints / cumulativeCredits) * 100) / 100 : 0;

      history.push({
        academicYear: row.academic_year,
        semester: row.semester,
        sgpa: row.sgpa,
        cgpaAtThisPoint: cgpa,
      });
    }

    return {
      studentId,
      semesterHistory: history,
      currentCGPA: history.length > 0 ? history[history.length - 1].cgpaAtThisPoint : 0,
    };
  }
}

export default StudentRecordModel;
`;

/* ---- services/student-record.service.ts ---- */
const STUDENT_RECORD_SERVICE = `import { StudentRecordModel, StudentRecordFilters, SubjectMark } from '../models/student-record.model';
import { getPagination, buildMeta } from '../utils/pagination';
import { AppError } from '../utils/AppError';

export class StudentRecordService {
  static async list(query: any) {
    const { page, limit } = getPagination(query);
    const filters: StudentRecordFilters = {
      studentId: query.studentId ? Number(query.studentId) : undefined,
      academicYear: query.academicYear || undefined,
      semester: query.semester ? Number(query.semester) : undefined,
      verificationStatus: query.verificationStatus || undefined,
    };
    const { rows, total } = await StudentRecordModel.findAll(filters, page, limit);
    return { records: rows, meta: buildMeta(total, page, limit) };
  }

  static async getById(id: number) {
    const record = await StudentRecordModel.findById(id);
    if (!record) {
      throw new AppError('Student record not found', 404);
    }
    return record;
  }

  static async create(payload: {
    studentId: number;
    academicYear: string;
    semester: number;
    subjects: SubjectMark[];
    marksheetUrl?: string;
  }) {
    if (!payload.subjects || payload.subjects.length === 0) {
      throw new AppError('At least one subject mark entry is required', 400);
    }
    const duplicate = await StudentRecordModel.findDuplicate(
      payload.studentId,
      payload.academicYear,
      payload.semester
    );
    if (duplicate) {
      throw new AppError('A record for this student, academic year, and semester already exists', 409);
    }
    return StudentRecordModel.create(payload);
  }

  static async update(id: number, payload: Partial<{ subjects: SubjectMark[]; marksheetUrl: string }>) {
    return StudentRecordModel.update(id, payload);
  }

  static async verify(id: number, verifiedBy: number) {
    return StudentRecordModel.setVerificationStatus(id, 'verified', verifiedBy);
  }

  static async reject(id: number, verifiedBy: number, reason: string) {
    if (!reason || reason.trim().length === 0) {
      throw new AppError('A rejection reason is required', 400);
    }
    return StudentRecordModel.setVerificationStatus(id, 'rejected', verifiedBy, reason);
  }

  static async remove(id: number) {
    return StudentRecordModel.softDelete(id);
  }

  static async getHistory(studentId: number) {
    return StudentRecordModel.getAcademicHistory(studentId);
  }
}

export default StudentRecordService;
`;

/* ---- controllers/student-record.controller.ts ---- */
const STUDENT_RECORD_CONTROLLER = `import { Request, Response } from 'express';
import { asyncHandler } from '../utils/asyncHandler';
import { sendResponse } from '../utils/response';
import { AppError } from '../utils/AppError';
import { StudentRecordService } from '../services/student-record.service';

export const listStudentRecords = asyncHandler(async (req: Request, res: Response) => {
  const result = await StudentRecordService.list(req.query);
  sendResponse(res, 200, 'Student records retrieved', result);
});

export const getStudentRecord = asyncHandler(async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const record = await StudentRecordService.getById(id);
  sendResponse(res, 200, 'Student record retrieved', record);
});

export const createStudentRecord = asyncHandler(async (req: Request, res: Response) => {
  const { studentId, academicYear, semester, subjects, marksheetUrl } = req.body;
  if (!studentId || !academicYear || !semester) {
    throw new AppError('studentId, academicYear and semester are required', 400);
  }
  const record = await StudentRecordService.create({ studentId, academicYear, semester, subjects, marksheetUrl });
  sendResponse(res, 201, 'Student record created', record);
});

export const updateStudentRecord = asyncHandler(async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const record = await StudentRecordService.update(id, req.body);
  sendResponse(res, 200, 'Student record updated', record);
});

export const verifyStudentRecord = asyncHandler(async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const verifiedBy = (req as any).user?.id;
  const record = await StudentRecordService.verify(id, verifiedBy);
  sendResponse(res, 200, 'Student record verified', record);
});

export const rejectStudentRecord = asyncHandler(async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const verifiedBy = (req as any).user?.id;
  const { reason } = req.body;
  const record = await StudentRecordService.reject(id, verifiedBy, reason);
  sendResponse(res, 200, 'Student record rejected', record);
});

export const deleteStudentRecord = asyncHandler(async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  await StudentRecordService.remove(id);
  sendResponse(res, 200, 'Student record deleted', null);
});

export const getStudentAcademicHistory = asyncHandler(async (req: Request, res: Response) => {
  const studentId = Number(req.params.studentId);
  const history = await StudentRecordService.getHistory(studentId);
  sendResponse(res, 200, 'Academic history retrieved', history);
});
`;

/* ---- routes/student-record.routes.ts ---- */
const STUDENT_RECORD_ROUTES = `import { Router } from 'express';
import { authenticate } from '../middleware/auth';
import { authorize } from '../middleware/rbac';
import {
  listStudentRecords,
  getStudentRecord,
  createStudentRecord,
  updateStudentRecord,
  verifyStudentRecord,
  rejectStudentRecord,
  deleteStudentRecord,
  getStudentAcademicHistory,
} from '../controllers/student-record.controller';

const router = Router();
router.use(authenticate);

router.get('/', authorize(['admin', 'iqac_coordinator', 'hod', 'faculty']), listStudentRecords);
router.get(
  '/student/:studentId/history',
  authorize(['admin', 'iqac_coordinator', 'hod', 'faculty', 'student']),
  getStudentAcademicHistory
);
router.get('/:id', authorize(['admin', 'iqac_coordinator', 'hod', 'faculty', 'student']), getStudentRecord);
router.post('/', authorize(['admin', 'faculty']), createStudentRecord);
router.put('/:id', authorize(['admin', 'faculty']), updateStudentRecord);
router.post('/:id/verify', authorize(['admin', 'iqac_coordinator']), verifyStudentRecord);
router.post('/:id/reject', authorize(['admin', 'iqac_coordinator']), rejectStudentRecord);
router.delete('/:id', authorize(['admin']), deleteStudentRecord);

export default router;
`;

/* ---- models/research.model.ts ---- */
const RESEARCH_MODEL = `import { pool } from '../config/database';
import { AppError } from '../utils/AppError';

export type ResearchRecordType = 'publication' | 'consultancy' | 'patent';
export type PatentStatus = 'filed' | 'published' | 'granted';

export interface ResearchRecordRow {
  id: number;
  faculty_id: number;
  department_id: number;
  record_type: ResearchRecordType;
  title: string;
  description: string | null;
  publication_venue: string | null;
  indexing: string | null;
  citation_count: number;
  patent_number: string | null;
  patent_status: PatentStatus | null;
  consultancy_client: string | null;
  consultancy_amount: number | null;
  naac_criteria_code: string | null;
  nba_co_po_mapping: Record<string, unknown> | null;
  year: number;
  proof_document_url: string | null;
  is_deleted: boolean;
  created_at: Date;
  updated_at: Date;
}

export interface ResearchFilters {
  facultyId?: number;
  departmentId?: number;
  recordType?: ResearchRecordType;
  year?: number;
  naacCriteriaCode?: string;
}

export class ResearchModel {
  static async create(data: {
    facultyId: number;
    departmentId: number;
    recordType: ResearchRecordType;
    title: string;
    description?: string;
    publicationVenue?: string;
    indexing?: string;
    citationCount?: number;
    patentNumber?: string;
    patentStatus?: PatentStatus;
    consultancyClient?: string;
    consultancyAmount?: number;
    year: number;
    proofDocumentUrl?: string;
  }): Promise<ResearchRecordRow> {
    const result = await pool.query(
      \`INSERT INTO research_records
        (faculty_id, department_id, record_type, title, description, publication_venue, indexing,
         citation_count, patent_number, patent_status, consultancy_client, consultancy_amount,
         year, proof_document_url, is_deleted, created_at, updated_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,false,NOW(),NOW())
       RETURNING *\`,
      [
        data.facultyId,
        data.departmentId,
        data.recordType,
        data.title,
        data.description || null,
        data.publicationVenue || null,
        data.indexing || null,
        data.citationCount || 0,
        data.patentNumber || null,
        data.patentStatus || null,
        data.consultancyClient || null,
        data.consultancyAmount || null,
        data.year,
        data.proofDocumentUrl || null,
      ]
    );
    return result.rows[0];
  }

  static async findById(id: number): Promise<ResearchRecordRow | null> {
    const result = await pool.query(\`SELECT * FROM research_records WHERE id = $1 AND is_deleted = false\`, [id]);
    return result.rows[0] || null;
  }

  static async findAll(filters: ResearchFilters, page: number, limit: number) {
    const conditions: string[] = ['is_deleted = false'];
    const params: any[] = [];
    let idx = 1;

    if (filters.facultyId) {
      conditions.push(\`faculty_id = $\${idx++}\`);
      params.push(filters.facultyId);
    }
    if (filters.departmentId) {
      conditions.push(\`department_id = $\${idx++}\`);
      params.push(filters.departmentId);
    }
    if (filters.recordType) {
      conditions.push(\`record_type = $\${idx++}\`);
      params.push(filters.recordType);
    }
    if (filters.year) {
      conditions.push(\`year = $\${idx++}\`);
      params.push(filters.year);
    }
    if (filters.naacCriteriaCode) {
      conditions.push(\`naac_criteria_code = $\${idx++}\`);
      params.push(filters.naacCriteriaCode);
    }

    const whereClause = conditions.join(' AND ');
    const offset = (page - 1) * limit;

    const countResult = await pool.query(
      \`SELECT COUNT(*)::int AS total FROM research_records WHERE \${whereClause}\`,
      params
    );
    const dataResult = await pool.query(
      \`SELECT * FROM research_records WHERE \${whereClause} ORDER BY year DESC, created_at DESC LIMIT $\${idx++} OFFSET $\${idx++}\`,
      [...params, limit, offset]
    );

    return { rows: dataResult.rows, total: countResult.rows[0].total };
  }

  static async update(
    id: number,
    data: Partial<{
      title: string;
      description: string;
      publicationVenue: string;
      indexing: string;
      citationCount: number;
      patentNumber: string;
      patentStatus: PatentStatus;
      consultancyClient: string;
      consultancyAmount: number;
      year: number;
      proofDocumentUrl: string;
    }>
  ) {
    const existing = await ResearchModel.findById(id);
    if (!existing) throw new AppError('Research record not found', 404);

    const result = await pool.query(
      \`UPDATE research_records SET
        title = COALESCE($1, title),
        description = COALESCE($2, description),
        publication_venue = COALESCE($3, publication_venue),
        indexing = COALESCE($4, indexing),
        citation_count = COALESCE($5, citation_count),
        patent_number = COALESCE($6, patent_number),
        patent_status = COALESCE($7, patent_status),
        consultancy_client = COALESCE($8, consultancy_client),
        consultancy_amount = COALESCE($9, consultancy_amount),
        year = COALESCE($10, year),
        proof_document_url = COALESCE($11, proof_document_url),
        updated_at = NOW()
       WHERE id = $12
       RETURNING *\`,
      [
        data.title ?? null,
        data.description ?? null,
        data.publicationVenue ?? null,
        data.indexing ?? null,
        data.citationCount ?? null,
        data.patentNumber ?? null,
        data.patentStatus ?? null,
        data.consultancyClient ?? null,
        data.consultancyAmount ?? null,
        data.year ?? null,
        data.proofDocumentUrl ?? null,
        id,
      ]
    );
    return result.rows[0];
  }

  static async softDelete(id: number) {
    const result = await pool.query(
      \`UPDATE research_records SET is_deleted = true, updated_at = NOW() WHERE id = $1 RETURNING id\`,
      [id]
    );
    if (result.rowCount === 0) throw new AppError('Research record not found', 404);
    return true;
  }

  static async mapNaacCriteria(id: number, criteriaCode: string) {
    const result = await pool.query(
      \`UPDATE research_records SET naac_criteria_code = $1, updated_at = NOW() WHERE id = $2 AND is_deleted = false RETURNING *\`,
      [criteriaCode, id]
    );
    if (result.rowCount === 0) throw new AppError('Research record not found', 404);
    return result.rows[0];
  }

  static async mapNbaOutcomes(id: number, mapping: Record<string, unknown>) {
    const result = await pool.query(
      \`UPDATE research_records SET nba_co_po_mapping = $1, updated_at = NOW() WHERE id = $2 AND is_deleted = false RETURNING *\`,
      [JSON.stringify(mapping), id]
    );
    if (result.rowCount === 0) throw new AppError('Research record not found', 404);
    return result.rows[0];
  }

  static async getFacultyAggregates(facultyId: number) {
    const result = await pool.query(
      \`SELECT
        COUNT(*) FILTER (WHERE record_type = 'publication')::int AS publication_count,
        COUNT(*) FILTER (WHERE record_type = 'patent')::int AS patent_count,
        COUNT(*) FILTER (WHERE record_type = 'consultancy')::int AS consultancy_count,
        COALESCE(SUM(citation_count), 0)::int AS total_citations,
        COALESCE(SUM(consultancy_amount) FILTER (WHERE record_type = 'consultancy'), 0)::numeric AS total_consultancy_income
       FROM research_records
       WHERE faculty_id = $1 AND is_deleted = false\`,
      [facultyId]
    );
    return result.rows[0];
  }

  static async getDepartmentAggregates(departmentId: number) {
    const result = await pool.query(
      \`SELECT
        record_type,
        COUNT(*)::int AS count,
        COALESCE(SUM(citation_count), 0)::int AS total_citations,
        COALESCE(SUM(consultancy_amount), 0)::numeric AS total_consultancy_income
       FROM research_records
       WHERE department_id = $1 AND is_deleted = false
       GROUP BY record_type\`,
      [departmentId]
    );
    return result.rows;
  }
}

export default ResearchModel;
`;

/* ---- services/research.service.ts ---- */
const RESEARCH_SERVICE = `import { ResearchModel, ResearchFilters, ResearchRecordType } from '../models/research.model';
import { getPagination, buildMeta } from '../utils/pagination';
import { AppError } from '../utils/AppError';

export class ResearchService {
  static async list(query: any) {
    const { page, limit } = getPagination(query);
    const filters: ResearchFilters = {
      facultyId: query.facultyId ? Number(query.facultyId) : undefined,
      departmentId: query.departmentId ? Number(query.departmentId) : undefined,
      recordType: query.recordType || undefined,
      year: query.year ? Number(query.year) : undefined,
      naacCriteriaCode: query.naacCriteriaCode || undefined,
    };
    const { rows, total } = await ResearchModel.findAll(filters, page, limit);
    return { records: rows, meta: buildMeta(total, page, limit) };
  }

  static async getById(id: number) {
    const record = await ResearchModel.findById(id);
    if (!record) throw new AppError('Research record not found', 404);
    return record;
  }

  static validateTypeSpecificFields(recordType: ResearchRecordType, body: any) {
    if (recordType === 'patent' && !body.patentNumber) {
      throw new AppError('patentNumber is required for patent records', 400);
    }
    if (recordType === 'consultancy' && (!body.consultancyClient || body.consultancyAmount === undefined)) {
      throw new AppError('consultancyClient and consultancyAmount are required for consultancy records', 400);
    }
    if (recordType === 'publication' && !body.publicationVenue) {
      throw new AppError('publicationVenue is required for publication records', 400);
    }
  }

  static async create(body: any) {
    if (!body.recordType || !['publication', 'consultancy', 'patent'].includes(body.recordType)) {
      throw new AppError('recordType must be one of publication, consultancy, patent', 400);
    }
    ResearchService.validateTypeSpecificFields(body.recordType, body);
    return ResearchModel.create(body);
  }

  static async update(id: number, body: any) {
    return ResearchModel.update(id, body);
  }

  static async remove(id: number) {
    return ResearchModel.softDelete(id);
  }

  static async mapCriteria(id: number, criteriaCode: string) {
    if (!criteriaCode) throw new AppError('criteriaCode is required', 400);
    return ResearchModel.mapNaacCriteria(id, criteriaCode);
  }

  static async mapOutcomes(id: number, mapping: Record<string, unknown>) {
    if (!mapping || Object.keys(mapping).length === 0) {
      throw new AppError('A non-empty CO-PO mapping object is required', 400);
    }
    return ResearchModel.mapNbaOutcomes(id, mapping);
  }

  static async getFacultyProfile(facultyId: number) {
    return ResearchModel.getFacultyAggregates(facultyId);
  }

  static async getDepartmentSummary(departmentId: number) {
    return ResearchModel.getDepartmentAggregates(departmentId);
  }
}

export default ResearchService;
`;

/* ---- controllers/research.controller.ts ---- */
const RESEARCH_CONTROLLER = `import { Request, Response } from 'express';
import { asyncHandler } from '../utils/asyncHandler';
import { sendResponse } from '../utils/response';
import { ResearchService } from '../services/research.service';

export const listResearchRecords = asyncHandler(async (req: Request, res: Response) => {
  const result = await ResearchService.list(req.query);
  sendResponse(res, 200, 'Research records retrieved', result);
});

export const getResearchRecord = asyncHandler(async (req: Request, res: Response) => {
  const record = await ResearchService.getById(Number(req.params.id));
  sendResponse(res, 200, 'Research record retrieved', record);
});

export const createResearchRecord = asyncHandler(async (req: Request, res: Response) => {
  const record = await ResearchService.create(req.body);
  sendResponse(res, 201, 'Research record created', record);
});

export const updateResearchRecord = asyncHandler(async (req: Request, res: Response) => {
  const record = await ResearchService.update(Number(req.params.id), req.body);
  sendResponse(res, 200, 'Research record updated', record);
});

export const deleteResearchRecord = asyncHandler(async (req: Request, res: Response) => {
  await ResearchService.remove(Number(req.params.id));
  sendResponse(res, 200, 'Research record deleted', null);
});

export const mapResearchNaacCriteria = asyncHandler(async (req: Request, res: Response) => {
  const record = await ResearchService.mapCriteria(Number(req.params.id), req.body.criteriaCode);
  sendResponse(res, 200, 'NAAC criteria mapping updated', record);
});

export const mapResearchNbaOutcomes = asyncHandler(async (req: Request, res: Response) => {
  const record = await ResearchService.mapOutcomes(Number(req.params.id), req.body.mapping);
  sendResponse(res, 200, 'NBA CO-PO mapping updated', record);
});

export const getFacultyResearchProfile = asyncHandler(async (req: Request, res: Response) => {
  const profile = await ResearchService.getFacultyProfile(Number(req.params.facultyId));
  sendResponse(res, 200, 'Faculty research profile retrieved', profile);
});

export const getDepartmentResearchSummary = asyncHandler(async (req: Request, res: Response) => {
  const summary = await ResearchService.getDepartmentSummary(Number(req.params.departmentId));
  sendResponse(res, 200, 'Department research summary retrieved', summary);
});
`;

/* ---- routes/research.routes.ts ---- */
const RESEARCH_ROUTES = `import { Router } from 'express';
import { authenticate } from '../middleware/auth';
import { authorize } from '../middleware/rbac';
import {
  listResearchRecords,
  getResearchRecord,
  createResearchRecord,
  updateResearchRecord,
  deleteResearchRecord,
  mapResearchNaacCriteria,
  mapResearchNbaOutcomes,
  getFacultyResearchProfile,
  getDepartmentResearchSummary,
} from '../controllers/research.controller';

const router = Router();
router.use(authenticate);

router.get('/', authorize(['admin', 'iqac_coordinator', 'hod', 'faculty']), listResearchRecords);
router.get(
  '/faculty/:facultyId/profile',
  authorize(['admin', 'iqac_coordinator', 'hod', 'faculty']),
  getFacultyResearchProfile
);
router.get(
  '/department/:departmentId/summary',
  authorize(['admin', 'iqac_coordinator', 'hod']),
  getDepartmentResearchSummary
);
router.get('/:id', authorize(['admin', 'iqac_coordinator', 'hod', 'faculty']), getResearchRecord);
router.post('/', authorize(['admin', 'faculty']), createResearchRecord);
router.put('/:id', authorize(['admin', 'faculty']), updateResearchRecord);
router.delete('/:id', authorize(['admin']), deleteResearchRecord);
router.post('/:id/map-naac', authorize(['admin', 'iqac_coordinator']), mapResearchNaacCriteria);
router.post('/:id/map-nba', authorize(['admin', 'iqac_coordinator']), mapResearchNbaOutcomes);

export default router;
`;

/* ---- models/placement.model.ts ---- */
const PLACEMENT_MODEL = `import { pool } from '../config/database';
import { AppError } from '../utils/AppError';

export interface RecruiterRow {
  id: number;
  company_name: string;
  sector: string | null;
  hr_contact_name: string | null;
  hr_contact_email: string | null;
  hr_contact_phone: string | null;
  visits_count: number;
  first_visit_date: Date | null;
  last_visit_date: Date | null;
  is_deleted: boolean;
  created_at: Date;
  updated_at: Date;
}

export interface TrainingProgramRow {
  id: number;
  title: string;
  trainer_name: string;
  trainer_organization: string | null;
  start_date: Date;
  end_date: Date;
  mode: 'online' | 'offline' | 'hybrid';
  students_enrolled_count: number;
  is_deleted: boolean;
  created_at: Date;
  updated_at: Date;
}

export interface PlacementRow {
  id: number;
  student_id: number;
  recruiter_id: number;
  training_program_id: number | null;
  offer_type: 'internship' | 'full-time' | 'ppo';
  package_lpa: number;
  placement_date: Date;
  offer_letter_url: string | null;
  status: 'offered' | 'accepted' | 'declined';
  is_deleted: boolean;
  created_at: Date;
  updated_at: Date;
}

export class RecruiterModel {
  static async create(data: {
    companyName: string;
    sector?: string;
    hrContactName?: string;
    hrContactEmail?: string;
    hrContactPhone?: string;
  }): Promise<RecruiterRow> {
    const result = await pool.query(
      \`INSERT INTO recruiters
        (company_name, sector, hr_contact_name, hr_contact_email, hr_contact_phone,
         visits_count, first_visit_date, last_visit_date, is_deleted, created_at, updated_at)
       VALUES ($1,$2,$3,$4,$5,1,NOW(),NOW(),false,NOW(),NOW())
       RETURNING *\`,
      [
        data.companyName,
        data.sector || null,
        data.hrContactName || null,
        data.hrContactEmail || null,
        data.hrContactPhone || null,
      ]
    );
    return result.rows[0];
  }

  static async findById(id: number): Promise<RecruiterRow | null> {
    const result = await pool.query(\`SELECT * FROM recruiters WHERE id = $1 AND is_deleted = false\`, [id]);
    return result.rows[0] || null;
  }

  static async findAll(page: number, limit: number, sector?: string) {
    const conditions: string[] = ['is_deleted = false'];
    const params: any[] = [];
    let idx = 1;
    if (sector) {
      conditions.push(\`sector = $\${idx++}\`);
      params.push(sector);
    }
    const whereClause = conditions.join(' AND ');
    const offset = (page - 1) * limit;

    const countResult = await pool.query(\`SELECT COUNT(*)::int AS total FROM recruiters WHERE \${whereClause}\`, params);
    const dataResult = await pool.query(
      \`SELECT * FROM recruiters WHERE \${whereClause} ORDER BY company_name ASC LIMIT $\${idx++} OFFSET $\${idx++}\`,
      [...params, limit, offset]
    );
    return { rows: dataResult.rows, total: countResult.rows[0].total };
  }

  static async update(
    id: number,
    data: Partial<{
      companyName: string;
      sector: string;
      hrContactName: string;
      hrContactEmail: string;
      hrContactPhone: string;
    }>
  ) {
    const result = await pool.query(
      \`UPDATE recruiters SET
        company_name = COALESCE($1, company_name),
        sector = COALESCE($2, sector),
        hr_contact_name = COALESCE($3, hr_contact_name),
        hr_contact_email = COALESCE($4, hr_contact_email),
        hr_contact_phone = COALESCE($5, hr_contact_phone),
        updated_at = NOW()
       WHERE id = $6 AND is_deleted = false
       RETURNING *\`,
      [
        data.companyName ?? null,
        data.sector ?? null,
        data.hrContactName ?? null,
        data.hrContactEmail ?? null,
        data.hrContactPhone ?? null,
        id,
      ]
    );
    if (result.rowCount === 0) throw new AppError('Recruiter not found', 404);
    return result.rows[0];
  }

  static async logVisit(id: number) {
    const result = await pool.query(
      \`UPDATE recruiters SET visits_count = visits_count + 1, last_visit_date = NOW(), updated_at = NOW()
       WHERE id = $1 AND is_deleted = false RETURNING *\`,
      [id]
    );
    if (result.rowCount === 0) throw new AppError('Recruiter not found', 404);
    return result.rows[0];
  }

  static async softDelete(id: number) {
    const result = await pool.query(\`UPDATE recruiters SET is_deleted = true, updated_at = NOW() WHERE id = $1 RETURNING id\`, [id]);
    if (result.rowCount === 0) throw new AppError('Recruiter not found', 404);
    return true;
  }
}

export class TrainingProgramModel {
  static async create(data: {
    title: string;
    trainerName: string;
    trainerOrganization?: string;
    startDate: string;
    endDate: string;
    mode: 'online' | 'offline' | 'hybrid';
  }): Promise<TrainingProgramRow> {
    const result = await pool.query(
      \`INSERT INTO training_programs
        (title, trainer_name, trainer_organization, start_date, end_date, mode,
         students_enrolled_count, is_deleted, created_at, updated_at)
       VALUES ($1,$2,$3,$4,$5,$6,0,false,NOW(),NOW())
       RETURNING *\`,
      [data.title, data.trainerName, data.trainerOrganization || null, data.startDate, data.endDate, data.mode]
    );
    return result.rows[0];
  }

  static async findById(id: number): Promise<TrainingProgramRow | null> {
    const result = await pool.query(\`SELECT * FROM training_programs WHERE id = $1 AND is_deleted = false\`, [id]);
    return result.rows[0] || null;
  }

  static async findAll(page: number, limit: number) {
    const offset = (page - 1) * limit;
    const countResult = await pool.query(\`SELECT COUNT(*)::int AS total FROM training_programs WHERE is_deleted = false\`);
    const dataResult = await pool.query(
      \`SELECT * FROM training_programs WHERE is_deleted = false ORDER BY start_date DESC LIMIT $1 OFFSET $2\`,
      [limit, offset]
    );
    return { rows: dataResult.rows, total: countResult.rows[0].total };
  }

  static async update(
    id: number,
    data: Partial<{
      title: string;
      trainerName: string;
      trainerOrganization: string;
      startDate: string;
      endDate: string;
      mode: 'online' | 'offline' | 'hybrid';
    }>
  ) {
    const result = await pool.query(
      \`UPDATE training_programs SET
        title = COALESCE($1, title),
        trainer_name = COALESCE($2, trainer_name),
        trainer_organization = COALESCE($3, trainer_organization),
        start_date = COALESCE($4, start_date),
        end_date = COALESCE($5, end_date),
        mode = COALESCE($6, mode),
        updated_at = NOW()
       WHERE id = $7 AND is_deleted = false
       RETURNING *\`,
      [
        data.title ?? null,
        data.trainerName ?? null,
        data.trainerOrganization ?? null,
        data.startDate ?? null,
        data.endDate ?? null,
        data.mode ?? null,
        id,
      ]
    );
    if (result.rowCount === 0) throw new AppError('Training program not found', 404);
    return result.rows[0];
  }

  static async enrollStudent(programId: number) {
    const result = await pool.query(
      \`UPDATE training_programs SET students_enrolled_count = students_enrolled_count + 1, updated_at = NOW()
       WHERE id = $1 AND is_deleted = false RETURNING *\`,
      [programId]
    );
    if (result.rowCount === 0) throw new AppError('Training program not found', 404);
    return result.rows[0];
  }

  static async softDelete(id: number) {
    const result = await pool.query(
      \`UPDATE training_programs SET is_deleted = true, updated_at = NOW() WHERE id = $1 RETURNING id\`,
      [id]
    );
    if (result.rowCount === 0) throw new AppError('Training program not found', 404);
    return true;
  }
}

export class PlacementModel {
  static async create(data: {
    studentId: number;
    recruiterId: number;
    trainingProgramId?: number;
    offerType: 'internship' | 'full-time' | 'ppo';
    packageLpa: number;
    placementDate: string;
    offerLetterUrl?: string;
  }): Promise<PlacementRow> {
    const recruiter = await RecruiterModel.findById(data.recruiterId);
    if (!recruiter) throw new AppError('Recruiter not found', 404);

    const result = await pool.query(
      \`INSERT INTO placements
        (student_id, recruiter_id, training_program_id, offer_type, package_lpa, placement_date,
         offer_letter_url, status, is_deleted, created_at, updated_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,'offered',false,NOW(),NOW())
       RETURNING *\`,
      [
        data.studentId,
        data.recruiterId,
        data.trainingProgramId || null,
        data.offerType,
        data.packageLpa,
        data.placementDate,
        data.offerLetterUrl || null,
      ]
    );
    return result.rows[0];
  }

  static async findById(id: number): Promise<PlacementRow | null> {
    const result = await pool.query(\`SELECT * FROM placements WHERE id = $1 AND is_deleted = false\`, [id]);
    return result.rows[0] || null;
  }

  static async findAll(
    filters: { studentId?: number; recruiterId?: number; status?: string; year?: number },
    page: number,
    limit: number
  ) {
    const conditions: string[] = ['is_deleted = false'];
    const params: any[] = [];
    let idx = 1;

    if (filters.studentId) {
      conditions.push(\`student_id = $\${idx++}\`);
      params.push(filters.studentId);
    }
    if (filters.recruiterId) {
      conditions.push(\`recruiter_id = $\${idx++}\`);
      params.push(filters.recruiterId);
    }
    if (filters.status) {
      conditions.push(\`status = $\${idx++}\`);
      params.push(filters.status);
    }
    if (filters.year) {
      conditions.push(\`EXTRACT(YEAR FROM placement_date) = $\${idx++}\`);
      params.push(filters.year);
    }

    const whereClause = conditions.join(' AND ');
    const offset = (page - 1) * limit;

    const countResult = await pool.query(\`SELECT COUNT(*)::int AS total FROM placements WHERE \${whereClause}\`, params);
    const dataResult = await pool.query(
      \`SELECT * FROM placements WHERE \${whereClause} ORDER BY placement_date DESC LIMIT $\${idx++} OFFSET $\${idx++}\`,
      [...params, limit, offset]
    );
    return { rows: dataResult.rows, total: countResult.rows[0].total };
  }

  static async updateStatus(id: number, status: 'offered' | 'accepted' | 'declined') {
    const result = await pool.query(
      \`UPDATE placements SET status = $1, updated_at = NOW() WHERE id = $2 AND is_deleted = false RETURNING *\`,
      [status, id]
    );
    if (result.rowCount === 0) throw new AppError('Placement record not found', 404);
    return result.rows[0];
  }

  static async softDelete(id: number) {
    const result = await pool.query(\`UPDATE placements SET is_deleted = true, updated_at = NOW() WHERE id = $1 RETURNING id\`, [id]);
    if (result.rowCount === 0) throw new AppError('Placement record not found', 404);
    return true;
  }

  static async getStatistics(year?: number) {
    const params: any[] = [];
    let whereClause = "is_deleted = false AND status = 'accepted'";
    if (year) {
      whereClause += ' AND EXTRACT(YEAR FROM placement_date) = $1';
      params.push(year);
    }
    const result = await pool.query(
      \`SELECT
        COUNT(*)::int AS total_placed,
        COALESCE(AVG(package_lpa), 0)::numeric(10,2) AS average_package,
        COALESCE(MAX(package_lpa), 0)::numeric(10,2) AS highest_package,
        COALESCE(MIN(package_lpa), 0)::numeric(10,2) AS lowest_package
       FROM placements WHERE \${whereClause}\`,
      params
    );
    return result.rows[0];
  }
}
`;

/* ---- services/placement.service.ts ---- */
const PLACEMENT_SERVICE = `import { PlacementModel, RecruiterModel, TrainingProgramModel } from '../models/placement.model';
import { getPagination, buildMeta } from '../utils/pagination';
import { AppError } from '../utils/AppError';

export class PlacementService {
  static async recordPlacement(body: any) {
    if (!body.studentId || !body.recruiterId || !body.offerType || body.packageLpa === undefined || !body.placementDate) {
      throw new AppError('studentId, recruiterId, offerType, packageLpa and placementDate are required', 400);
    }
    return PlacementModel.create(body);
  }

  static async list(query: any) {
    const { page, limit } = getPagination(query);
    const filters = {
      studentId: query.studentId ? Number(query.studentId) : undefined,
      recruiterId: query.recruiterId ? Number(query.recruiterId) : undefined,
      status: query.status || undefined,
      year: query.year ? Number(query.year) : undefined,
    };
    const { rows, total } = await PlacementModel.findAll(filters, page, limit);
    return { placements: rows, meta: buildMeta(total, page, limit) };
  }

  static async getById(id: number) {
    const record = await PlacementModel.findById(id);
    if (!record) throw new AppError('Placement record not found', 404);
    return record;
  }

  static async updateStatus(id: number, status: 'offered' | 'accepted' | 'declined') {
    if (!['offered', 'accepted', 'declined'].includes(status)) {
      throw new AppError('status must be one of offered, accepted, declined', 400);
    }
    return PlacementModel.updateStatus(id, status);
  }

  static async remove(id: number) {
    return PlacementModel.softDelete(id);
  }

  static async getStatistics(year?: number, totalEligibleStudents?: number) {
    const stats = await PlacementModel.getStatistics(year);
    const placementPercentage =
      totalEligibleStudents && totalEligibleStudents > 0
        ? Math.round((stats.total_placed / totalEligibleStudents) * 10000) / 100
        : null;
    return { ...stats, placementPercentage };
  }
}

export class RecruiterService {
  static async create(body: any) {
    if (!body.companyName) throw new AppError('companyName is required', 400);
    return RecruiterModel.create(body);
  }

  static async list(query: any) {
    const { page, limit } = getPagination(query);
    const { rows, total } = await RecruiterModel.findAll(page, limit, query.sector);
    return { recruiters: rows, meta: buildMeta(total, page, limit) };
  }

  static async getById(id: number) {
    const recruiter = await RecruiterModel.findById(id);
    if (!recruiter) throw new AppError('Recruiter not found', 404);
    return recruiter;
  }

  static async update(id: number, body: any) {
    return RecruiterModel.update(id, body);
  }

  static async logVisit(id: number) {
    return RecruiterModel.logVisit(id);
  }

  static async remove(id: number) {
    return RecruiterModel.softDelete(id);
  }
}

export class TrainingProgramService {
  static async create(body: any) {
    if (!body.title || !body.trainerName || !body.startDate || !body.endDate || !body.mode) {
      throw new AppError('title, trainerName, startDate, endDate and mode are required', 400);
    }
    return TrainingProgramModel.create(body);
  }

  static async list(query: any) {
    const { page, limit } = getPagination(query);
    const { rows, total } = await TrainingProgramModel.findAll(page, limit);
    return { programs: rows, meta: buildMeta(total, page, limit) };
  }

  static async getById(id: number) {
    const program = await TrainingProgramModel.findById(id);
    if (!program) throw new AppError('Training program not found', 404);
    return program;
  }

  static async update(id: number, body: any) {
    return TrainingProgramModel.update(id, body);
  }

  static async enroll(id: number) {
    return TrainingProgramModel.enrollStudent(id);
  }

  static async remove(id: number) {
    return TrainingProgramModel.softDelete(id);
  }
}
`;

/* ---- controllers/placement.controller.ts ---- */
const PLACEMENT_CONTROLLER = `import { Request, Response } from 'express';
import { asyncHandler } from '../utils/asyncHandler';
import { sendResponse } from '../utils/response';
import { PlacementService, RecruiterService, TrainingProgramService } from '../services/placement.service';

// Placements
export const createPlacement = asyncHandler(async (req: Request, res: Response) => {
  const record = await PlacementService.recordPlacement(req.body);
  sendResponse(res, 201, 'Placement recorded', record);
});

export const listPlacements = asyncHandler(async (req: Request, res: Response) => {
  const result = await PlacementService.list(req.query);
  sendResponse(res, 200, 'Placements retrieved', result);
});

export const getPlacement = asyncHandler(async (req: Request, res: Response) => {
  const record = await PlacementService.getById(Number(req.params.id));
  sendResponse(res, 200, 'Placement retrieved', record);
});

export const updatePlacementStatus = asyncHandler(async (req: Request, res: Response) => {
  const record = await PlacementService.updateStatus(Number(req.params.id), req.body.status);
  sendResponse(res, 200, 'Placement status updated', record);
});

export const deletePlacement = asyncHandler(async (req: Request, res: Response) => {
  await PlacementService.remove(Number(req.params.id));
  sendResponse(res, 200, 'Placement deleted', null);
});

export const getPlacementStatistics = asyncHandler(async (req: Request, res: Response) => {
  const year = req.query.year ? Number(req.query.year) : undefined;
  const totalEligibleStudents = req.query.totalEligibleStudents
    ? Number(req.query.totalEligibleStudents)
    : undefined;
  const stats = await PlacementService.getStatistics(year, totalEligibleStudents);
  sendResponse(res, 200, 'Placement statistics retrieved', stats);
});

// Recruiters
export const createRecruiter = asyncHandler(async (req: Request, res: Response) => {
  const recruiter = await RecruiterService.create(req.body);
  sendResponse(res, 201, 'Recruiter created', recruiter);
});

export const listRecruiters = asyncHandler(async (req: Request, res: Response) => {
  const result = await RecruiterService.list(req.query);
  sendResponse(res, 200, 'Recruiters retrieved', result);
});

export const getRecruiter = asyncHandler(async (req: Request, res: Response) => {
  const recruiter = await RecruiterService.getById(Number(req.params.id));
  sendResponse(res, 200, 'Recruiter retrieved', recruiter);
});

export const updateRecruiter = asyncHandler(async (req: Request, res: Response) => {
  const recruiter = await RecruiterService.update(Number(req.params.id), req.body);
  sendResponse(res, 200, 'Recruiter updated', recruiter);
});

export const logRecruiterVisit = asyncHandler(async (req: Request, res: Response) => {
  const recruiter = await RecruiterService.logVisit(Number(req.params.id));
  sendResponse(res, 200, 'Recruiter visit logged', recruiter);
});

export const deleteRecruiter = asyncHandler(async (req: Request, res: Response) => {
  await RecruiterService.remove(Number(req.params.id));
  sendResponse(res, 200, 'Recruiter deleted', null);
});

// Training Programs
export const createTrainingProgram = asyncHandler(async (req: Request, res: Response) => {
  const program = await TrainingProgramService.create(req.body);
  sendResponse(res, 201, 'Training program created', program);
});

export const listTrainingPrograms = asyncHandler(async (req: Request, res: Response) => {
  const result = await TrainingProgramService.list(req.query);
  sendResponse(res, 200, 'Training programs retrieved', result);
});

export const getTrainingProgram = asyncHandler(async (req: Request, res: Response) => {
  const program = await TrainingProgramService.getById(Number(req.params.id));
  sendResponse(res, 200, 'Training program retrieved', program);
});

export const updateTrainingProgram = asyncHandler(async (req: Request, res: Response) => {
  const program = await TrainingProgramService.update(Number(req.params.id), req.body);
  sendResponse(res, 200, 'Training program updated', program);
});

export const enrollInTrainingProgram = asyncHandler(async (req: Request, res: Response) => {
  const program = await TrainingProgramService.enroll(Number(req.params.id));
  sendResponse(res, 200, 'Student enrolled in training program', program);
});

export const deleteTrainingProgram = asyncHandler(async (req: Request, res: Response) => {
  await TrainingProgramService.remove(Number(req.params.id));
  sendResponse(res, 200, 'Training program deleted', null);
});
`;

/* ---- routes/placement.routes.ts ---- */
const PLACEMENT_ROUTES = `import { Router } from 'express';
import { authenticate } from '../middleware/auth';
import { authorize } from '../middleware/rbac';
import {
  createPlacement,
  listPlacements,
  getPlacement,
  updatePlacementStatus,
  deletePlacement,
  getPlacementStatistics,
  createRecruiter,
  listRecruiters,
  getRecruiter,
  updateRecruiter,
  logRecruiterVisit,
  deleteRecruiter,
  createTrainingProgram,
  listTrainingPrograms,
  getTrainingProgram,
  updateTrainingProgram,
  enrollInTrainingProgram,
  deleteTrainingProgram,
} from '../controllers/placement.controller';

const router = Router();
router.use(authenticate);

// Placements
router.get('/placements/stats', authorize(['admin', 'iqac_coordinator', 'placement_officer']), getPlacementStatistics);
router.get('/placements', authorize(['admin', 'iqac_coordinator', 'placement_officer']), listPlacements);
router.get('/placements/:id', authorize(['admin', 'iqac_coordinator', 'placement_officer']), getPlacement);
router.post('/placements', authorize(['admin', 'placement_officer']), createPlacement);
router.patch('/placements/:id/status', authorize(['admin', 'placement_officer']), updatePlacementStatus);
router.delete('/placements/:id', authorize(['admin']), deletePlacement);

// Recruiters
router.get('/recruiters', authorize(['admin', 'iqac_coordinator', 'placement_officer']), listRecruiters);
router.get('/recruiters/:id', authorize(['admin', 'iqac_coordinator', 'placement_officer']), getRecruiter);
router.post('/recruiters', authorize(['admin', 'placement_officer']), createRecruiter);
router.put('/recruiters/:id', authorize(['admin', 'placement_officer']), updateRecruiter);
router.post('/recruiters/:id/visit', authorize(['admin', 'placement_officer']), logRecruiterVisit);
router.delete('/recruiters/:id', authorize(['admin']), deleteRecruiter);

// Training Programs
router.get('/training-programs', authorize(['admin', 'iqac_coordinator', 'placement_officer']), listTrainingPrograms);
router.get('/training-programs/:id', authorize(['admin', 'iqac_coordinator', 'placement_officer']), getTrainingProgram);
router.post('/training-programs', authorize(['admin', 'placement_officer']), createTrainingProgram);
router.put('/training-programs/:id', authorize(['admin', 'placement_officer']), updateTrainingProgram);
router.post('/training-programs/:id/enroll', authorize(['admin', 'placement_officer']), enrollInTrainingProgram);
router.delete('/training-programs/:id', authorize(['admin']), deleteTrainingProgram);

export default router;
`;

/* ---- models/compliance.model.ts ---- */
const COMPLIANCE_MODEL = `import { pool } from '../config/database';
import { AppError } from '../utils/AppError';

export type ComplianceFramework = 'NAAC' | 'NBA';
export type ComplianceStatus = 'compliant' | 'at_risk' | 'non_compliant';
export type AuditAction = 'create' | 'update' | 'delete' | 'verify' | 'reject';

export interface ComplianceCriteriaRow {
  id: number;
  framework: ComplianceFramework;
  criteria_code: string;
  criteria_name: string;
  metric_description: string | null;
  target_value: number;
  unit: string | null;
  weight: number;
  created_at: Date;
}

export interface ComplianceRecordRow {
  id: number;
  criteria_id: number;
  academic_year: string;
  department_id: number | null;
  achieved_value: number;
  status: ComplianceStatus;
  evidence_links: string[] | null;
  remarks: string | null;
  submitted_by: number;
  submitted_at: Date;
  is_deleted: boolean;
  created_at: Date;
  updated_at: Date;
}

export interface AuditLogRow {
  id: number;
  module_name: string;
  action: AuditAction;
  entity_type: string;
  entity_id: number;
  performed_by: number;
  before_state: Record<string, unknown> | null;
  after_state: Record<string, unknown> | null;
  ip_address: string | null;
  created_at: Date;
}

const AT_RISK_THRESHOLD_PCT = 75;

export function computeComplianceStatus(achievedValue: number, targetValue: number): ComplianceStatus {
  if (targetValue <= 0) return 'non_compliant';
  const percentage = (achievedValue / targetValue) * 100;
  if (percentage >= 100) return 'compliant';
  if (percentage >= AT_RISK_THRESHOLD_PCT) return 'at_risk';
  return 'non_compliant';
}

export class ComplianceCriteriaModel {
  static async create(data: {
    framework: ComplianceFramework;
    criteriaCode: string;
    criteriaName: string;
    metricDescription?: string;
    targetValue: number;
    unit?: string;
    weight?: number;
  }): Promise<ComplianceCriteriaRow> {
    const result = await pool.query(
      \`INSERT INTO compliance_criteria
        (framework, criteria_code, criteria_name, metric_description, target_value, unit, weight, created_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,NOW())
       RETURNING *\`,
      [
        data.framework,
        data.criteriaCode,
        data.criteriaName,
        data.metricDescription || null,
        data.targetValue,
        data.unit || null,
        data.weight || 1,
      ]
    );
    return result.rows[0];
  }

  static async findAll(framework?: ComplianceFramework) {
    if (framework) {
      const result = await pool.query(
        \`SELECT * FROM compliance_criteria WHERE framework = $1 ORDER BY criteria_code ASC\`,
        [framework]
      );
      return result.rows;
    }
    const result = await pool.query(\`SELECT * FROM compliance_criteria ORDER BY framework ASC, criteria_code ASC\`);
    return result.rows;
  }

  static async findById(id: number): Promise<ComplianceCriteriaRow | null> {
    const result = await pool.query(\`SELECT * FROM compliance_criteria WHERE id = $1\`, [id]);
    return result.rows[0] || null;
  }
}

export class ComplianceRecordModel {
  static async create(data: {
    criteriaId: number;
    academicYear: string;
    departmentId?: number;
    achievedValue: number;
    evidenceLinks?: string[];
    remarks?: string;
    submittedBy: number;
  }): Promise<ComplianceRecordRow> {
    const criteria = await ComplianceCriteriaModel.findById(data.criteriaId);
    if (!criteria) throw new AppError('Compliance criteria not found', 404);

    const status = computeComplianceStatus(data.achievedValue, criteria.target_value);

    const result = await pool.query(
      \`INSERT INTO compliance_records
        (criteria_id, academic_year, department_id, achieved_value, status, evidence_links,
         remarks, submitted_by, submitted_at, is_deleted, created_at, updated_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,NOW(),false,NOW(),NOW())
       RETURNING *\`,
      [
        data.criteriaId,
        data.academicYear,
        data.departmentId || null,
        data.achievedValue,
        status,
        data.evidenceLinks ? JSON.stringify(data.evidenceLinks) : null,
        data.remarks || null,
        data.submittedBy,
      ]
    );
    return result.rows[0];
  }

  static async findById(id: number): Promise<ComplianceRecordRow | null> {
    const result = await pool.query(\`SELECT * FROM compliance_records WHERE id = $1 AND is_deleted = false\`, [id]);
    return result.rows[0] || null;
  }

  static async findAll(
    filters: {
      framework?: ComplianceFramework;
      academicYear?: string;
      departmentId?: number;
      status?: ComplianceStatus;
    },
    page: number,
    limit: number
  ) {
    const conditions: string[] = ['cr.is_deleted = false'];
    const params: any[] = [];
    let idx = 1;

    if (filters.framework) {
      conditions.push(\`cc.framework = $\${idx++}\`);
      params.push(filters.framework);
    }
    if (filters.academicYear) {
      conditions.push(\`cr.academic_year = $\${idx++}\`);
      params.push(filters.academicYear);
    }
    if (filters.departmentId) {
      conditions.push(\`cr.department_id = $\${idx++}\`);
      params.push(filters.departmentId);
    }
    if (filters.status) {
      conditions.push(\`cr.status = $\${idx++}\`);
      params.push(filters.status);
    }

    const whereClause = conditions.join(' AND ');
    const offset = (page - 1) * limit;

    const countResult = await pool.query(
      \`SELECT COUNT(*)::int AS total FROM compliance_records cr JOIN compliance_criteria cc ON cc.id = cr.criteria_id WHERE \${whereClause}\`,
      params
    );
    const dataResult = await pool.query(
      \`SELECT cr.*, cc.framework, cc.criteria_code, cc.criteria_name, cc.target_value
       FROM compliance_records cr JOIN compliance_criteria cc ON cc.id = cr.criteria_id
       WHERE \${whereClause}
       ORDER BY cr.academic_year DESC, cc.criteria_code ASC
       LIMIT $\${idx++} OFFSET $\${idx++}\`,
      [...params, limit, offset]
    );
    return { rows: dataResult.rows, total: countResult.rows[0].total };
  }

  static async update(id: number, data: Partial<{ achievedValue: number; evidenceLinks: string[]; remarks: string }>) {
    const existing = await ComplianceRecordModel.findById(id);
    if (!existing) throw new AppError('Compliance record not found', 404);

    let status = existing.status;
    if (data.achievedValue !== undefined) {
      const criteria = await ComplianceCriteriaModel.findById(existing.criteria_id);
      if (criteria) status = computeComplianceStatus(data.achievedValue, criteria.target_value);
    }

    const result = await pool.query(
      \`UPDATE compliance_records SET
        achieved_value = COALESCE($1, achieved_value),
        status = $2,
        evidence_links = COALESCE($3, evidence_links),
        remarks = COALESCE($4, remarks),
        updated_at = NOW()
       WHERE id = $5
       RETURNING *\`,
      [
        data.achievedValue ?? null,
        status,
        data.evidenceLinks ? JSON.stringify(data.evidenceLinks) : null,
        data.remarks ?? null,
        id,
      ]
    );
    return result.rows[0];
  }

  static async softDelete(id: number) {
    const result = await pool.query(
      \`UPDATE compliance_records SET is_deleted = true, updated_at = NOW() WHERE id = $1 RETURNING id\`,
      [id]
    );
    if (result.rowCount === 0) throw new AppError('Compliance record not found', 404);
    return true;
  }

  static async getLoopSummary(framework: ComplianceFramework, academicYear: string) {
    const result = await pool.query(
      \`SELECT cc.criteria_code, cc.criteria_name, cc.target_value, cc.weight,
              cr.achieved_value, cr.status, cr.id AS record_id
       FROM compliance_criteria cc
       LEFT JOIN compliance_records cr
         ON cr.criteria_id = cc.id AND cr.academic_year = $2 AND cr.is_deleted = false
       WHERE cc.framework = $1
       ORDER BY cc.criteria_code ASC\`,
      [framework, academicYear]
    );
    return result.rows;
  }

  static async getPreviousYearRecord(criteriaId: number, currentAcademicYear: string) {
    const result = await pool.query(
      \`SELECT * FROM compliance_records
       WHERE criteria_id = $1 AND academic_year < $2 AND is_deleted = false
       ORDER BY academic_year DESC LIMIT 1\`,
      [criteriaId, currentAcademicYear]
    );
    return result.rows[0] || null;
  }
}

export class AuditLogModel {
  static async record(entry: {
    moduleName: string;
    action: AuditAction;
    entityType: string;
    entityId: number;
    performedBy: number;
    beforeState?: Record<string, unknown> | null;
    afterState?: Record<string, unknown> | null;
    ipAddress?: string;
  }): Promise<AuditLogRow> {
    const result = await pool.query(
      \`INSERT INTO audit_logs
        (module_name, action, entity_type, entity_id, performed_by, before_state, after_state, ip_address, created_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,NOW())
       RETURNING *\`,
      [
        entry.moduleName,
        entry.action,
        entry.entityType,
        entry.entityId,
        entry.performedBy,
        entry.beforeState ? JSON.stringify(entry.beforeState) : null,
        entry.afterState ? JSON.stringify(entry.afterState) : null,
        entry.ipAddress || null,
      ]
    );
    return result.rows[0];
  }

  static async findAll(
    filters: { moduleName?: string; action?: AuditAction; entityType?: string; performedBy?: number },
    page: number,
    limit: number
  ) {
    const conditions: string[] = ['1 = 1'];
    const params: any[] = [];
    let idx = 1;

    if (filters.moduleName) {
      conditions.push(\`module_name = $\${idx++}\`);
      params.push(filters.moduleName);
    }
    if (filters.action) {
      conditions.push(\`action = $\${idx++}\`);
      params.push(filters.action);
    }
    if (filters.entityType) {
      conditions.push(\`entity_type = $\${idx++}\`);
      params.push(filters.entityType);
    }
    if (filters.performedBy) {
      conditions.push(\`performed_by = $\${idx++}\`);
      params.push(filters.performedBy);
    }

    const whereClause = conditions.join(' AND ');
    const offset = (page - 1) * limit;

    const countResult = await pool.query(\`SELECT COUNT(*)::int AS total FROM audit_logs WHERE \${whereClause}\`, params);
    const dataResult = await pool.query(
      \`SELECT * FROM audit_logs WHERE \${whereClause} ORDER BY created_at DESC LIMIT $\${idx++} OFFSET $\${idx++}\`,
      [...params, limit, offset]
    );
    return { rows: dataResult.rows, total: countResult.rows[0].total };
  }

  static async findByEntity(entityType: string, entityId: number) {
    const result = await pool.query(
      \`SELECT * FROM audit_logs WHERE entity_type = $1 AND entity_id = $2 ORDER BY created_at ASC\`,
      [entityType, entityId]
    );
    return result.rows;
  }
}
`;

/* ---- services/compliance.service.ts ---- */
const COMPLIANCE_SERVICE = `import {
  ComplianceCriteriaModel,
  ComplianceRecordModel,
  AuditLogModel,
  ComplianceFramework,
  AuditAction,
} from '../models/compliance.model';
import { getPagination, buildMeta } from '../utils/pagination';
import { AppError } from '../utils/AppError';

export class ComplianceService {
  static async createCriteria(body: any) {
    if (!body.framework || !body.criteriaCode || !body.criteriaName || body.targetValue === undefined) {
      throw new AppError('framework, criteriaCode, criteriaName and targetValue are required', 400);
    }
    return ComplianceCriteriaModel.create(body);
  }

  static async listCriteria(framework?: ComplianceFramework) {
    return ComplianceCriteriaModel.findAll(framework);
  }

  static async submitRecord(body: any, userId: number, ipAddress?: string) {
    if (!body.criteriaId || !body.academicYear || body.achievedValue === undefined) {
      throw new AppError('criteriaId, academicYear and achievedValue are required', 400);
    }
    const record = await ComplianceRecordModel.create({ ...body, submittedBy: userId });

    await AuditLogModel.record({
      moduleName: 'compliance',
      action: 'create',
      entityType: 'compliance_record',
      entityId: record.id,
      performedBy: userId,
      beforeState: null,
      afterState: record,
      ipAddress,
    });

    return record;
  }

  static async list(query: any) {
    const { page, limit } = getPagination(query);
    const filters = {
      framework: query.framework || undefined,
      academicYear: query.academicYear || undefined,
      departmentId: query.departmentId ? Number(query.departmentId) : undefined,
      status: query.status || undefined,
    };
    const { rows, total } = await ComplianceRecordModel.findAll(filters, page, limit);
    return { records: rows, meta: buildMeta(total, page, limit) };
  }

  static async getById(id: number) {
    const record = await ComplianceRecordModel.findById(id);
    if (!record) throw new AppError('Compliance record not found', 404);
    return record;
  }

  static async updateRecord(id: number, body: any, userId: number, ipAddress?: string) {
    const before = await ComplianceRecordModel.findById(id);
    if (!before) throw new AppError('Compliance record not found', 404);

    const after = await ComplianceRecordModel.update(id, body);

    await AuditLogModel.record({
      moduleName: 'compliance',
      action: 'update',
      entityType: 'compliance_record',
      entityId: id,
      performedBy: userId,
      beforeState: before,
      afterState: after,
      ipAddress,
    });

    return after;
  }

  static async removeRecord(id: number, userId: number, ipAddress?: string) {
    const before = await ComplianceRecordModel.findById(id);
    if (!before) throw new AppError('Compliance record not found', 404);

    await ComplianceRecordModel.softDelete(id);

    await AuditLogModel.record({
      moduleName: 'compliance',
      action: 'delete',
      entityType: 'compliance_record',
      entityId: id,
      performedBy: userId,
      beforeState: before,
      afterState: null,
      ipAddress,
    });

    return true;
  }

  /**
   * The compliance loop: for every criterion in a framework/year, compute
   * status against target, compare with the previous year's trend, and flag
   * anything non-compliant or at-risk for IQAC follow-up action.
   */
  static async getComplianceLoop(framework: ComplianceFramework, academicYear: string) {
    const rows = await ComplianceRecordModel.getLoopSummary(framework, academicYear);

    const loop = await Promise.all(
      rows.map(async (row: any) => {
        const previous = await ComplianceRecordModel.getPreviousYearRecord(row.record_id ?? -1, academicYear);
        const achieved = row.achieved_value !== null ? Number(row.achieved_value) : null;
        const target = Number(row.target_value);
        const gap = achieved !== null ? Math.round((target - achieved) * 100) / 100 : null;
        const trend =
          previous && achieved !== null
            ? achieved > Number(previous.achieved_value)
              ? 'improving'
              : achieved < Number(previous.achieved_value)
              ? 'declining'
              : 'stable'
            : 'no_prior_data';

        return {
          criteriaCode: row.criteria_code,
          criteriaName: row.criteria_name,
          targetValue: target,
          achievedValue: achieved,
          status: row.status || 'non_compliant',
          gap,
          trend,
          requiresIqacFollowUp: row.status !== 'compliant' || achieved === null,
        };
      })
    );

    const totalCriteria = loop.length;
    const compliantCount = loop.filter((l) => l.status === 'compliant').length;
    const overallCompliancePct =
      totalCriteria > 0 ? Math.round((compliantCount / totalCriteria) * 10000) / 100 : 0;

    return {
      framework,
      academicYear,
      overallCompliancePct,
      totalCriteria,
      compliantCount,
      criteria: loop,
    };
  }

  static async getGapAnalysis(framework: ComplianceFramework, academicYear: string) {
    const loop = await ComplianceService.getComplianceLoop(framework, academicYear);
    return {
      framework,
      academicYear,
      gaps: loop.criteria.filter((c) => c.status !== 'compliant'),
    };
  }

  static async listAuditLogs(query: any) {
    const { page, limit } = getPagination(query);
    const filters = {
      moduleName: query.moduleName || undefined,
      action: query.action as AuditAction | undefined,
      entityType: query.entityType || undefined,
      performedBy: query.performedBy ? Number(query.performedBy) : undefined,
    };
    const { rows, total } = await AuditLogModel.findAll(filters, page, limit);
    return { logs: rows, meta: buildMeta(total, page, limit) };
  }

  static async getAuditTrail(entityType: string, entityId: number) {
    return AuditLogModel.findByEntity(entityType, entityId);
  }
}

export default ComplianceService;
`;

/* ---- controllers/compliance.controller.ts ---- */
const COMPLIANCE_CONTROLLER = `import { Request, Response } from 'express';
import { asyncHandler } from '../utils/asyncHandler';
import { sendResponse } from '../utils/response';
import { ComplianceService } from '../services/compliance.service';

export const createComplianceCriteria = asyncHandler(async (req: Request, res: Response) => {
  const criteria = await ComplianceService.createCriteria(req.body);
  sendResponse(res, 201, 'Compliance criteria created', criteria);
});

export const listComplianceCriteria = asyncHandler(async (req: Request, res: Response) => {
  const criteria = await ComplianceService.listCriteria(req.query.framework as any);
  sendResponse(res, 200, 'Compliance criteria retrieved', criteria);
});

export const submitComplianceRecord = asyncHandler(async (req: Request, res: Response) => {
  const userId = (req as any).user?.id;
  const record = await ComplianceService.submitRecord(req.body, userId, req.ip);
  sendResponse(res, 201, 'Compliance record submitted', record);
});

export const listComplianceRecords = asyncHandler(async (req: Request, res: Response) => {
  const result = await ComplianceService.list(req.query);
  sendResponse(res, 200, 'Compliance records retrieved', result);
});

export const getComplianceRecord = asyncHandler(async (req: Request, res: Response) => {
  const record = await ComplianceService.getById(Number(req.params.id));
  sendResponse(res, 200, 'Compliance record retrieved', record);
});

export const updateComplianceRecord = asyncHandler(async (req: Request, res: Response) => {
  const userId = (req as any).user?.id;
  const record = await ComplianceService.updateRecord(Number(req.params.id), req.body, userId, req.ip);
  sendResponse(res, 200, 'Compliance record updated', record);
});

export const deleteComplianceRecord = asyncHandler(async (req: Request, res: Response) => {
  const userId = (req as any).user?.id;
  await ComplianceService.removeRecord(Number(req.params.id), userId, req.ip);
  sendResponse(res, 200, 'Compliance record deleted', null);
});

export const getComplianceLoop = asyncHandler(async (req: Request, res: Response) => {
  const { framework, academicYear } = req.params;
  const loop = await ComplianceService.getComplianceLoop(framework as any, academicYear);
  sendResponse(res, 200, 'Compliance loop summary retrieved', loop);
});

export const getGapAnalysis = asyncHandler(async (req: Request, res: Response) => {
  const { framework, academicYear } = req.params;
  const gaps = await ComplianceService.getGapAnalysis(framework as any, academicYear);
  sendResponse(res, 200, 'Gap analysis retrieved', gaps);
});

export const listAuditLogs = asyncHandler(async (req: Request, res: Response) => {
  const result = await ComplianceService.listAuditLogs(req.query);
  sendResponse(res, 200, 'Audit logs retrieved', result);
});

export const getAuditTrail = asyncHandler(async (req: Request, res: Response) => {
  const { entityType, entityId } = req.params;
  const trail = await ComplianceService.getAuditTrail(entityType, Number(entityId));
  sendResponse(res, 200, 'Audit trail retrieved', trail);
});
`;

/* ---- routes/compliance.routes.ts ---- */
const COMPLIANCE_ROUTES = `import { Router } from 'express';
import { authenticate } from '../middleware/auth';
import { authorize } from '../middleware/rbac';
import {
  createComplianceCriteria,
  listComplianceCriteria,
  submitComplianceRecord,
  listComplianceRecords,
  getComplianceRecord,
  updateComplianceRecord,
  deleteComplianceRecord,
  getComplianceLoop,
  getGapAnalysis,
  listAuditLogs,
  getAuditTrail,
} from '../controllers/compliance.controller';

const router = Router();
router.use(authenticate);

// Criteria (admin-managed master data)
router.get('/criteria', authorize(['admin', 'iqac_coordinator', 'hod']), listComplianceCriteria);
router.post('/criteria', authorize(['admin']), createComplianceCriteria);

// Compliance records
router.get('/records', authorize(['admin', 'iqac_coordinator', 'hod']), listComplianceRecords);
router.get('/records/:id', authorize(['admin', 'iqac_coordinator', 'hod']), getComplianceRecord);
router.post('/records', authorize(['admin', 'iqac_coordinator', 'hod']), submitComplianceRecord);
router.put('/records/:id', authorize(['admin', 'iqac_coordinator']), updateComplianceRecord);
router.delete('/records/:id', authorize(['admin']), deleteComplianceRecord);

// Compliance loop & gap analysis
router.get('/loop/:framework/:academicYear', authorize(['admin', 'iqac_coordinator', 'hod']), getComplianceLoop);
router.get(
  '/gap-analysis/:framework/:academicYear',
  authorize(['admin', 'iqac_coordinator', 'hod']),
  getGapAnalysis
);

// Audit logs
router.get('/audit-logs', authorize(['admin', 'iqac_coordinator']), listAuditLogs);
router.get('/audit-logs/:entityType/:entityId', authorize(['admin', 'iqac_coordinator']), getAuditTrail);

export default router;
`;

function run() {
  console.log('AccrediAI — Phase 4: Core Platform Modules');
  console.log('==================================================');
  ensureDirs();

  writeFile('models/student-record.model.ts', STUDENT_RECORD_MODEL);
  writeFile('services/student-record.service.ts', STUDENT_RECORD_SERVICE);
  writeFile('controllers/student-record.controller.ts', STUDENT_RECORD_CONTROLLER);
  writeFile('routes/student-record.routes.ts', STUDENT_RECORD_ROUTES);
  writeFile('models/research.model.ts', RESEARCH_MODEL);
  writeFile('services/research.service.ts', RESEARCH_SERVICE);
  writeFile('controllers/research.controller.ts', RESEARCH_CONTROLLER);
  writeFile('routes/research.routes.ts', RESEARCH_ROUTES);
  writeFile('models/placement.model.ts', PLACEMENT_MODEL);
  writeFile('services/placement.service.ts', PLACEMENT_SERVICE);
  writeFile('controllers/placement.controller.ts', PLACEMENT_CONTROLLER);
  writeFile('routes/placement.routes.ts', PLACEMENT_ROUTES);
  writeFile('models/compliance.model.ts', COMPLIANCE_MODEL);
  writeFile('services/compliance.service.ts', COMPLIANCE_SERVICE);
  writeFile('controllers/compliance.controller.ts', COMPLIANCE_CONTROLLER);
  writeFile('routes/compliance.routes.ts', COMPLIANCE_ROUTES);

  console.log('==================================================');
  console.log('Phase 4 complete. 16 files written under backend/src/.');
  console.log('');
  console.log('Mount the routers in your main app file, e.g.:');
  console.log("  import studentRecordRoutes from './routes/student-record.routes';");
  console.log("  import researchRoutes from './routes/research.routes';");
  console.log("  import placementRoutes from './routes/placement.routes';");
  console.log("  import complianceRoutes from './routes/compliance.routes';");
  console.log("  app.use('/api/student-records', studentRecordRoutes);");
  console.log("  app.use('/api/research', researchRoutes);");
  console.log("  app.use('/api/placement', placementRoutes);");
  console.log("  app.use('/api/compliance', complianceRoutes);");
}


run();