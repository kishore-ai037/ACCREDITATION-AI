# AccrediAI Backend API

Production-grade REST API for the AccrediAI intelligent accreditation management system. Handles NAAC, NBA, and IQAC processes for Indian higher education institutions.

## Stack

- **Runtime:** Node.js 22 + TypeScript
- **Framework:** Express 5
- **Database:** PostgreSQL 16 (direct `pg` queries — no ORM)
- **Auth:** JWT (access + refresh tokens, bcryptjs hashing)
- **File uploads:** Multer (disk storage, UUID filenames)
- **Validation:** express-validator
- **Rate limiting:** express-rate-limit
- **Security:** Helmet, CORS

## Project Structure

```
src/
├── ai/                    # Evidence classification engine (keyword heuristics)
│   └── evidenceClassifier.ts
├── config/                # App config loader and DB connection pool
│   ├── index.ts
│   └── database.ts
├── controllers/           # HTTP request handlers (thin — delegate to services)
│   ├── authController.ts
│   ├── userController.ts
│   ├── departmentController.ts
│   ├── facultyController.ts
│   ├── studentController.ts
│   ├── documentController.ts
│   ├── iqacController.ts
│   ├── researchController.ts
│   ├── placementController.ts
│   ├── criteriaController.ts
│   ├── reportController.ts
│   ├── aiAnalysisController.ts
│   ├── notificationController.ts
│   └── dashboardController.ts
├── db/                    # Database scripts
│   ├── migrate.ts         # Idempotent schema runner (npm run db:migrate)
│   ├── seed.ts            # Demo data seeder (npm run db:seed)
│   ├── reset.ts           # Full DB wipe (dev only)
│   ├── migrations/        # Plain-SQL schema reference
│   └── seeds/             # Seed data reference (JSON)
├── middleware/            # Express middleware
│   ├── auth.ts            # JWT bearer token verification
│   ├── rbac.ts            # Role-based access control guards
│   ├── errorHandler.ts    # Global error handler + AppError class
│   └── validate.ts        # express-validator result checker
├── routes/                # Route definitions (14 modules + aggregator)
├── services/              # Business logic (all DB interaction lives here)
├── types/                 # Shared TypeScript types, enums, Express augmentation
│   └── index.ts
├── utils/                 # Shared utilities
│   ├── jwt.ts             # Token sign/verify helpers
│   ├── logger.ts          # Activity log writer
│   ├── pagination.ts      # Page/limit parsing + response builder
│   ├── response.ts        # Standardised HTTP response helpers
│   └── upload.ts          # Multer configuration
├── validators/            # express-validator rule sets (one file per domain)
├── app.ts                 # Express application setup (middleware stack, routes)
└── index.ts               # Server entry point (bootstrap + graceful shutdown)
```

## Quick Start

### Prerequisites

- Node.js 22+
- PostgreSQL 16+

### 1. Clone and install

```bash
git clone <repo-url>
cd accredi-backend
npm install
```

### 2. Configure environment

```bash
cp .env.example .env
# Edit .env — set DATABASE_URL, JWT_SECRET, JWT_REFRESH_SECRET at minimum
```

### 3. Create the database

```sql
-- Run in psql as a superuser:
CREATE USER accredi WITH PASSWORD 'your_password' CREATEDB;
CREATE DATABASE accredi_db OWNER accredi;
```

### 4. Run migrations

```bash
npm run db:migrate
```

### 5. Seed demo data (optional)

```bash
npm run db:seed
```

Demo accounts (password: `Admin@123`):

| Email | Role |
|-------|------|
| admin@accredi.ai | Admin / Principal |
| iqac@accredi.ai | IQAC Coordinator |
| hod@accredi.ai | Head of Department (CSE) |
| faculty@accredi.ai | Faculty |

### 6. Start development server

```bash
npm run dev
```

API available at `http://localhost:4000`. Health check: `http://localhost:4000/health`.

### 7. Production build

```bash
npm run build
npm start
```

---

## Docker

### Full stack with Docker Compose

```bash
# Start PostgreSQL + API + run migrations
docker compose up -d

# Seed demo data
docker compose exec api node dist/index.js  # wait for startup, then:
docker compose run --rm migrate npx tsx src/db/seed.ts
```

### API only

```bash
docker build -t accredi-api .
docker run -p 4000:4000 --env-file .env accredi-api
```

---

## API Reference

All endpoints are prefixed with `/api`. Authentication via `Authorization: Bearer <token>`.

### Auth
| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | /api/auth/login | — | Login, receive access + refresh tokens |
| POST | /api/auth/refresh | — | Exchange refresh token for new token pair |
| POST | /api/auth/logout | ✓ | Invalidate refresh token |
| GET | /api/auth/me | ✓ | Get authenticated user profile |
| POST | /api/auth/change-password | ✓ | Change own password |

### Users
| Method | Path | Min Role | Description |
|--------|------|----------|-------------|
| GET | /api/users | HoD | List users (paginated) |
| GET | /api/users/:id | HoD | Get user by ID |
| POST | /api/users | Admin | Create user |
| PUT | /api/users/:id | Admin | Update user |
| DELETE | /api/users/:id | Admin | Delete user |

### Departments
| Method | Path | Min Role | Description |
|--------|------|----------|-------------|
| GET | /api/departments | Any | List departments |
| GET | /api/departments/:id | Any | Get department |
| POST | /api/departments | Staff | Create department |
| PUT | /api/departments/:id | Staff | Update department |
| DELETE | /api/departments/:id | Staff | Delete department |

### Faculty
`GET /api/faculty`, `GET /api/faculty/stats`, `GET /api/faculty/:id`
`POST /api/faculty` (HoD+), `PUT /api/faculty/:id` (HoD+), `DELETE /api/faculty/:id` (HoD+)

### Students
`GET /api/students`, `GET /api/students/stats`, `GET /api/students/:id`
`POST /api/students` (HoD+), `PUT /api/students/:id` (HoD+), `DELETE /api/students/:id` (HoD+)

### Documents
`GET /api/documents`, `GET /api/documents/stats`, `GET /api/documents/search`, `GET /api/documents/:id`
`POST /api/documents/upload` (multipart, Staff+)
`PATCH /api/documents/:id/approve` (HoD+), `PATCH /api/documents/:id/reject` (HoD+)
`DELETE /api/documents/:id` (Staff+)

### IQAC
`GET|POST /api/iqac/meetings`, `GET|PUT|DELETE /api/iqac/meetings/:id`
`GET|POST /api/iqac/action-plans`, `PUT|DELETE /api/iqac/action-plans/:id`

### Research
`GET /api/research`, `GET /api/research/stats`, `GET /api/research/:id`
`POST /api/research` (Staff+), `PUT /api/research/:id` (Staff+)
`PATCH /api/research/:id/verify` (HoD+), `DELETE /api/research/:id` (Staff+)

### Placements
`GET /api/placements`, `GET /api/placements/stats`, `GET /api/placements/trend`
`PUT /api/placements/student/:studentId` (HoD+), `DELETE /api/placements/:id` (HoD+)

### NAAC / NBA Criteria
`GET|POST /api/criteria/naac`, `GET /api/criteria/naac/overview`, `GET|PUT|DELETE /api/criteria/naac/:id`
`GET|POST /api/criteria/nba`, `GET /api/criteria/nba/overview`, `GET|PUT|DELETE /api/criteria/nba/:id`

### Reports
`GET /api/reports`, `GET /api/reports/:id`, `GET /api/reports/:id/download`
`POST /api/reports/generate` (Staff+), `DELETE /api/reports/:id` (Staff+)

### AI Analysis
`GET /api/ai-analysis`, `GET /api/ai-analysis/stats`, `GET /api/ai-analysis/:id`
`POST /api/ai-analysis/map-document` (Staff+), `POST /api/ai-analysis/bulk-search` (Staff+)

### Notifications
`GET /api/notifications`, `GET /api/notifications/unread-count`
`PATCH /api/notifications/:id/read`, `PATCH /api/notifications/read-all`
`DELETE /api/notifications/:id`

### Dashboard
`GET /api/dashboard/summary`, `GET /api/dashboard/recent-activity`, `GET /api/dashboard/document-trend`

---

## Role Hierarchy

```
admin / principal
    └── iqac_coordinator (staffOrAbove)
            └── hod (hodOrAbove)
                    └── faculty (anyStaff)
                            └── student
```

---

## Environment Variables

See `.env.example` for all variables. Required:
- `DATABASE_URL` — PostgreSQL connection string
- `JWT_SECRET` — min 32 characters, random
- `JWT_REFRESH_SECRET` — min 32 characters, different from JWT_SECRET

---

## npm Scripts

| Script | Description |
|--------|-------------|
| `npm run dev` | Start development server with hot reload (tsx watch) |
| `npm run build` | Compile TypeScript to `dist/` |
| `npm start` | Run compiled production server |
| `npm run db:migrate` | Apply schema migrations (idempotent) |
| `npm run db:seed` | Insert demo data |
| `npm run db:reset` | Drop all tables and types (dev only) |
