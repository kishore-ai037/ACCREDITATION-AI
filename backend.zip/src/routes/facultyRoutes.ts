import { Router } from 'express';
import * as facultyController from '../controllers/facultyController';
import { authenticate } from '../middleware/auth';
import { hodOrAbove } from '../middleware/rbac';
import { validate } from '../middleware/validate';
import { createFacultyValidator } from '../validators/facultyValidators';

const router = Router();

router.use(authenticate);

router.get('/', facultyController.list);
router.get('/stats', facultyController.stats);
router.get('/:id', facultyController.getOne);

router.post('/', hodOrAbove, createFacultyValidator, validate, facultyController.create);

router.put('/:id', hodOrAbove, facultyController.update);
router.delete('/:id', hodOrAbove, facultyController.remove);

export default router;
