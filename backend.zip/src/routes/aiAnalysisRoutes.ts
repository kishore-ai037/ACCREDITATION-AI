import { Router } from 'express';
import * as aiController from '../controllers/aiAnalysisController';
import { authenticate } from '../middleware/auth';
import { anyStaff } from '../middleware/rbac';
import { validate } from '../middleware/validate';
import { mapDocumentValidator } from '../validators/reportAndAiValidators';

const router = Router();

router.use(authenticate);

router.get('/', aiController.list);
router.get('/stats', aiController.stats);
router.get('/:id', aiController.getOne);
router.post('/map-document', anyStaff, mapDocumentValidator, validate, aiController.mapDocument);
router.post('/bulk-search', anyStaff, aiController.bulkSearch);

export default router;
