import { Router } from 'express';
import * as departmentController from '../controllers/departmentController';
import { authenticate } from '../middleware/auth';
import { staffOrAbove } from '../middleware/rbac';
import { validate } from '../middleware/validate';
import { createDepartmentValidator } from '../validators/departmentValidators';

const router = Router();

router.use(authenticate);

router.get('/', departmentController.list);
router.get('/:id', departmentController.getOne);

router.post('/', staffOrAbove, createDepartmentValidator, validate, departmentController.create);

router.put('/:id', staffOrAbove, departmentController.update);
router.delete('/:id', staffOrAbove, departmentController.remove);

export default router;
