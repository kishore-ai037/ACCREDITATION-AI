import { Router } from 'express';
import * as dashboardController from '../controllers/dashboardController';
import { authenticate } from '../middleware/auth';

const router = Router();

router.use(authenticate);

router.get('/summary', dashboardController.summary);
router.get('/recent-activity', dashboardController.recentActivity);
router.get('/document-trend', dashboardController.documentTrend);

export default router;
