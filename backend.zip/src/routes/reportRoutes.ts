import { Router } from 'express';
import * as reportController from '../controllers/reportController';
import { authenticate } from '../middleware/auth';
import { staffOrAbove } from '../middleware/rbac';
import { validate } from '../middleware/validate';
import { generateReportValidator } from '../validators/reportAndAiValidators';

const router = Router();

router.use(authenticate);

router.get('/', reportController.list);
router.get('/:id', reportController.getOne);
router.get('/:id/download', reportController.download);
router.post('/generate', staffOrAbove, generateReportValidator, validate, reportController.generate);
router.delete('/:id', staffOrAbove, reportController.remove);

export default router;
