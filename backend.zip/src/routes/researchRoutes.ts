import { Router } from 'express';
import * as researchController from '../controllers/researchController';
import { authenticate } from '../middleware/auth';
import { anyStaff, hodOrAbove } from '../middleware/rbac';
import { validate } from '../middleware/validate';
import { createResearchValidator } from '../validators/researchValidators';

const router = Router();

router.use(authenticate);

router.get('/', researchController.list);
router.get('/stats', researchController.stats);
router.get('/:id', researchController.getOne);

router.post('/', anyStaff, createResearchValidator, validate, researchController.create);
router.put('/:id', anyStaff, researchController.update);
router.patch('/:id/verify', hodOrAbove, researchController.verify);
router.delete('/:id', anyStaff, researchController.remove);

export default router;
