import { Router } from 'express';
import authRoutes from './authRoutes';
import userRoutes from './userRoutes';
import departmentRoutes from './departmentRoutes';
import facultyRoutes from './facultyRoutes';
import studentRoutes from './studentRoutes';
import documentRoutes from './documentRoutes';
import iqacRoutes from './iqacRoutes';
import researchRoutes from './researchRoutes';
import placementRoutes from './placementRoutes';
import criteriaRoutes from './criteriaRoutes';
import reportRoutes from './reportRoutes';
import aiAnalysisRoutes from './aiAnalysisRoutes';
import notificationRoutes from './notificationRoutes';
import dashboardRoutes from './dashboardRoutes';

const router = Router();

router.use('/auth', authRoutes);
router.use('/users', userRoutes);
router.use('/departments', departmentRoutes);
router.use('/faculty', facultyRoutes);
router.use('/students', studentRoutes);
router.use('/documents', documentRoutes);
router.use('/iqac', iqacRoutes);
router.use('/research', researchRoutes);
router.use('/placements', placementRoutes);
router.use('/criteria', criteriaRoutes);
router.use('/reports', reportRoutes);
router.use('/ai-analysis', aiAnalysisRoutes);
router.use('/notifications', notificationRoutes);
router.use('/dashboard', dashboardRoutes);

export default router;
