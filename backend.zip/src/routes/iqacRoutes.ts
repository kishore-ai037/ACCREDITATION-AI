import { Router } from 'express';
import * as iqacController from '../controllers/iqacController';
import { authenticate } from '../middleware/auth';
import { staffOrAbove } from '../middleware/rbac';
import { validate } from '../middleware/validate';
import { createMeetingValidator, createActionPlanValidator } from '../validators/iqacValidators';

const router = Router();

router.use(authenticate);

// Meetings
router.get('/meetings', iqacController.listMeetings);
router.get('/meetings/:id', iqacController.getMeeting);
router.post('/meetings', staffOrAbove, createMeetingValidator, validate, iqacController.createMeeting);
router.put('/meetings/:id', staffOrAbove, iqacController.updateMeeting);
router.delete('/meetings/:id', staffOrAbove, iqacController.deleteMeeting);

// Action Plans
router.get('/action-plans', iqacController.listActionPlans);
router.post(
  '/action-plans',
  staffOrAbove,
  createActionPlanValidator,
  validate,
  iqacController.createActionPlan
);
router.put('/action-plans/:id', staffOrAbove, iqacController.updateActionPlan);
router.delete('/action-plans/:id', staffOrAbove, iqacController.deleteActionPlan);

export default router;
