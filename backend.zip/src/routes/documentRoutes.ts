import { Router } from 'express';
import * as documentController from '../controllers/documentController';
import { authenticate } from '../middleware/auth';
import { anyStaff, hodOrAbove } from '../middleware/rbac';
import { validate } from '../middleware/validate';
import { upload } from '../utils/upload';
import { uploadDocumentValidator } from '../validators/documentValidators';

const router = Router();

router.use(authenticate);

router.get('/', documentController.list);
router.get('/stats', documentController.stats);
router.get('/search', documentController.search);
router.get('/:id', documentController.getOne);

router.post(
  '/upload',
  anyStaff,
  upload.single('file'),
  uploadDocumentValidator,
  validate,
  documentController.upload
);

router.patch('/:id/approve', hodOrAbove, documentController.approve);
router.patch('/:id/reject', hodOrAbove, documentController.reject);
router.patch('/:id/status', hodOrAbove, documentController.setStatus);

router.delete('/:id', anyStaff, documentController.remove);

export default router;
