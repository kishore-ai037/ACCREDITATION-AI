import { Router } from 'express';
import * as userController from '../controllers/userController';
import { authenticate } from '../middleware/auth';
import { hodOrAbove, adminOnly } from '../middleware/rbac';
import { validate } from '../middleware/validate';
import { createUserValidator } from '../validators/userValidators';

const router = Router();

router.use(authenticate);

router.get('/', hodOrAbove, userController.list);
router.get('/:id', hodOrAbove, userController.getOne);

router.post('/', adminOnly, createUserValidator, validate, userController.create);

router.put('/:id', adminOnly, userController.update);
router.delete('/:id', adminOnly, userController.remove);

export default router;
