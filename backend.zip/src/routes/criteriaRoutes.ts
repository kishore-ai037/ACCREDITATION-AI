import { Router } from 'express';
import * as criteriaController from '../controllers/criteriaController';
import { authenticate } from '../middleware/auth';
import { staffOrAbove, hodOrAbove } from '../middleware/rbac';
import { validate } from '../middleware/validate';
import { createNaacValidator, createNbaValidator } from '../validators/criteriaValidators';

const router = Router();

router.use(authenticate);

// NAAC
router.get('/naac', criteriaController.listNaac);
router.get('/naac/overview', criteriaController.naacOverview);
router.get('/naac/:id', criteriaController.getNaacOne);
router.post('/naac', staffOrAbove, createNaacValidator, validate, criteriaController.createNaac);
router.put('/naac/:id', staffOrAbove, criteriaController.updateNaac);
router.delete('/naac/:id', staffOrAbove, criteriaController.deleteNaac);

// NBA / OBE
router.get('/nba', criteriaController.listNba);
router.get('/nba/overview', criteriaController.nbaOverview);
router.get('/nba/:id', criteriaController.getNbaOne);
router.post('/nba', hodOrAbove, createNbaValidator, validate, criteriaController.createNba);
router.put('/nba/:id', hodOrAbove, criteriaController.updateNba);
router.delete('/nba/:id', hodOrAbove, criteriaController.deleteNba);

export default router;
