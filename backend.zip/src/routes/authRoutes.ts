import { Router } from 'express';
import * as authController from '../controllers/authController';
import { authenticate } from '../middleware/auth';
import { validate } from '../middleware/validate';
import { loginValidator, refreshValidator, changePasswordValidator } from '../validators/authValidators';

const router = Router();

router.post('/login', loginValidator, validate, authController.login);

router.post('/refresh', refreshValidator, validate, authController.refresh);

router.post('/logout', authenticate, authController.logout);
router.get('/me', authenticate, authController.me);

router.post(
  '/change-password',
  authenticate,
  changePasswordValidator,
  validate,
  authController.changePassword
);

export default router;
