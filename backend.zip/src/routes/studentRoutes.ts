import { Router } from 'express';
import * as studentController from '../controllers/studentController';
import { authenticate } from '../middleware/auth';
import { hodOrAbove } from '../middleware/rbac';
import { validate } from '../middleware/validate';
import { createStudentValidator } from '../validators/studentValidators';

const router = Router();

router.use(authenticate);

router.get('/', studentController.list);
router.get('/stats', studentController.stats);
router.get('/:id', studentController.getOne);

router.post('/', hodOrAbove, createStudentValidator, validate, studentController.create);

router.put('/:id', hodOrAbove, studentController.update);
router.delete('/:id', hodOrAbove, studentController.remove);

export default router;
