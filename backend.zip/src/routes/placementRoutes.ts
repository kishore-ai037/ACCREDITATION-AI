import { Router } from 'express';
import * as placementController from '../controllers/placementController';
import { authenticate } from '../middleware/auth';
import { hodOrAbove } from '../middleware/rbac';

const router = Router();

router.use(authenticate);

router.get('/', placementController.list);
router.get('/stats', placementController.stats);
router.get('/trend', placementController.trend);
router.get('/:id', placementController.getOne);

router.put('/student/:studentId', hodOrAbove, placementController.upsert);
router.delete('/:id', hodOrAbove, placementController.remove);

export default router;
