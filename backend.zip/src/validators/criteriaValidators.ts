import { body } from 'express-validator';

export const createNaacValidator = [
  body('criterion_no').notEmpty().withMessage('criterion_no is required'),
  body('criterion_name').notEmpty().withMessage('criterion_name is required'),
];

export const createNbaValidator = [
  body('department_id').isUUID().withMessage('Valid department_id is required'),
  body('criterion_no').notEmpty().withMessage('criterion_no is required'),
  body('criterion_name').notEmpty().withMessage('criterion_name is required'),
];
