import { body } from 'express-validator';

export const createMeetingValidator = [
  body('title').notEmpty().withMessage('Meeting title is required'),
  body('meeting_date').isISO8601().withMessage('Valid meeting_date is required'),
];

export const createActionPlanValidator = [
  body('title').notEmpty().withMessage('Action plan title is required'),
];
