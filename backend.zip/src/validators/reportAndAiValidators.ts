import { body } from 'express-validator';

export const generateReportValidator = [
  body('title').notEmpty().withMessage('Report title is required'),
  body('type')
    .isIn(['naac_ssr', 'naac_iqar', 'nba_sar', 'iqac_aqar', 'custom'])
    .withMessage('Invalid report type'),
];

export const mapDocumentValidator = [
  body('document_id').isUUID().withMessage('Valid document_id is required'),
];
