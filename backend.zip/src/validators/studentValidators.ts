import { body } from 'express-validator';

export const createStudentValidator = [
  body('department_id').isUUID().withMessage('Valid department_id is required'),
  body('roll_number').notEmpty().withMessage('Roll number is required'),
  body('name').notEmpty().withMessage('Name is required'),
  body('batch_year').isInt({ min: 2000, max: 2100 }).withMessage('Valid batch year is required'),
];
