import { body } from 'express-validator';

export const createDepartmentValidator = [
  body('name').notEmpty().withMessage('Department name is required'),
  body('code').notEmpty().withMessage('Department code is required'),
];
