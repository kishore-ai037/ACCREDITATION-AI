import { body, param, query } from 'express-validator';

export const createDepartmentValidator = [
  body('name')
    .trim()
    .notEmpty().withMessage('Department name is required.')
    .isLength({ min: 2, max: 150 }).withMessage('Department name must be between 2 and 150 characters.'),
  body('code')
    .trim()
    .notEmpty().withMessage('Department code is required.')
    .isLength({ min: 2, max: 10 }).withMessage('Department code must be between 2 and 10 characters.')
    .matches(/^[A-Za-z0-9]+$/).withMessage('Department code must be alphanumeric.'),
  body('hod_name')
    .optional({ nullable: true })
    .trim()
    .isLength({ max: 150 }).withMessage('HoD name must not exceed 150 characters.'),
  body('established')
    .optional({ nullable: true })
    .isInt({ min: 1800, max: new Date().getFullYear() }).withMessage('Established year is invalid.'),
  body('intake')
    .optional({ nullable: true })
    .isInt({ min: 1, max: 2000 }).withMessage('Intake must be a positive number.'),
  body('nba_accredited')
    .optional({ nullable: true })
    .isBoolean().withMessage('nba_accredited must be a boolean.'),
  body('nba_valid_till')
    .optional({ nullable: true })
    .isISO8601().withMessage('nba_valid_till must be a valid date.'),
  body('description')
    .optional({ nullable: true })
    .trim()
    .isLength({ max: 1000 }).withMessage('Description must not exceed 1000 characters.'),
];

export const updateDepartmentValidator = [
  param('id').isUUID().withMessage('Invalid department id.'),
  body('name')
    .optional()
    .trim()
    .isLength({ min: 2, max: 150 }).withMessage('Department name must be between 2 and 150 characters.'),
  body('code')
    .optional()
    .trim()
    .isLength({ min: 2, max: 10 }).withMessage('Department code must be between 2 and 10 characters.')
    .matches(/^[A-Za-z0-9]+$/).withMessage('Department code must be alphanumeric.'),
  body('hod_name')
    .optional({ nullable: true })
    .trim()
    .isLength({ max: 150 }).withMessage('HoD name must not exceed 150 characters.'),
  body('established')
    .optional({ nullable: true })
    .isInt({ min: 1800, max: new Date().getFullYear() }).withMessage('Established year is invalid.'),
  body('intake')
    .optional({ nullable: true })
    .isInt({ min: 1, max: 2000 }).withMessage('Intake must be a positive number.'),
  body('nba_accredited')
    .optional({ nullable: true })
    .isBoolean().withMessage('nba_accredited must be a boolean.'),
  body('nba_valid_till')
    .optional({ nullable: true })
    .isISO8601().withMessage('nba_valid_till must be a valid date.'),
  body('description')
    .optional({ nullable: true })
    .trim()
    .isLength({ max: 1000 }).withMessage('Description must not exceed 1000 characters.'),
  body('is_active')
    .optional({ nullable: true })
    .isBoolean().withMessage('is_active must be a boolean.'),
];

export const departmentIdValidator = [
  param('id').isUUID().withMessage('Invalid department id.'),
];

export const listDepartmentsValidator = [
  query('page').optional().isInt({ min: 1 }).withMessage('page must be a positive integer.'),
  query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('limit must be between 1 and 100.'),
  query('search').optional().trim().isLength({ max: 100 }),
  query('is_active').optional().isBoolean(),
  query('nba_accredited').optional().isBoolean(),
];

export const deleteDepartmentValidator = [
  param('id').isUUID().withMessage('Invalid department id.'),
  query('hard').optional().isBoolean().withMessage('hard must be a boolean.'),
];
