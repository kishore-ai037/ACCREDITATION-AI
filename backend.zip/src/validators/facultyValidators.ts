import { body } from 'express-validator';

export const createFacultyValidator = [
  body('user_id').isUUID().withMessage('Valid user_id is required'),
];
