import { body } from 'express-validator';

export const createUserValidator = [
  body('email').isEmail().withMessage('A valid email is required'),
  body('password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters'),
  body('name').notEmpty().withMessage('Name is required'),
  body('role')
    .isIn(['admin', 'principal', 'iqac_coordinator', 'hod', 'faculty', 'student'])
    .withMessage('Invalid role'),
];
