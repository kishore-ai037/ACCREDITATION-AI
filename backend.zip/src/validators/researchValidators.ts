import { body } from 'express-validator';

export const createResearchValidator = [
  body('faculty_id').isUUID().withMessage('Valid faculty_id is required'),
  body('title').notEmpty().withMessage('Title is required'),
  body('type')
    .isIn(['journal', 'conference', 'book', 'book_chapter', 'patent', 'project', 'consultancy'])
    .withMessage('Invalid research type'),
];
