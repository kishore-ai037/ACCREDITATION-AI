import { body } from 'express-validator';

export const uploadDocumentValidator = [
  body('title').notEmpty().withMessage('Document title is required'),
];
