import path from 'path';
import fs from 'fs';
import { query, queryOne, queryMany } from '../config/database';
import { AppError } from '../middleware/errorHandler';
import { Request } from 'express';
import { parsePagination, buildPaginatedResponse } from '../utils/pagination';
import { DocStatus } from '../types';

export async function listDocuments(req: Request) {
  const instId = req.user!.institutionId;
  const { limit, offset, page } = parsePagination(req);
  const status     = req.query.status        as string | undefined;
  const criterion  = req.query.criterion_type as string | undefined;
  const criterionRef = req.query.criterion_ref as string | undefined;
  const deptId     = req.query.department_id  as string | undefined;
  const search     = req.query.search         as string | undefined;
  const aiMapped   = req.query.ai_mapped      as string | undefined;

  const conditions = ['d.institution_id = $1'];
  const params: unknown[] = [instId];
  let idx = 2;

  if (status)      { conditions.push(`d.status = $${idx++}::doc_status`);          params.push(status); }
  if (criterion)   { conditions.push(`d.criterion_type = $${idx++}::criterion_type`); params.push(criterion); }
  if (criterionRef){ conditions.push(`d.criterion_ref = $${idx++}`);                params.push(criterionRef); }
  if (deptId)      { conditions.push(`d.department_id = $${idx++}`);               params.push(deptId); }
  if (aiMapped !== undefined) { conditions.push(`d.ai_mapped = $${idx++}`);         params.push(aiMapped === 'true'); }
  if (search) {
    conditions.push(`(to_tsvector('english', d.title) @@ plainto_tsquery('english', $${idx}) OR d.title ILIKE $${idx + 1})`);
    params.push(search, `%${search}%`); idx += 2;
  }

  const where = conditions.join(' AND ');

  const [rows, countRes] = await Promise.all([
    queryMany<Record<string, unknown>>(`
      SELECT d.id, d.title, d.description, d.file_name, d.file_type, d.file_size,
             d.status, d.criterion_type, d.criterion_ref, d.tags, d.ai_tags,
             d.ai_mapped, d.ai_confidence, d.academic_year, d.version,
             d.rejection_note, d.review_note, d.created_at, d.updated_at,
             u.name AS uploaded_by_name, u.email AS uploaded_by_email,
             rv.name AS reviewed_by_name,
             dept.name AS department
      FROM documents d
      JOIN users u ON u.id = d.uploaded_by
      LEFT JOIN users rv ON rv.id = d.reviewed_by
      LEFT JOIN departments dept ON dept.id = d.department_id
      WHERE ${where}
      ORDER BY d.created_at DESC
      LIMIT $${idx} OFFSET $${idx + 1}
    `, [...params, limit, offset]),
    query<{ count: string }>(`SELECT COUNT(*) FROM documents d WHERE ${where}`, params),
  ]);

  return buildPaginatedResponse(rows, parseInt(countRes.rows[0].count, 10), { page, limit, offset });
}

export async function getDocumentById(id: string, institutionId: string) {
  const row = await queryOne<Record<string, unknown>>(`
    SELECT d.*,
           u.name AS uploaded_by_name, u.email AS uploaded_by_email,
           rv.name AS reviewed_by_name,
           dept.name AS department
    FROM documents d
    JOIN users u ON u.id = d.uploaded_by
    LEFT JOIN users rv ON rv.id = d.reviewed_by
    LEFT JOIN departments dept ON dept.id = d.department_id
    WHERE d.id = $1 AND d.institution_id = $2
  `, [id, institutionId]);

  if (!row) throw new AppError('Document not found', 404);
  return row;
}

export async function createDocument(
  file: Express.Multer.File,
  body: Record<string, unknown>,
  userId: string,
  institutionId: string
) {
  const tags = Array.isArray(body.tags)
    ? body.tags
    : (body.tags ? String(body.tags).split(',').map((t: string) => t.trim()) : []);

  const row = await queryOne<Record<string, unknown>>(`
    INSERT INTO documents (
      institution_id, department_id, uploaded_by, title, description,
      file_name, file_path, file_type, file_size, status,
      criterion_type, criterion_ref, tags, academic_year
    ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,'draft'::doc_status,$10,$11,$12,$13)
    RETURNING *
  `, [
    institutionId,
    body.department_id ?? null,
    userId,
    body.title,
    body.description ?? null,
    file.originalname,
    file.path,
    file.mimetype,
    file.size,
    body.criterion_type ?? null,
    body.criterion_ref ?? null,
    tags,
    body.academic_year ?? null,
  ]);
  return row;
}

export async function updateDocumentStatus(
  id: string,
  institutionId: string,
  status: DocStatus,
  reviewerId: string,
  note?: string
) {
  const doc = await queryOne<{ id: string; status: string }>(
    'SELECT id, status FROM documents WHERE id=$1 AND institution_id=$2',
    [id, institutionId]
  );
  if (!doc) throw new AppError('Document not found', 404);

  const row = await queryOne<Record<string, unknown>>(`
    UPDATE documents
    SET status=$1::doc_status, reviewed_by=$2,
        rejection_note = CASE WHEN $1='rejected' THEN $3 ELSE rejection_note END,
        review_note    = CASE WHEN $1!='rejected' THEN $3 ELSE review_note END
    WHERE id=$4
    RETURNING *
  `, [status, reviewerId, note ?? null, id]);
  return row;
}

export async function deleteDocument(id: string, institutionId: string, userId: string, role: string): Promise<void> {
  const doc = await queryOne<{ id: string; uploaded_by: string; file_path: string }>(
    'SELECT id, uploaded_by, file_path FROM documents WHERE id=$1 AND institution_id=$2',
    [id, institutionId]
  );
  if (!doc) throw new AppError('Document not found', 404);
  if (doc.uploaded_by !== userId && !['admin','iqac_coordinator'].includes(role)) {
    throw new AppError('Only the uploader or admin can delete this document', 403);
  }

  await query('DELETE FROM documents WHERE id=$1', [id]);

  // Clean up file
  try {
    if (fs.existsSync(doc.file_path)) fs.unlinkSync(doc.file_path);
  } catch { /* ignore FS errors */ }
}

export async function getDocumentStats(institutionId: string) {
  const row = await queryOne<Record<string, unknown>>(`
    SELECT
      COUNT(*)                                               AS total,
      COUNT(*) FILTER (WHERE status='draft')                AS draft,
      COUNT(*) FILTER (WHERE status='pending')              AS pending,
      COUNT(*) FILTER (WHERE status='approved')             AS approved,
      COUNT(*) FILTER (WHERE status='rejected')             AS rejected,
      COUNT(*) FILTER (WHERE ai_mapped=true)                AS ai_mapped,
      COALESCE(SUM(file_size),0)                            AS total_size_bytes,
      COUNT(*) FILTER (WHERE criterion_type='naac')         AS naac_docs,
      COUNT(*) FILTER (WHERE criterion_type='nba')          AS nba_docs,
      COUNT(*) FILTER (WHERE criterion_type='iqac')         AS iqac_docs
    FROM documents WHERE institution_id=$1
  `, [institutionId]);
  return row;
}

export async function searchDocuments(institutionId: string, q: string, criterionType?: string) {
  const conditions = ['d.institution_id = $1'];
  const params: unknown[] = [institutionId];
  let idx = 2;

  if (q) {
    conditions.push(`(to_tsvector('english', d.title || ' ' || COALESCE(d.description,'')) @@ plainto_tsquery('english', $${idx})
                      OR d.title ILIKE $${idx + 1} OR d.tags && ARRAY[$${idx + 2}]::text[])`);
    params.push(q, `%${q}%`, q); idx += 3;
  }
  if (criterionType) {
    conditions.push(`d.criterion_type = $${idx++}::criterion_type`);
    params.push(criterionType);
  }

  const rows = await queryMany<Record<string, unknown>>(`
    SELECT d.id, d.title, d.criterion_type, d.criterion_ref, d.status,
           d.ai_mapped, d.ai_confidence, d.tags, d.file_type, d.created_at,
           u.name AS uploaded_by_name
    FROM documents d
    JOIN users u ON u.id = d.uploaded_by
    WHERE ${conditions.join(' AND ')}
    ORDER BY d.created_at DESC
    LIMIT 50
  `, params);

  return rows;
}
