import { query, queryOne, queryMany } from '../config/database';
import { AppError } from '../middleware/errorHandler';
import { Request } from 'express';
import { parsePagination, buildPaginatedResponse } from '../utils/pagination';
import { AIAnalysisStatus } from '../types';
import { NAAC_KEYWORDS, NBA_KEYWORDS, suggestCriteria } from '../ai/evidenceClassifier';

// ─── Document evidence mapping ─────────────────────────────────────────────────

export async function runDocumentMapping(
  documentId: string,
  userId: string,
  institutionId: string
) {
  const doc = await queryOne<{ id: string; title: string; description: string | null; criterion_type: string | null }>(
    'SELECT id, title, description, criterion_type FROM documents WHERE id=$1 AND institution_id=$2',
    [documentId, institutionId]
  );
  if (!doc) throw new AppError('Document not found', 404);

  const analysisRow = await queryOne<Record<string, unknown>>(`
    INSERT INTO ai_analysis (institution_id, document_id, triggered_by, analysis_type, status, input_data, started_at)
    VALUES ($1,$2,$3,'document_evidence_mapping','running',$4,NOW())
    RETURNING *
  `, [institutionId, documentId, userId, JSON.stringify({ title: doc.title, description: doc.description })]);

  const analysisId = analysisRow!.id as string;

  try {
    const corpus = `${doc.title} ${doc.description ?? ''}`;
    const naacSuggestions = suggestCriteria(corpus, NAAC_KEYWORDS);
    const nbaSuggestions  = suggestCriteria(corpus, NBA_KEYWORDS);

    const topSuggestion = [...naacSuggestions, ...nbaSuggestions].sort((a, b) => b.confidence - a.confidence)[0];

    const allTags = [
      ...naacSuggestions.flatMap(s => s.matched_keywords),
      ...nbaSuggestions.flatMap(s => s.matched_keywords),
    ];
    const uniqueTags = Array.from(new Set(allTags)).slice(0, 10);

    const criteriaMapped = [
      ...naacSuggestions.map(s => `naac:${s.criterion_ref}`),
      ...nbaSuggestions.map(s => `nba:${s.criterion_ref}`),
    ];

    const result = {
      naac_suggestions: naacSuggestions,
      nba_suggestions: nbaSuggestions,
      recommended_tags: uniqueTags,
    };

    const updated = await queryOne<Record<string, unknown>>(`
      UPDATE ai_analysis
      SET status='completed', result=$1, suggestions=$2, confidence=$3, criteria_mapped=$4, completed_at=NOW()
      WHERE id=$5
      RETURNING *
    `, [
      JSON.stringify(result),
      JSON.stringify({ top_suggestion: topSuggestion ?? null }),
      topSuggestion?.confidence ?? 0,
      criteriaMapped,
      analysisId,
    ]);

    // Auto-tag the document with AI suggestions (does not overwrite human-set criterion)
    if (topSuggestion) {
      const [type, ref] = topSuggestion.criterion_ref.includes(':')
        ? topSuggestion.criterion_ref.split(':')
        : ['naac', topSuggestion.criterion_ref];

      await query(`
        UPDATE documents
        SET ai_mapped=true, ai_confidence=$1, ai_tags=$2,
            criterion_type = COALESCE(criterion_type, $3::criterion_type),
            criterion_ref  = COALESCE(criterion_ref, $4)
        WHERE id=$5
      `, [topSuggestion.confidence * 100, uniqueTags, type, ref, documentId]);
    } else {
      await query(`UPDATE documents SET ai_mapped=true, ai_tags=$1 WHERE id=$2`, [uniqueTags, documentId]);
    }

    return updated;
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown error during analysis';
    await query(
      `UPDATE ai_analysis SET status='failed', error_message=$1, completed_at=NOW() WHERE id=$2`,
      [message, analysisId]
    );
    throw new AppError('AI analysis failed: ' + message, 500);
  }
}

// ─── Bulk evidence search across un-mapped documents ───────────────────────────

export async function runBulkEvidenceSearch(
  userId: string,
  institutionId: string,
  criterionType: 'naac' | 'nba' = 'naac'
) {
  const unmapped = await queryMany<{ id: string; title: string; description: string | null }>(
    `SELECT id, title, description FROM documents
     WHERE institution_id=$1 AND ai_mapped=false
     ORDER BY created_at DESC LIMIT 50`,
    [institutionId]
  );

  const analysisRow = await queryOne<Record<string, unknown>>(`
    INSERT INTO ai_analysis (institution_id, triggered_by, analysis_type, status, input_data, started_at)
    VALUES ($1,$2,'bulk_evidence_search','running',$3,NOW())
    RETURNING *
  `, [institutionId, userId, JSON.stringify({ criterion_type: criterionType, candidate_count: unmapped.length })]);

  const analysisId = analysisRow!.id as string;
  const dictionary = criterionType === 'nba' ? NBA_KEYWORDS : NAAC_KEYWORDS;

  const matches: Array<{ document_id: string; title: string; criterion_ref: string; confidence: number }> = [];

  for (const doc of unmapped) {
    const corpus = `${doc.title} ${doc.description ?? ''}`;
    const suggestions = suggestCriteria(corpus, dictionary);
    if (suggestions.length > 0) {
      matches.push({
        document_id: doc.id,
        title: doc.title,
        criterion_ref: suggestions[0].criterion_ref,
        confidence: suggestions[0].confidence,
      });

      await query(`
        UPDATE documents
        SET ai_mapped=true, ai_confidence=$1,
            criterion_type = COALESCE(criterion_type, $2::criterion_type),
            criterion_ref  = COALESCE(criterion_ref, $3)
        WHERE id=$4
      `, [suggestions[0].confidence * 100, criterionType, suggestions[0].criterion_ref, doc.id]);
    }
  }

  const updated = await queryOne<Record<string, unknown>>(`
    UPDATE ai_analysis
    SET status='completed', result=$1, criteria_mapped=$2, completed_at=NOW()
    WHERE id=$3
    RETURNING *
  `, [
    JSON.stringify({ matches, scanned: unmapped.length, matched: matches.length }),
    matches.map(m => `${criterionType}:${m.criterion_ref}`),
    analysisId,
  ]);

  return updated;
}

// ─── Listing & retrieval ───────────────────────────────────────────────────────

export async function listAnalyses(req: Request) {
  const instId = req.user!.institutionId;
  const { limit, offset, page } = parsePagination(req);
  const status = req.query.status as string | undefined;
  const type   = req.query.analysis_type as string | undefined;

  const conditions = ['a.institution_id = $1'];
  const params: unknown[] = [instId];
  let idx = 2;

  if (status) { conditions.push(`a.status = $${idx++}::ai_analysis_status`); params.push(status); }
  if (type)   { conditions.push(`a.analysis_type = $${idx++}`);             params.push(type); }
  const where = conditions.join(' AND ');

  const [rows, countRes] = await Promise.all([
    queryMany<Record<string, unknown>>(`
      SELECT a.*, u.name AS triggered_by_name, d.title AS document_title
      FROM ai_analysis a
      JOIN users u ON u.id = a.triggered_by
      LEFT JOIN documents d ON d.id = a.document_id
      WHERE ${where}
      ORDER BY a.created_at DESC
      LIMIT $${idx} OFFSET $${idx + 1}
    `, [...params, limit, offset]),
    query<{ count: string }>(`SELECT COUNT(*) FROM ai_analysis a WHERE ${where}`, params),
  ]);

  return buildPaginatedResponse(rows, parseInt(countRes.rows[0].count, 10), { page, limit, offset });
}

export async function getAnalysisById(id: string, institutionId: string) {
  const row = await queryOne<Record<string, unknown>>(`
    SELECT a.*, u.name AS triggered_by_name, d.title AS document_title
    FROM ai_analysis a
    JOIN users u ON u.id = a.triggered_by
    LEFT JOIN documents d ON d.id = a.document_id
    WHERE a.id = $1 AND a.institution_id = $2
  `, [id, institutionId]);

  if (!row) throw new AppError('AI analysis job not found', 404);
  return row;
}

export async function getAnalysisStats(institutionId: string) {
  const row = await queryOne<Record<string, unknown>>(`
    SELECT
      COUNT(*)                                            AS total_jobs,
      COUNT(*) FILTER (WHERE status='completed')         AS completed,
      COUNT(*) FILTER (WHERE status='failed')             AS failed,
      COUNT(*) FILTER (WHERE status='running')            AS running,
      COALESCE(AVG(confidence) FILTER (WHERE confidence IS NOT NULL), 0)::NUMERIC(5,2) AS avg_confidence,
      (SELECT COUNT(*) FROM documents WHERE institution_id=$1 AND ai_mapped=true)  AS documents_ai_mapped,
      (SELECT COUNT(*) FROM documents WHERE institution_id=$1 AND ai_mapped=false) AS documents_unmapped
    FROM ai_analysis WHERE institution_id=$1
  `, [institutionId]);
  return row;
}

export function _statusEnumCheck(s: AIAnalysisStatus): AIAnalysisStatus {
  return s;
}
