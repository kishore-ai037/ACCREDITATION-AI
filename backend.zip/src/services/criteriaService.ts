import { query, queryOne, queryMany } from '../config/database';
import { AppError } from '../middleware/errorHandler';
import { Request } from 'express';
import { parsePagination, buildPaginatedResponse } from '../utils/pagination';

// ─── NAAC Criteria ─────────────────────────────────────────────────────────────

export async function listNaacCriteria(req: Request) {
  const instId = req.user!.institutionId;
  const { limit, offset, page } = parsePagination(req, 50);
  const cycleYear = req.query.cycle_year as string | undefined;

  const conditions = ['n.institution_id = $1'];
  const params: unknown[] = [instId];
  let idx = 2;

  if (cycleYear) { conditions.push(`n.cycle_year = $${idx++}`); params.push(cycleYear); }
  const where = conditions.join(' AND ');

  const [rows, countRes] = await Promise.all([
    queryMany<Record<string, unknown>>(`
      SELECT n.*, u.name AS responsible_name
      FROM naac_criteria n
      LEFT JOIN users u ON u.id = n.responsible_id
      WHERE ${where}
      ORDER BY n.criterion_no
      LIMIT $${idx} OFFSET $${idx + 1}
    `, [...params, limit, offset]),
    query<{ count: string }>(`SELECT COUNT(*) FROM naac_criteria n WHERE ${where}`, params),
  ]);

  return buildPaginatedResponse(rows, parseInt(countRes.rows[0].count, 10), { page, limit, offset });
}

export async function getNaacCriterionById(id: string, institutionId: string) {
  const row = await queryOne<Record<string, unknown>>(`
    SELECT n.*, u.name AS responsible_name
    FROM naac_criteria n
    LEFT JOIN users u ON u.id = n.responsible_id
    WHERE n.id = $1 AND n.institution_id = $2
  `, [id, institutionId]);

  if (!row) throw new AppError('NAAC criterion not found', 404);
  return row;
}

export async function createNaacCriterion(body: Record<string, unknown>, institutionId: string) {
  const row = await queryOne<Record<string, unknown>>(`
    INSERT INTO naac_criteria (institution_id, criterion_no, criterion_name, sub_criteria, description, max_score, current_score, completion_pct, cycle_year, responsible_id, due_date, notes)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
    RETURNING *
  `, [
    institutionId, body.criterion_no, body.criterion_name, body.sub_criteria ?? null,
    body.description ?? null, body.max_score ?? 100, body.current_score ?? 0,
    body.completion_pct ?? 0, body.cycle_year ?? null, body.responsible_id ?? null,
    body.due_date ?? null, body.notes ?? null,
  ]);
  return row;
}

export async function updateNaacCriterion(id: string, institutionId: string, body: Record<string, unknown>) {
  const allowed = ['criterion_name','sub_criteria','description','max_score','current_score','completion_pct','cycle_year','responsible_id','due_date','notes'];
  const fields: string[] = [];
  const params: unknown[] = [];
  let idx = 1;

  for (const key of allowed) {
    if (body[key] !== undefined) { fields.push(`${key}=$${idx++}`); params.push(body[key]); }
  }
  if (fields.length === 0) throw new AppError('No fields to update', 400);

  params.push(id, institutionId);
  const row = await queryOne<Record<string, unknown>>(`
    UPDATE naac_criteria SET ${fields.join(',')} WHERE id=$${idx} AND institution_id=$${idx + 1} RETURNING *
  `, params);
  if (!row) throw new AppError('NAAC criterion not found', 404);
  return row;
}

export async function deleteNaacCriterion(id: string, institutionId: string): Promise<void> {
  const res = await query('DELETE FROM naac_criteria WHERE id=$1 AND institution_id=$2', [id, institutionId]);
  if ((res.rowCount ?? 0) === 0) throw new AppError('NAAC criterion not found', 404);
}

export async function getNaacOverview(institutionId: string) {
  const rows = await queryMany<Record<string, unknown>>(`
    SELECT criterion_no, criterion_name, max_score, current_score, completion_pct, cycle_year, due_date
    FROM naac_criteria
    WHERE institution_id = $1
    ORDER BY criterion_no
  `, [institutionId]);

  const aggregate = await queryOne<Record<string, unknown>>(`
    SELECT
      COUNT(*)                                              AS total_criteria,
      COALESCE(AVG(completion_pct), 0)::NUMERIC(5,2)        AS overall_completion,
      COALESCE(SUM(current_score), 0)                        AS total_score,
      COALESCE(SUM(max_score), 0)                             AS max_possible_score,
      COUNT(*) FILTER (WHERE completion_pct >= 80)          AS criteria_above_80,
      COUNT(*) FILTER (WHERE completion_pct < 50)           AS criteria_below_50
    FROM naac_criteria WHERE institution_id = $1
  `, [institutionId]);

  return { criteria: rows, aggregate };
}

// ─── NBA / OBE Criteria ────────────────────────────────────────────────────────

export async function listNbaCriteria(req: Request) {
  const instId = req.user!.institutionId;
  const { limit, offset, page } = parsePagination(req, 50);
  const deptId    = req.query.department_id as string | undefined;
  const cycleYear = req.query.cycle_year    as string | undefined;

  const conditions = ['d.institution_id = $1'];
  const params: unknown[] = [instId];
  let idx = 2;

  if (deptId)    { conditions.push(`n.department_id = $${idx++}`); params.push(deptId); }
  if (cycleYear) { conditions.push(`n.cycle_year = $${idx++}`);    params.push(cycleYear); }
  const where = conditions.join(' AND ');

  const [rows, countRes] = await Promise.all([
    queryMany<Record<string, unknown>>(`
      SELECT n.*, d.name AS department, d.code AS department_code
      FROM nba_criteria n
      JOIN departments d ON d.id = n.department_id
      WHERE ${where}
      ORDER BY n.criterion_no
      LIMIT $${idx} OFFSET $${idx + 1}
    `, [...params, limit, offset]),
    query<{ count: string }>(`
      SELECT COUNT(*) FROM nba_criteria n JOIN departments d ON d.id=n.department_id WHERE ${where}
    `, params),
  ]);

  return buildPaginatedResponse(rows, parseInt(countRes.rows[0].count, 10), { page, limit, offset });
}

export async function getNbaCriterionById(id: string, institutionId: string) {
  const row = await queryOne<Record<string, unknown>>(`
    SELECT n.*, d.name AS department, d.code AS department_code
    FROM nba_criteria n
    JOIN departments d ON d.id = n.department_id
    WHERE n.id = $1 AND d.institution_id = $2
  `, [id, institutionId]);

  if (!row) throw new AppError('NBA criterion not found', 404);
  return row;
}

export async function createNbaCriterion(body: Record<string, unknown>, institutionId: string) {
  const dept = await queryOne<{ id: string }>(
    'SELECT id FROM departments WHERE id = $1 AND institution_id = $2',
    [body.department_id, institutionId]
  );
  if (!dept) throw new AppError('Department not found', 404);

  const row = await queryOne<Record<string, unknown>>(`
    INSERT INTO nba_criteria (department_id, criterion_no, criterion_name, max_marks, obtained_marks, completion_pct, cycle_year, tier, notes)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
    RETURNING *
  `, [
    body.department_id, body.criterion_no, body.criterion_name,
    body.max_marks ?? null, body.obtained_marks ?? 0, body.completion_pct ?? 0,
    body.cycle_year ?? null, body.tier ?? 1, body.notes ?? null,
  ]);
  return row;
}

export async function updateNbaCriterion(id: string, institutionId: string, body: Record<string, unknown>) {
  const check = await queryOne<{ id: string }>(
    `SELECT n.id FROM nba_criteria n JOIN departments d ON d.id=n.department_id
     WHERE n.id=$1 AND d.institution_id=$2`,
    [id, institutionId]
  );
  if (!check) throw new AppError('NBA criterion not found', 404);

  const allowed = ['criterion_name','max_marks','obtained_marks','completion_pct','cycle_year','tier','notes'];
  const fields: string[] = [];
  const params: unknown[] = [];
  let idx = 1;

  for (const key of allowed) {
    if (body[key] !== undefined) { fields.push(`${key}=$${idx++}`); params.push(body[key]); }
  }
  if (fields.length === 0) throw new AppError('No fields to update', 400);

  params.push(id);
  const row = await queryOne<Record<string, unknown>>(
    `UPDATE nba_criteria SET ${fields.join(',')} WHERE id=$${idx} RETURNING *`,
    params
  );
  return row;
}

export async function deleteNbaCriterion(id: string, institutionId: string): Promise<void> {
  const check = await queryOne<{ id: string }>(
    `SELECT n.id FROM nba_criteria n JOIN departments d ON d.id=n.department_id
     WHERE n.id=$1 AND d.institution_id=$2`,
    [id, institutionId]
  );
  if (!check) throw new AppError('NBA criterion not found', 404);
  await query('DELETE FROM nba_criteria WHERE id=$1', [id]);
}

export async function getNbaOverviewByDept(institutionId: string, departmentId?: string) {
  const conditions = ['d.institution_id = $1'];
  const params: unknown[] = [institutionId];

  if (departmentId) {
    conditions.push('n.department_id = $2');
    params.push(departmentId);
  }

  const rows = await queryMany<Record<string, unknown>>(`
    SELECT
      d.name AS department,
      d.code AS department_code,
      COUNT(n.id)                                          AS total_criteria,
      COALESCE(AVG(n.completion_pct), 0)::NUMERIC(5,2)    AS avg_completion,
      COALESCE(SUM(n.obtained_marks), 0)                    AS total_obtained,
      COALESCE(SUM(n.max_marks), 0)                          AS total_max
    FROM departments d
    LEFT JOIN nba_criteria n ON n.department_id = d.id
    WHERE ${conditions.join(' AND ')}
    GROUP BY d.id, d.name, d.code
    ORDER BY d.name
  `, params);

  return rows;
}
