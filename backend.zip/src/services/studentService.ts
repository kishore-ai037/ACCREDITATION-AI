import { query, queryOne, queryMany } from '../config/database';
import { AppError } from '../middleware/errorHandler';
import { Request } from 'express';
import { parsePagination, buildPaginatedResponse } from '../utils/pagination';

export async function listStudents(req: Request) {
  const instId = req.user!.institutionId;
  const { limit, offset, page } = parsePagination(req);
  const deptId    = req.query.department_id as string | undefined;
  const batchYear = req.query.batch_year    as string | undefined;
  const search    = req.query.search        as string | undefined;
  const active    = req.query.active        as string | undefined;

  const conditions = ['s.institution_id = $1'];
  const params: unknown[] = [instId];
  let idx = 2;

  if (deptId)    { conditions.push(`s.department_id = $${idx++}`);      params.push(deptId); }
  if (batchYear) { conditions.push(`s.batch_year = $${idx++}`);         params.push(parseInt(batchYear, 10)); }
  if (active !== undefined) { conditions.push(`s.active = $${idx++}`);  params.push(active === 'true'); }
  if (search)    { conditions.push(`(s.name ILIKE $${idx} OR s.roll_number ILIKE $${idx} OR s.email ILIKE $${idx})`); params.push(`%${search}%`); idx++; }

  const where = conditions.join(' AND ');

  const [rows, countRes] = await Promise.all([
    queryMany<Record<string, unknown>>(`
      SELECT s.*, d.name AS department, d.code AS department_code
      FROM students s
      JOIN departments d ON d.id = s.department_id
      WHERE ${where}
      ORDER BY s.batch_year DESC, s.roll_number
      LIMIT $${idx} OFFSET $${idx + 1}
    `, [...params, limit, offset]),
    query<{ count: string }>(`SELECT COUNT(*) FROM students s WHERE ${where}`, params),
  ]);

  return buildPaginatedResponse(rows, parseInt(countRes.rows[0].count, 10), { page, limit, offset });
}

export async function getStudentById(id: string, institutionId: string) {
  const row = await queryOne<Record<string, unknown>>(`
    SELECT s.*, d.name AS department, d.code AS department_code,
           p.status AS placement_status, p.company_name, p.package_lpa, p.job_role
    FROM students s
    JOIN departments d ON d.id = s.department_id
    LEFT JOIN placements p ON p.student_id = s.id
    WHERE s.id = $1 AND s.institution_id = $2
  `, [id, institutionId]);

  if (!row) throw new AppError('Student not found', 404);
  return row;
}

export async function createStudent(body: Record<string, unknown>, institutionId: string) {
  const deptCheck = await queryOne(
    'SELECT id FROM departments WHERE id=$1 AND institution_id=$2',
    [body.department_id, institutionId]
  );
  if (!deptCheck) throw new AppError('Department not found', 404);

  const row = await queryOne<Record<string, unknown>>(`
    INSERT INTO students (
      institution_id, department_id, roll_number, name, email, phone,
      gender, date_of_birth, batch_year, year_of_study, semester,
      section, lateral_entry, category, cgpa, arrear_count, active
    ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17)
    RETURNING *
  `, [
    institutionId, body.department_id, body.roll_number, body.name,
    body.email ?? null, body.phone ?? null, body.gender ?? null,
    body.date_of_birth ?? null, body.batch_year, body.year_of_study ?? null,
    body.semester ?? null, body.section ?? null, body.lateral_entry ?? false,
    body.category ?? null, body.cgpa ?? null, body.arrear_count ?? 0, true,
  ]);
  return row;
}

export async function updateStudent(id: string, institutionId: string, body: Record<string, unknown>) {
  const allowed = [
    'name','email','phone','gender','date_of_birth','year_of_study','semester',
    'section','cgpa','arrear_count','active','category','lateral_entry',
  ];

  const fields: string[] = [];
  const params: unknown[] = [];
  let idx = 1;
  for (const key of allowed) {
    if (body[key] !== undefined) { fields.push(`${key}=$${idx++}`); params.push(body[key]); }
  }
  if (fields.length === 0) throw new AppError('No fields to update', 400);

  params.push(id, institutionId);
  const row = await queryOne<Record<string, unknown>>(`
    UPDATE students SET ${fields.join(',')} WHERE id=$${idx} AND institution_id=$${idx + 1} RETURNING *
  `, params);
  if (!row) throw new AppError('Student not found', 404);
  return row;
}

export async function deleteStudent(id: string, institutionId: string): Promise<void> {
  const res = await query('DELETE FROM students WHERE id=$1 AND institution_id=$2', [id, institutionId]);
  if ((res.rowCount ?? 0) === 0) throw new AppError('Student not found', 404);
}

export async function getStudentStats(institutionId: string) {
  const row = await queryOne<Record<string, unknown>>(`
    SELECT
      COUNT(*)                                       AS total_students,
      COUNT(*) FILTER (WHERE active=true)            AS active_students,
      COUNT(DISTINCT batch_year)                     AS total_batches,
      COUNT(*) FILTER (WHERE lateral_entry=true)     AS lateral_entries,
      COALESCE(AVG(cgpa) FILTER (WHERE cgpa IS NOT NULL), 0)::NUMERIC(4,2) AS avg_cgpa,
      COUNT(*) FILTER (WHERE arrear_count > 0)       AS students_with_arrears,
      COUNT(*) FILTER (WHERE gender='female')        AS female_students,
      COUNT(*) FILTER (WHERE gender='male')          AS male_students,
      (SELECT COUNT(*) FROM placements p
        JOIN students s2 ON s2.id = p.student_id
        WHERE s2.institution_id=$1 AND p.status='placed') AS total_placed
    FROM students WHERE institution_id=$1
  `, [institutionId]);
  return row;
}
