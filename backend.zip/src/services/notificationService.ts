import { query, queryOne, queryMany } from '../config/database';
import { AppError } from '../middleware/errorHandler';
import { Request } from 'express';
import { parsePagination, buildPaginatedResponse } from '../utils/pagination';
import { NotifType } from '../types';

export async function listNotifications(req: Request) {
  const userId = req.user!.userId;
  const { limit, offset, page } = parsePagination(req);
  const unreadOnly = req.query.unread === 'true';

  const conditions = ['user_id = $1'];
  const params: unknown[] = [userId];
  let idx = 2;

  if (unreadOnly) { conditions.push(`read = false`); }
  const where = conditions.join(' AND ');

  const [rows, countRes] = await Promise.all([
    queryMany<Record<string, unknown>>(`
      SELECT * FROM notifications WHERE ${where}
      ORDER BY created_at DESC
      LIMIT $${idx} OFFSET $${idx + 1}
    `, [...params, limit, offset]),
    query<{ count: string }>(`SELECT COUNT(*) FROM notifications WHERE ${where}`, params),
  ]);

  return buildPaginatedResponse(rows, parseInt(countRes.rows[0].count, 10), { page, limit, offset });
}

export async function getUnreadCount(userId: string): Promise<number> {
  const row = await queryOne<{ count: string }>(
    'SELECT COUNT(*) AS count FROM notifications WHERE user_id=$1 AND read=false',
    [userId]
  );
  return parseInt(row?.count ?? '0', 10);
}

export async function createNotification(
  userId: string,
  title: string,
  message: string,
  type: NotifType = NotifType.INFO,
  link?: string,
  metadata?: Record<string, unknown>
) {
  const row = await queryOne<Record<string, unknown>>(`
    INSERT INTO notifications (user_id, title, message, type, link, metadata)
    VALUES ($1,$2,$3,$4::notif_type,$5,$6)
    RETURNING *
  `, [userId, title, message, type, link ?? null, JSON.stringify(metadata ?? {})]);
  return row;
}

export async function markAsRead(id: string, userId: string) {
  const row = await queryOne<Record<string, unknown>>(
    'UPDATE notifications SET read=true WHERE id=$1 AND user_id=$2 RETURNING *',
    [id, userId]
  );
  if (!row) throw new AppError('Notification not found', 404);
  return row;
}

export async function markAllAsRead(userId: string): Promise<number> {
  const res = await query('UPDATE notifications SET read=true WHERE user_id=$1 AND read=false', [userId]);
  return res.rowCount ?? 0;
}

export async function deleteNotification(id: string, userId: string): Promise<void> {
  const res = await query('DELETE FROM notifications WHERE id=$1 AND user_id=$2', [id, userId]);
  if ((res.rowCount ?? 0) === 0) throw new AppError('Notification not found', 404);
}
