import bcrypt from 'bcryptjs';
import { query, queryOne } from '../config/database';
import { signAccessToken, signRefreshToken, verifyRefreshToken } from '../utils/jwt';
import { AppError } from '../middleware/errorHandler';
import { UserRole, AuthPayload } from '../types';

interface LoginResult {
  user: {
    id: string;
    name: string;
    email: string;
    role: string;
    designation: string | null;
    department_id: string | null;
    institution_id: string;
    institution: string;
    avatar_url: string | null;
  };
  accessToken: string;
  refreshToken: string;
}

export async function login(email: string, password: string): Promise<LoginResult> {
  const user = await queryOne<{
    id: string; name: string; email: string; role: string;
    password_hash: string; is_active: boolean; designation: string | null;
    department_id: string | null; institution_id: string; institution_name: string;
    avatar_url: string | null;
  }>(`
    SELECT u.id, u.name, u.email, u.role, u.password_hash, u.is_active,
           u.designation, u.department_id, u.institution_id, u.avatar_url,
           i.name AS institution_name
    FROM users u
    JOIN institutions i ON i.id = u.institution_id
    WHERE LOWER(u.email) = LOWER($1)
  `, [email]);

  if (!user) throw new AppError('Invalid email or password', 401);
  if (!user.is_active) throw new AppError('Account is disabled. Contact administrator.', 403);

  const valid = await bcrypt.compare(password, user.password_hash);
  if (!valid) throw new AppError('Invalid email or password', 401);

  const payload: AuthPayload = {
    userId: user.id,
    institutionId: user.institution_id,
    role: user.role as UserRole,
    email: user.email,
  };

  const accessToken  = signAccessToken(payload);
  const refreshToken = signRefreshToken(payload);

  // Persist refresh token hash and update last_login
  const tokenHash = await bcrypt.hash(refreshToken, 8);
  await query(
    'UPDATE users SET refresh_token=$1, last_login=NOW() WHERE id=$2',
    [tokenHash, user.id]
  );

  return {
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      designation: user.designation,
      department_id: user.department_id,
      institution_id: user.institution_id,
      institution: user.institution_name,
      avatar_url: user.avatar_url,
    },
    accessToken,
    refreshToken,
  };
}

export async function refreshTokens(token: string): Promise<{ accessToken: string; refreshToken: string }> {
  let payload: AuthPayload;
  try {
    payload = verifyRefreshToken(token);
  } catch {
    throw new AppError('Invalid or expired refresh token', 401);
  }

  const user = await queryOne<{ id: string; refresh_token: string | null; is_active: boolean }>(
    'SELECT id, refresh_token, is_active FROM users WHERE id=$1',
    [payload.userId]
  );

  if (!user || !user.is_active) throw new AppError('User not found or inactive', 401);
  if (!user.refresh_token) throw new AppError('Session expired — please log in again', 401);

  const match = await bcrypt.compare(token, user.refresh_token);
  if (!match) throw new AppError('Refresh token mismatch', 401);

  const newAccess  = signAccessToken(payload);
  const newRefresh = signRefreshToken(payload);
  const newHash    = await bcrypt.hash(newRefresh, 8);

  await query('UPDATE users SET refresh_token=$1 WHERE id=$2', [newHash, user.id]);

  return { accessToken: newAccess, refreshToken: newRefresh };
}

export async function logout(userId: string): Promise<void> {
  await query('UPDATE users SET refresh_token=NULL WHERE id=$1', [userId]);
}

export async function getProfile(userId: string) {
  const row = await queryOne<Record<string, unknown>>(`
    SELECT u.id, u.name, u.email, u.role, u.phone, u.avatar_url, u.employee_id,
           u.designation, u.is_active, u.last_login, u.created_at,
           u.institution_id, i.name AS institution,
           u.department_id, d.name AS department, d.code AS department_code
    FROM users u
    JOIN institutions i ON i.id = u.institution_id
    LEFT JOIN departments d ON d.id = u.department_id
    WHERE u.id = $1
  `, [userId]);

  if (!row) throw new AppError('User not found', 404);
  return row;
}

export async function changePassword(userId: string, currentPw: string, newPw: string): Promise<void> {
  const user = await queryOne<{ password_hash: string }>(
    'SELECT password_hash FROM users WHERE id=$1', [userId]
  );
  if (!user) throw new AppError('User not found', 404);

  const valid = await bcrypt.compare(currentPw, user.password_hash);
  if (!valid) throw new AppError('Current password is incorrect', 400);

  const hash = await bcrypt.hash(newPw, 12);
  await query('UPDATE users SET password_hash=$1, refresh_token=NULL WHERE id=$2', [hash, userId]);
}
