import { query, queryOne, queryMany } from '../config/database';
import { AppError } from '../middleware/errorHandler';
import { Request } from 'express';
import { parsePagination, buildPaginatedResponse } from '../utils/pagination';

export async function listDepartments(req: Request) {
  const instId = req.user!.institutionId;
  const { limit, offset, page } = parsePagination(req, 50);
  const search = req.query.search as string | undefined;

  const conditions = ['d.institution_id = $1'];
  const params: unknown[] = [instId];
  let idx = 2;

  if (search) {
    conditions.push(`(d.name ILIKE $${idx} OR d.code ILIKE $${idx})`);
    params.push(`%${search}%`); idx++;
  }
  const where = conditions.join(' AND ');

  const [rows, countRes] = await Promise.all([
    queryMany<Record<string, unknown>>(`
      SELECT d.*,
             (SELECT COUNT(*) FROM faculty f WHERE f.department_id = d.id) AS faculty_count,
             (SELECT COUNT(*) FROM students s WHERE s.department_id = d.id AND s.active) AS student_count
      FROM departments d
      WHERE ${where}
      ORDER BY d.name
      LIMIT $${idx} OFFSET $${idx + 1}
    `, [...params, limit, offset]),
    query<{ count: string }>(`SELECT COUNT(*) FROM departments d WHERE ${where}`, params),
  ]);

  return buildPaginatedResponse(rows, parseInt(countRes.rows[0].count, 10), { page, limit, offset });
}

export async function getDepartmentById(id: string, institutionId: string) {
  const row = await queryOne<Record<string, unknown>>(`
    SELECT d.*,
           (SELECT COUNT(*) FROM faculty f WHERE f.department_id = d.id) AS faculty_count,
           (SELECT COUNT(*) FROM students s WHERE s.department_id = d.id AND s.active) AS student_count,
           (SELECT COUNT(*) FROM documents doc WHERE doc.department_id = d.id) AS document_count
    FROM departments d
    WHERE d.id = $1 AND d.institution_id = $2
  `, [id, institutionId]);

  if (!row) throw new AppError('Department not found', 404);
  return row;
}

export async function createDepartment(body: {
  name: string; code: string; hod_name?: string; established?: number;
  intake?: number; nba_accredited?: boolean; nba_valid_till?: string; description?: string;
}, institutionId: string) {
  const row = await queryOne<Record<string, unknown>>(`
    INSERT INTO departments (institution_id, name, code, hod_name, established, intake, nba_accredited, nba_valid_till, description)
    VALUES ($1,$2,UPPER($3),$4,$5,$6,$7,$8,$9)
    RETURNING *
  `, [
    institutionId, body.name, body.code, body.hod_name ?? null,
    body.established ?? null, body.intake ?? 60,
    body.nba_accredited ?? false, body.nba_valid_till ?? null, body.description ?? null,
  ]);
  return row;
}

export async function updateDepartment(id: string, institutionId: string, body: Record<string, unknown>) {
  const allowed = ['name','code','hod_name','established','intake','nba_accredited','nba_valid_till','description'];
  const fields: string[] = [];
  const params: unknown[] = [];
  let idx = 1;

  for (const key of allowed) {
    if (body[key] !== undefined) {
      fields.push(`${key}=$${idx++}`);
      params.push(key === 'code' ? String(body[key]).toUpperCase() : body[key]);
    }
  }
  if (fields.length === 0) throw new AppError('No fields to update', 400);

  params.push(id, institutionId);
  const row = await queryOne<Record<string, unknown>>(`
    UPDATE departments SET ${fields.join(',')} WHERE id=$${idx} AND institution_id=$${idx + 1}
    RETURNING *
  `, params);

  if (!row) throw new AppError('Department not found', 404);
  return row;
}

export async function deleteDepartment(id: string, institutionId: string): Promise<void> {
  const check = await queryOne<{ count: string }>(
    'SELECT COUNT(*) AS count FROM users WHERE department_id=$1', [id]
  );
  if (parseInt(check?.count ?? '0', 10) > 0) {
    throw new AppError('Cannot delete department with existing users. Reassign users first.', 409);
  }
  const res = await query(
    'DELETE FROM departments WHERE id=$1 AND institution_id=$2', [id, institutionId]
  );
  if ((res.rowCount ?? 0) === 0) throw new AppError('Department not found', 404);
}
