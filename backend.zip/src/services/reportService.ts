import fs from 'fs';
import path from 'path';
import { query, queryOne, queryMany } from '../config/database';
import { AppError } from '../middleware/errorHandler';
import { Request } from 'express';
import { parsePagination, buildPaginatedResponse } from '../utils/pagination';
import config from '../config';
import { ReportType } from '../types';

export async function listReports(req: Request) {
  const instId = req.user!.institutionId;
  const { limit, offset, page } = parsePagination(req);
  const type = req.query.type as string | undefined;
  const year = req.query.academic_year as string | undefined;

  const conditions = ['r.institution_id = $1'];
  const params: unknown[] = [instId];
  let idx = 2;

  if (type) { conditions.push(`r.type = $${idx++}::report_type`); params.push(type); }
  if (year) { conditions.push(`r.academic_year = $${idx++}`);     params.push(year); }
  const where = conditions.join(' AND ');

  const [rows, countRes] = await Promise.all([
    queryMany<Record<string, unknown>>(`
      SELECT r.*, u.name AS generated_by_name
      FROM reports r
      JOIN users u ON u.id = r.generated_by
      WHERE ${where}
      ORDER BY r.created_at DESC
      LIMIT $${idx} OFFSET $${idx + 1}
    `, [...params, limit, offset]),
    query<{ count: string }>(`SELECT COUNT(*) FROM reports r WHERE ${where}`, params),
  ]);

  return buildPaginatedResponse(rows, parseInt(countRes.rows[0].count, 10), { page, limit, offset });
}

export async function getReportById(id: string, institutionId: string) {
  const row = await queryOne<Record<string, unknown>>(`
    SELECT r.*, u.name AS generated_by_name
    FROM reports r
    JOIN users u ON u.id = r.generated_by
    WHERE r.id = $1 AND r.institution_id = $2
  `, [id, institutionId]);

  if (!row) throw new AppError('Report not found', 404);
  return row;
}

/**
 * Builds the underlying dataset for a report type by querying the
 * relevant domain tables, then persists a JSON snapshot file to disk
 * and records the report metadata.
 */
export async function generateReport(
  body: { title: string; type: ReportType; academic_year?: string; description?: string; parameters?: Record<string, unknown> },
  userId: string,
  institutionId: string
) {
  const reportRow = await queryOne<Record<string, unknown>>(`
    INSERT INTO reports (institution_id, generated_by, title, type, academic_year, description, parameters, status)
    VALUES ($1,$2,$3,$4::report_type,$5,$6,$7,'generating')
    RETURNING *
  `, [
    institutionId, userId, body.title, body.type,
    body.academic_year ?? null, body.description ?? null,
    JSON.stringify(body.parameters ?? {}),
  ]);

  const reportId = reportRow!.id as string;

  try {
    const data = await buildReportDataset(body.type, institutionId, body.academic_year);

    const reportsDir = path.join(config.upload.dir, 'reports');
    if (!fs.existsSync(reportsDir)) fs.mkdirSync(reportsDir, { recursive: true });

    const fileName = `${body.type}_${reportId}.json`;
    const filePath = path.join(reportsDir, fileName);
    const payload = JSON.stringify({ report: reportRow, generatedAt: new Date().toISOString(), data }, null, 2);
    fs.writeFileSync(filePath, payload, 'utf-8');

    const fileSize = Buffer.byteLength(payload, 'utf-8');

    const updated = await queryOne<Record<string, unknown>>(`
      UPDATE reports SET status='completed', file_path=$1, file_size=$2, generated_at=NOW()
      WHERE id=$3 RETURNING *
    `, [filePath, fileSize, reportId]);

    return updated;
  } catch (err) {
    await query(`UPDATE reports SET status='failed' WHERE id=$1`, [reportId]);
    throw err;
  }
}

async function buildReportDataset(
  type: ReportType,
  institutionId: string,
  academicYear?: string
): Promise<Record<string, unknown>> {
  switch (type) {
    case ReportType.NAAC_SSR:
    case ReportType.NAAC_IQAR: {
      const criteria = await queryMany(`
        SELECT criterion_no, criterion_name, max_score, current_score, completion_pct, cycle_year
        FROM naac_criteria WHERE institution_id = $1 ${academicYear ? 'AND cycle_year = $2' : ''}
        ORDER BY criterion_no
      `, academicYear ? [institutionId, academicYear] : [institutionId]);

      const docs = await queryMany(`
        SELECT criterion_ref, COUNT(*) AS document_count
        FROM documents WHERE institution_id=$1 AND criterion_type='naac' AND status='approved'
        GROUP BY criterion_ref
      `, [institutionId]);

      return { criteria, supporting_documents: docs };
    }

    case ReportType.NBA_SAR: {
      const criteria = await queryMany(`
        SELECT d.name AS department, n.criterion_no, n.criterion_name, n.max_marks, n.obtained_marks, n.completion_pct
        FROM nba_criteria n JOIN departments d ON d.id = n.department_id
        WHERE d.institution_id = $1 ${academicYear ? 'AND n.cycle_year = $2' : ''}
        ORDER BY d.name, n.criterion_no
      `, academicYear ? [institutionId, academicYear] : [institutionId]);

      return { criteria };
    }

    case ReportType.IQAC_AQAR: {
      const meetings = await queryMany(`
        SELECT title, meeting_date, venue, action_points
        FROM iqac_meetings WHERE institution_id = $1
        ORDER BY meeting_date DESC LIMIT 20
      `, [institutionId]);

      const actionPlans = await queryMany(`
        SELECT title, status, completion_pct, target_date, priority
        FROM iqac_action_plans WHERE institution_id = $1
        ${academicYear ? 'AND academic_year = $2' : ''}
        ORDER BY priority DESC
      `, academicYear ? [institutionId, academicYear] : [institutionId]);

      return { meetings, action_plans: actionPlans };
    }

    case ReportType.CUSTOM:
    default: {
      const docStats = await queryOne(`
        SELECT COUNT(*) AS total_documents,
               COUNT(*) FILTER (WHERE status='approved') AS approved
        FROM documents WHERE institution_id = $1
      `, [institutionId]);

      const facultyStats = await queryOne(`
        SELECT COUNT(*) AS total_faculty, COALESCE(SUM(publications_count),0) AS total_publications
        FROM faculty f JOIN users u ON u.id = f.user_id WHERE u.institution_id = $1
      `, [institutionId]);

      const studentStats = await queryOne(`
        SELECT COUNT(*) AS total_students FROM students WHERE institution_id = $1
      `, [institutionId]);

      return { documents: docStats, faculty: facultyStats, students: studentStats };
    }
  }
}

export async function deleteReport(id: string, institutionId: string): Promise<void> {
  const report = await queryOne<{ file_path: string | null }>(
    'SELECT file_path FROM reports WHERE id=$1 AND institution_id=$2',
    [id, institutionId]
  );
  if (!report) throw new AppError('Report not found', 404);

  await query('DELETE FROM reports WHERE id=$1', [id]);

  if (report.file_path && fs.existsSync(report.file_path)) {
    try { fs.unlinkSync(report.file_path); } catch { /* ignore */ }
  }
}
