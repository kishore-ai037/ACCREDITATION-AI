import { query, queryOne, queryMany } from '../config/database';
import { AppError } from '../middleware/errorHandler';
import { Request } from 'express';
import { parsePagination, buildPaginatedResponse } from '../utils/pagination';

export async function listPlacements(req: Request) {
  const instId = req.user!.institutionId;
  const { limit, offset, page } = parsePagination(req);
  const deptId    = req.query.department_id as string | undefined;
  const batchYear = req.query.batch_year    as string | undefined;
  const status    = req.query.status        as string | undefined;
  const search    = req.query.search        as string | undefined;

  const conditions = ['s.institution_id = $1'];
  const params: unknown[] = [instId];
  let idx = 2;

  if (deptId)    { conditions.push(`s.department_id = $${idx++}`);           params.push(deptId); }
  if (batchYear) { conditions.push(`p.batch_year = $${idx++}`);              params.push(parseInt(batchYear, 10)); }
  if (status)    { conditions.push(`p.status = $${idx++}::placement_status`); params.push(status); }
  if (search) {
    conditions.push(`(s.name ILIKE $${idx} OR s.roll_number ILIKE $${idx} OR p.company_name ILIKE $${idx})`);
    params.push(`%${search}%`); idx++;
  }

  const where = conditions.join(' AND ');

  const [rows, countRes] = await Promise.all([
    queryMany<Record<string, unknown>>(`
      SELECT p.*,
             s.name        AS student_name,
             s.roll_number,
             s.email       AS student_email,
             s.cgpa,
             d.name        AS department,
             d.code        AS department_code
      FROM placements p
      JOIN students s    ON s.id = p.student_id
      JOIN departments d ON d.id = s.department_id
      WHERE ${where}
      ORDER BY p.batch_year DESC, s.name
      LIMIT $${idx} OFFSET $${idx + 1}
    `, [...params, limit, offset]),
    query<{ count: string }>(`
      SELECT COUNT(*) FROM placements p
      JOIN students s ON s.id = p.student_id
      WHERE ${where}
    `, params),
  ]);

  return buildPaginatedResponse(rows, parseInt(countRes.rows[0].count, 10), { page, limit, offset });
}

export async function getPlacementById(id: string, institutionId: string) {
  const row = await queryOne<Record<string, unknown>>(`
    SELECT p.*,
           s.name AS student_name, s.roll_number, s.email AS student_email, s.cgpa,
           d.name AS department, d.code AS department_code
    FROM placements p
    JOIN students s    ON s.id = p.student_id
    JOIN departments d ON d.id = s.department_id
    WHERE p.id = $1 AND s.institution_id = $2
  `, [id, institutionId]);

  if (!row) throw new AppError('Placement record not found', 404);
  return row;
}

export async function upsertPlacement(
  studentId: string,
  body: Record<string, unknown>,
  institutionId: string
) {
  // Validate student belongs to institution
  const student = await queryOne<{ id: string; batch_year: number }>(
    'SELECT id, batch_year FROM students WHERE id = $1 AND institution_id = $2',
    [studentId, institutionId]
  );
  if (!student) throw new AppError('Student not found', 404);

  const batchYear = (body.batch_year as number) ?? student.batch_year;

  // Check for existing placement record for this student
  const existing = await queryOne<{ id: string }>(
    'SELECT id FROM placements WHERE student_id = $1',
    [studentId]
  );

  if (existing) {
    // Update
    const allowed = ['status','company_name','package_lpa','offer_date','joining_date','job_role','placement_type','higher_studies','batch_year'];
    const fields: string[] = [];
    const params: unknown[] = [];
    let idx = 1;

    for (const key of allowed) {
      if (body[key] !== undefined) {
        const suffix = key === 'status' ? '::placement_status' : '';
        fields.push(`${key}=$${idx++}${suffix}`);
        params.push(body[key]);
      }
    }
    if (fields.length === 0) throw new AppError('No fields to update', 400);

    params.push(existing.id);
    const row = await queryOne<Record<string, unknown>>(
      `UPDATE placements SET ${fields.join(',')} WHERE id=$${idx} RETURNING *`,
      params
    );
    return row;
  } else {
    // Insert
    const row = await queryOne<Record<string, unknown>>(`
      INSERT INTO placements (student_id, batch_year, status, company_name, package_lpa, offer_date, joining_date, job_role, placement_type, higher_studies)
      VALUES ($1,$2,$3::placement_status,$4,$5,$6,$7,$8,$9,$10)
      RETURNING *
    `, [
      studentId, batchYear,
      body.status ?? 'not_placed',
      body.company_name ?? null,
      body.package_lpa ?? null,
      body.offer_date ?? null,
      body.joining_date ?? null,
      body.job_role ?? null,
      body.placement_type ?? null,
      body.higher_studies ?? null,
    ]);
    return row;
  }
}

export async function deletePlacement(id: string, institutionId: string): Promise<void> {
  const check = await queryOne<{ id: string }>(
    `SELECT p.id FROM placements p JOIN students s ON s.id = p.student_id
     WHERE p.id = $1 AND s.institution_id = $2`,
    [id, institutionId]
  );
  if (!check) throw new AppError('Placement record not found', 404);
  await query('DELETE FROM placements WHERE id = $1', [id]);
}

export async function getPlacementStats(institutionId: string, batchYear?: number) {
  const conditions = ['s.institution_id = $1'];
  const params: unknown[] = [institutionId];

  if (batchYear) {
    conditions.push(`p.batch_year = $2`);
    params.push(batchYear);
  }

  const where = conditions.join(' AND ');

  const summary = await queryOne<Record<string, unknown>>(`
    SELECT
      COUNT(*)                                                    AS total_students,
      COUNT(*) FILTER (WHERE p.status = 'placed')                AS placed,
      COUNT(*) FILTER (WHERE p.status = 'not_placed')            AS not_placed,
      COUNT(*) FILTER (WHERE p.status = 'higher_studies')        AS higher_studies,
      COUNT(*) FILTER (WHERE p.status = 'entrepreneur')          AS entrepreneur,
      ROUND(COUNT(*) FILTER (WHERE p.status='placed')::numeric /
        NULLIF(COUNT(*),0) * 100, 2)                             AS placement_percentage,
      COALESCE(AVG(p.package_lpa) FILTER (WHERE p.status='placed'), 0)::NUMERIC(6,2) AS avg_package_lpa,
      COALESCE(MAX(p.package_lpa), 0)                            AS highest_package_lpa,
      COALESCE(MIN(p.package_lpa) FILTER (WHERE p.status='placed'), 0) AS lowest_package_lpa,
      COUNT(DISTINCT p.company_name) FILTER (WHERE p.status='placed') AS unique_companies
    FROM students s
    LEFT JOIN placements p ON p.student_id = s.id
    WHERE ${where}
  `, params);

  const byDept = await queryMany<Record<string, unknown>>(`
    SELECT
      d.name AS department,
      d.code,
      COUNT(*)                                           AS total,
      COUNT(*) FILTER (WHERE p.status='placed')         AS placed,
      ROUND(COUNT(*) FILTER (WHERE p.status='placed')::numeric / NULLIF(COUNT(*),0)*100,2) AS pct,
      COALESCE(AVG(p.package_lpa) FILTER (WHERE p.status='placed'), 0)::NUMERIC(6,2) AS avg_pkg
    FROM students s
    JOIN departments d ON d.id = s.department_id
    LEFT JOIN placements p ON p.student_id = s.id
    WHERE ${where}
    GROUP BY d.id, d.name, d.code
    ORDER BY pct DESC
  `, params);

  const topRecruiters = await queryMany<Record<string, unknown>>(`
    SELECT
      p.company_name,
      COUNT(*)                                        AS hires,
      COALESCE(AVG(p.package_lpa),0)::NUMERIC(6,2)   AS avg_package,
      MAX(p.package_lpa)                              AS max_package
    FROM placements p
    JOIN students s ON s.id = p.student_id
    WHERE s.institution_id = $1 AND p.status = 'placed' AND p.company_name IS NOT NULL
    ${batchYear ? 'AND p.batch_year = $2' : ''}
    GROUP BY p.company_name
    ORDER BY hires DESC
    LIMIT 10
  `, batchYear ? [institutionId, batchYear] : [institutionId]);

  return { summary, by_department: byDept, top_recruiters: topRecruiters };
}

export async function getPlacementTrend(institutionId: string) {
  const rows = await queryMany<Record<string, unknown>>(`
    SELECT
      p.batch_year,
      COUNT(*)                                           AS total,
      COUNT(*) FILTER (WHERE p.status='placed')         AS placed,
      ROUND(COUNT(*) FILTER (WHERE p.status='placed')::numeric / NULLIF(COUNT(*),0)*100,2) AS placement_pct,
      COALESCE(AVG(p.package_lpa) FILTER (WHERE p.status='placed'), 0)::NUMERIC(6,2) AS avg_package
    FROM placements p
    JOIN students s ON s.id = p.student_id
    WHERE s.institution_id = $1
    GROUP BY p.batch_year
    ORDER BY p.batch_year DESC
    LIMIT 6
  `, [institutionId]);
  return rows;
}
