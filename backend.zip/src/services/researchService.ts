import { query, queryOne, queryMany } from '../config/database';
import { AppError } from '../middleware/errorHandler';
import { Request } from 'express';
import { parsePagination, buildPaginatedResponse } from '../utils/pagination';

export async function listResearch(req: Request) {
  const instId = req.user!.institutionId;
  const { limit, offset, page } = parsePagination(req);
  const type      = req.query.type        as string | undefined;
  const facultyId = req.query.faculty_id  as string | undefined;
  const year      = req.query.year        as string | undefined;
  const search    = req.query.search      as string | undefined;
  const verified  = req.query.verified    as string | undefined;

  const conditions = ['u.institution_id = $1'];
  const params: unknown[] = [instId];
  let idx = 2;

  if (type)      { conditions.push(`r.type = $${idx++}::research_type`); params.push(type); }
  if (facultyId) { conditions.push(`r.faculty_id = $${idx++}`);          params.push(facultyId); }
  if (year)      { conditions.push(`r.year = $${idx++}`);                params.push(parseInt(year, 10)); }
  if (verified !== undefined) { conditions.push(`r.verified = $${idx++}`); params.push(verified === 'true'); }
  if (search)    {
    conditions.push(`(r.title ILIKE $${idx} OR r.journal_name ILIKE $${idx} OR r.doi ILIKE $${idx})`);
    params.push(`%${search}%`); idx++;
  }

  const where = conditions.join(' AND ');

  const [rows, countRes] = await Promise.all([
    queryMany<Record<string, unknown>>(`
      SELECT r.*,
             u.name  AS faculty_name,
             u.email AS faculty_email,
             d.name  AS department,
             d.code  AS department_code,
             vu.name AS verified_by_name
      FROM research r
      JOIN faculty f  ON f.id  = r.faculty_id
      JOIN users u    ON u.id  = f.user_id
      JOIN departments d ON d.id = f.department_id
      LEFT JOIN users vu ON vu.id = r.verified_by
      WHERE ${where}
      ORDER BY r.year DESC NULLS LAST, r.created_at DESC
      LIMIT $${idx} OFFSET $${idx + 1}
    `, [...params, limit, offset]),
    query<{ count: string }>(`
      SELECT COUNT(*) FROM research r
      JOIN faculty f ON f.id = r.faculty_id
      JOIN users u   ON u.id = f.user_id
      WHERE ${where}
    `, params),
  ]);

  return buildPaginatedResponse(rows, parseInt(countRes.rows[0].count, 10), { page, limit, offset });
}

export async function getResearchById(id: string, institutionId: string) {
  const row = await queryOne<Record<string, unknown>>(`
    SELECT r.*,
           u.name  AS faculty_name,
           u.email AS faculty_email,
           d.name  AS department,
           vu.name AS verified_by_name
    FROM research r
    JOIN faculty f  ON f.id  = r.faculty_id
    JOIN users u    ON u.id  = f.user_id
    JOIN departments d ON d.id = f.department_id
    LEFT JOIN users vu ON vu.id = r.verified_by
    WHERE r.id = $1 AND u.institution_id = $2
  `, [id, institutionId]);

  if (!row) throw new AppError('Research record not found', 404);
  return row;
}

export async function createResearch(body: Record<string, unknown>, institutionId: string) {
  // Verify faculty belongs to institution
  const faculty = await queryOne<{ id: string }>(
    `SELECT f.id FROM faculty f JOIN users u ON u.id = f.user_id
     WHERE f.id = $1 AND u.institution_id = $2`,
    [body.faculty_id, institutionId]
  );
  if (!faculty) throw new AppError('Faculty not found in this institution', 404);

  const keywords   = Array.isArray(body.keywords)  ? body.keywords  : (body.keywords  ? String(body.keywords).split(',').map((k: string) => k.trim())  : null);
  const co_authors = Array.isArray(body.co_authors) ? body.co_authors : (body.co_authors ? String(body.co_authors).split(',').map((a: string) => a.trim()) : null);

  const row = await queryOne<Record<string, unknown>>(`
    INSERT INTO research (
      faculty_id, title, type, journal_name, publisher, doi, isbn_issn,
      year, volume, issue, pages, impact_factor, scopus_indexed, wos_indexed,
      ugc_listed, funding_agency, funding_amount, abstract, keywords,
      co_authors, document_url
    ) VALUES ($1,$2,$3::research_type,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21)
    RETURNING *
  `, [
    body.faculty_id, body.title, body.type,
    body.journal_name ?? null, body.publisher ?? null,
    body.doi ?? null, body.isbn_issn ?? null,
    body.year ?? null, body.volume ?? null, body.issue ?? null, body.pages ?? null,
    body.impact_factor ?? null,
    body.scopus_indexed ?? false, body.wos_indexed ?? false, body.ugc_listed ?? false,
    body.funding_agency ?? null, body.funding_amount ?? null,
    body.abstract ?? null, keywords, co_authors,
    body.document_url ?? null,
  ]);

  // Update faculty publication count
  await query(
    'UPDATE faculty SET publications_count = publications_count + 1 WHERE id = $1',
    [body.faculty_id]
  );

  return row;
}

export async function updateResearch(id: string, institutionId: string, body: Record<string, unknown>) {
  const check = await queryOne<{ id: string }>(
    `SELECT r.id FROM research r JOIN faculty f ON f.id = r.faculty_id
     JOIN users u ON u.id = f.user_id WHERE r.id = $1 AND u.institution_id = $2`,
    [id, institutionId]
  );
  if (!check) throw new AppError('Research record not found', 404);

  const allowed = [
    'title','type','journal_name','publisher','doi','isbn_issn','year',
    'volume','issue','pages','impact_factor','scopus_indexed','wos_indexed',
    'ugc_listed','funding_agency','funding_amount','abstract','keywords',
    'co_authors','document_url',
  ];

  const fields: string[] = [];
  const params: unknown[] = [];
  let idx = 1;

  for (const key of allowed) {
    if (body[key] !== undefined) {
      const suffix = key === 'type' ? '::research_type' : '';
      fields.push(`${key}=$${idx++}${suffix}`);
      params.push(body[key]);
    }
  }
  if (fields.length === 0) throw new AppError('No fields to update', 400);

  params.push(id);
  const row = await queryOne<Record<string, unknown>>(
    `UPDATE research SET ${fields.join(',')} WHERE id=$${idx} RETURNING *`,
    params
  );
  return row;
}

export async function verifyResearch(id: string, institutionId: string, verifierId: string) {
  const check = await queryOne<{ id: string }>(
    `SELECT r.id FROM research r JOIN faculty f ON f.id = r.faculty_id
     JOIN users u ON u.id = f.user_id WHERE r.id = $1 AND u.institution_id = $2`,
    [id, institutionId]
  );
  if (!check) throw new AppError('Research record not found', 404);

  const row = await queryOne<Record<string, unknown>>(
    `UPDATE research SET verified = true, verified_by = $1 WHERE id = $2 RETURNING *`,
    [verifierId, id]
  );
  return row;
}

export async function deleteResearch(id: string, institutionId: string): Promise<void> {
  const row = await queryOne<{ faculty_id: string }>(
    `SELECT r.faculty_id FROM research r JOIN faculty f ON f.id = r.faculty_id
     JOIN users u ON u.id = f.user_id WHERE r.id = $1 AND u.institution_id = $2`,
    [id, institutionId]
  );
  if (!row) throw new AppError('Research record not found', 404);

  await query('DELETE FROM research WHERE id = $1', [id]);

  // Decrement faculty publication count (floor at 0)
  await query(
    `UPDATE faculty SET publications_count = GREATEST(publications_count - 1, 0) WHERE id = $1`,
    [row.faculty_id]
  );
}

export async function getResearchStats(institutionId: string) {
  const row = await queryOne<Record<string, unknown>>(`
    SELECT
      COUNT(r.id)                                                   AS total,
      COUNT(*) FILTER (WHERE r.type = 'journal')                    AS journals,
      COUNT(*) FILTER (WHERE r.type = 'conference')                 AS conferences,
      COUNT(*) FILTER (WHERE r.type = 'patent')                     AS patents,
      COUNT(*) FILTER (WHERE r.type = 'book' OR r.type = 'book_chapter') AS books,
      COUNT(*) FILTER (WHERE r.scopus_indexed = true)               AS scopus_indexed,
      COUNT(*) FILTER (WHERE r.wos_indexed = true)                  AS wos_indexed,
      COUNT(*) FILTER (WHERE r.ugc_listed = true)                   AS ugc_listed,
      COUNT(*) FILTER (WHERE r.verified = true)                     AS verified,
      COALESCE(AVG(r.impact_factor) FILTER (WHERE r.impact_factor IS NOT NULL), 0)::NUMERIC(5,3) AS avg_impact_factor,
      COALESCE(SUM(r.funding_amount), 0)                            AS total_funding_amount,
      COUNT(DISTINCT r.year)                                        AS years_covered
    FROM research r
    JOIN faculty f ON f.id = r.faculty_id
    JOIN users u   ON u.id = f.user_id
    WHERE u.institution_id = $1
  `, [institutionId]);
  return row;
}
