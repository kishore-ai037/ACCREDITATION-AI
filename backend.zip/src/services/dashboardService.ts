import { queryOne, queryMany } from '../config/database';

export async function getDashboardSummary(institutionId: string) {
  const [institution, docStats, naacAvg, facultyStats, studentStats, pendingCount] = await Promise.all([
    queryOne<Record<string, unknown>>(
      'SELECT name, code, naac_grade, naac_score, nba_status FROM institutions WHERE id=$1',
      [institutionId]
    ),
    queryOne<Record<string, unknown>>(`
      SELECT COUNT(*) AS total, COUNT(*) FILTER (WHERE status='approved') AS approved
      FROM documents WHERE institution_id=$1
    `, [institutionId]),
    queryOne<{ avg_completion: string }>(`
      SELECT COALESCE(AVG(completion_pct),0)::NUMERIC(5,2) AS avg_completion
      FROM naac_criteria WHERE institution_id=$1
    `, [institutionId]),
    queryOne<Record<string, unknown>>(`
      SELECT COUNT(*) AS total FROM faculty f JOIN users u ON u.id=f.user_id WHERE u.institution_id=$1
    `, [institutionId]),
    queryOne<Record<string, unknown>>(
      'SELECT COUNT(*) AS total FROM students WHERE institution_id=$1 AND active=true',
      [institutionId]
    ),
    queryOne<{ count: string }>(
      `SELECT COUNT(*) AS count FROM documents WHERE institution_id=$1 AND status='pending'`,
      [institutionId]
    ),
  ]);

  return {
    institution,
    naac_score: institution?.naac_score ?? null,
    naac_completion_pct: naacAvg?.avg_completion ?? 0,
    documents: docStats,
    faculty_count: facultyStats?.total ?? 0,
    student_count: studentStats?.total ?? 0,
    pending_reviews: parseInt(pendingCount?.count ?? '0', 10),
  };
}

export async function getRecentActivity(institutionId: string, limit = 10) {
  const rows = await queryMany<Record<string, unknown>>(`
    SELECT id, user_name, action, entity_type, entity_title, description, created_at
    FROM activity_log
    WHERE institution_id = $1
    ORDER BY created_at DESC
    LIMIT $2
  `, [institutionId, limit]);
  return rows;
}

export async function getDocumentTrend(institutionId: string, months = 6) {
  const rows = await queryMany<Record<string, unknown>>(`
    SELECT
      TO_CHAR(date_trunc('month', created_at), 'Mon')  AS month,
      COUNT(*)                                          AS uploaded,
      COUNT(*) FILTER (WHERE status IN ('approved','rejected')) AS reviewed
    FROM documents
    WHERE institution_id = $1
      AND created_at >= NOW() - INTERVAL '1 month' * $2
    GROUP BY date_trunc('month', created_at)
    ORDER BY date_trunc('month', created_at)
  `, [institutionId, months]);
  return rows;
}
