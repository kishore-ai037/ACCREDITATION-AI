import bcrypt from 'bcryptjs';
import { query, queryOne, queryMany } from '../config/database';
import { AppError } from '../middleware/errorHandler';
import { parsePagination, buildPaginatedResponse } from '../utils/pagination';
import { Request } from 'express';
import { UserRole } from '../types';

export async function listUsers(req: Request) {
  const { limit, offset, page } = parsePagination(req);
  const instId  = req.user!.institutionId;
  const roleFilter = req.query.role   as string | undefined;
  const deptFilter = req.query.dept   as string | undefined;
  const search     = req.query.search as string | undefined;

  const conditions: string[] = ['u.institution_id = $1'];
  const params: unknown[]    = [instId];
  let idx = 2;

  if (roleFilter) { conditions.push(`u.role = $${idx++}::user_role`); params.push(roleFilter); }
  if (deptFilter) { conditions.push(`u.department_id = $${idx++}`);    params.push(deptFilter); }
  if (search) {
    conditions.push(`(u.name ILIKE $${idx} OR u.email ILIKE $${idx})`);
    params.push(`%${search}%`); idx++;
  }

  const where = conditions.join(' AND ');

  const [rows, countRes] = await Promise.all([
    queryMany<Record<string, unknown>>(`
      SELECT u.id, u.name, u.email, u.role, u.phone, u.avatar_url,
             u.designation, u.employee_id, u.is_active, u.last_login, u.created_at,
             d.name AS department, d.code AS department_code
      FROM users u
      LEFT JOIN departments d ON d.id = u.department_id
      WHERE ${where}
      ORDER BY u.name
      LIMIT $${idx} OFFSET $${idx + 1}
    `, [...params, limit, offset]),
    query<{ count: string }>(`SELECT COUNT(*) AS count FROM users u WHERE ${where}`, params),
  ]);

  return buildPaginatedResponse(rows, parseInt(countRes.rows[0].count, 10), { page, limit, offset });
}

export async function getUserById(id: string, institutionId: string) {
  const row = await queryOne<Record<string, unknown>>(`
    SELECT u.id, u.name, u.email, u.role, u.phone, u.avatar_url,
           u.designation, u.employee_id, u.is_active, u.last_login, u.created_at, u.updated_at,
           u.department_id, d.name AS department, d.code AS department_code,
           u.institution_id, i.name AS institution
    FROM users u
    LEFT JOIN departments d ON d.id = u.department_id
    JOIN institutions i ON i.id = u.institution_id
    WHERE u.id = $1 AND u.institution_id = $2
  `, [id, institutionId]);

  if (!row) throw new AppError('User not found', 404);
  return row;
}

export async function createUser(body: {
  email: string; password: string; name: string; role: UserRole;
  phone?: string; designation?: string; employee_id?: string;
  department_id?: string;
}, institutionId: string) {
  const existing = await queryOne('SELECT id FROM users WHERE LOWER(email)=LOWER($1)', [body.email]);
  if (existing) throw new AppError('Email already registered', 409);

  const hash = await bcrypt.hash(body.password, 12);

  const row = await queryOne<Record<string, unknown>>(`
    INSERT INTO users (institution_id, department_id, email, password_hash, name, role, phone, designation, employee_id)
    VALUES ($1,$2,$3,$4,$5,$6::user_role,$7,$8,$9)
    RETURNING id, name, email, role, designation, employee_id, is_active, created_at
  `, [
    institutionId, body.department_id ?? null, body.email, hash,
    body.name, body.role, body.phone ?? null, body.designation ?? null, body.employee_id ?? null,
  ]);

  return row;
}

export async function updateUser(
  id: string,
  institutionId: string,
  body: Partial<{ name: string; phone: string; designation: string; employee_id: string; avatar_url: string; department_id: string; is_active: boolean; role: UserRole }>
) {
  // Build dynamic SET clause
  const fields: string[] = [];
  const params: unknown[] = [];
  let idx = 1;

  if (body.name        !== undefined) { fields.push(`name=$${idx++}`);          params.push(body.name); }
  if (body.phone       !== undefined) { fields.push(`phone=$${idx++}`);         params.push(body.phone); }
  if (body.designation !== undefined) { fields.push(`designation=$${idx++}`);   params.push(body.designation); }
  if (body.employee_id !== undefined) { fields.push(`employee_id=$${idx++}`);   params.push(body.employee_id); }
  if (body.avatar_url  !== undefined) { fields.push(`avatar_url=$${idx++}`);    params.push(body.avatar_url); }
  if (body.department_id !== undefined) { fields.push(`department_id=$${idx++}`); params.push(body.department_id); }
  if (body.is_active   !== undefined) { fields.push(`is_active=$${idx++}`);     params.push(body.is_active); }
  if (body.role        !== undefined) { fields.push(`role=$${idx++}::user_role`); params.push(body.role); }

  if (fields.length === 0) throw new AppError('No fields to update', 400);

  params.push(id, institutionId);
  const row = await queryOne<Record<string, unknown>>(`
    UPDATE users SET ${fields.join(',')} WHERE id=$${idx} AND institution_id=$${idx + 1}
    RETURNING id, name, email, role, designation, is_active, updated_at
  `, params);

  if (!row) throw new AppError('User not found', 404);
  return row;
}

export async function deleteUser(id: string, institutionId: string, requesterId: string): Promise<void> {
  if (id === requesterId) throw new AppError('Cannot delete your own account', 400);

  const res = await query(
    'DELETE FROM users WHERE id=$1 AND institution_id=$2',
    [id, institutionId]
  );
  if ((res.rowCount ?? 0) === 0) throw new AppError('User not found', 404);
}
