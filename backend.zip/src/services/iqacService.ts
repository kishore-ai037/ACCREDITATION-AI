import { query, queryOne, queryMany } from '../config/database';
import { AppError } from '../middleware/errorHandler';
import { Request } from 'express';
import { parsePagination, buildPaginatedResponse } from '../utils/pagination';

// ─── Meetings ──────────────────────────────────────────────────────────────────

export async function listMeetings(req: Request) {
  const instId = req.user!.institutionId;
  const { limit, offset, page } = parsePagination(req);
  const year = req.query.year as string | undefined;

  const conditions = ['m.institution_id = $1'];
  const params: unknown[] = [instId];
  let idx = 2;

  if (year) {
    conditions.push(`EXTRACT(YEAR FROM m.meeting_date)=$${idx++}`);
    params.push(parseInt(year, 10));
  }
  const where = conditions.join(' AND ');

  const [rows, countRes] = await Promise.all([
    queryMany<Record<string, unknown>>(`
      SELECT m.*, u.name AS created_by_name
      FROM iqac_meetings m
      JOIN users u ON u.id = m.created_by
      WHERE ${where}
      ORDER BY m.meeting_date DESC
      LIMIT $${idx} OFFSET $${idx + 1}
    `, [...params, limit, offset]),
    query<{ count: string }>(`SELECT COUNT(*) FROM iqac_meetings m WHERE ${where}`, params),
  ]);

  return buildPaginatedResponse(rows, parseInt(countRes.rows[0].count, 10), { page, limit, offset });
}

export async function getMeetingById(id: string, institutionId: string) {
  const row = await queryOne<Record<string, unknown>>(`
    SELECT m.*, u.name AS created_by_name
    FROM iqac_meetings m
    JOIN users u ON u.id = m.created_by
    WHERE m.id = $1 AND m.institution_id = $2
  `, [id, institutionId]);

  if (!row) throw new AppError('IQAC meeting not found', 404);
  return row;
}

export async function createMeeting(body: Record<string, unknown>, userId: string, institutionId: string) {
  const row = await queryOne<Record<string, unknown>>(`
    INSERT INTO iqac_meetings (institution_id, title, meeting_date, venue, agenda, minutes, action_points, attendees, document_url, created_by)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
    RETURNING *
  `, [
    institutionId, body.title, body.meeting_date, body.venue ?? null,
    body.agenda ?? null, body.minutes ?? null,
    JSON.stringify(body.action_points ?? []),
    body.attendees ?? '{}',
    body.document_url ?? null,
    userId,
  ]);
  return row;
}

export async function updateMeeting(id: string, institutionId: string, body: Record<string, unknown>) {
  const allowed = ['title','meeting_date','venue','agenda','minutes','action_points','attendees','document_url'];
  const fields: string[] = [];
  const params: unknown[] = [];
  let idx = 1;

  for (const key of allowed) {
    if (body[key] !== undefined) {
      const val = (key === 'action_points') ? JSON.stringify(body[key]) : body[key];
      fields.push(`${key}=$${idx++}`);
      params.push(val);
    }
  }
  if (fields.length === 0) throw new AppError('No fields to update', 400);

  params.push(id, institutionId);
  const row = await queryOne<Record<string, unknown>>(`
    UPDATE iqac_meetings SET ${fields.join(',')} WHERE id=$${idx} AND institution_id=$${idx + 1} RETURNING *
  `, params);
  if (!row) throw new AppError('Meeting not found', 404);
  return row;
}

export async function deleteMeeting(id: string, institutionId: string): Promise<void> {
  const res = await query('DELETE FROM iqac_meetings WHERE id=$1 AND institution_id=$2', [id, institutionId]);
  if ((res.rowCount ?? 0) === 0) throw new AppError('Meeting not found', 404);
}

// ─── Action Plans ──────────────────────────────────────────────────────────────

export async function listActionPlans(req: Request) {
  const instId = req.user!.institutionId;
  const { limit, offset, page } = parsePagination(req);
  const status = req.query.status as string | undefined;
  const year   = req.query.academic_year as string | undefined;

  const conditions = ['ap.institution_id = $1'];
  const params: unknown[] = [instId];
  let idx = 2;

  if (status) { conditions.push(`ap.status=$${idx++}`);         params.push(status); }
  if (year)   { conditions.push(`ap.academic_year=$${idx++}`);  params.push(year); }

  const where = conditions.join(' AND ');

  const [rows, countRes] = await Promise.all([
    queryMany<Record<string, unknown>>(`
      SELECT ap.*, u.name AS responsible_name
      FROM iqac_action_plans ap
      LEFT JOIN users u ON u.id = ap.responsible_id
      WHERE ${where}
      ORDER BY ap.priority DESC, ap.target_date ASC
      LIMIT $${idx} OFFSET $${idx + 1}
    `, [...params, limit, offset]),
    query<{ count: string }>(`SELECT COUNT(*) FROM iqac_action_plans ap WHERE ${where}`, params),
  ]);

  return buildPaginatedResponse(rows, parseInt(countRes.rows[0].count, 10), { page, limit, offset });
}

export async function createActionPlan(body: Record<string, unknown>, institutionId: string) {
  const row = await queryOne<Record<string, unknown>>(`
    INSERT INTO iqac_action_plans (institution_id, title, description, target_date, responsible_id, status, academic_year, priority, remarks)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
    RETURNING *
  `, [
    institutionId, body.title, body.description ?? null, body.target_date ?? null,
    body.responsible_id ?? null, body.status ?? 'planned', body.academic_year ?? null,
    body.priority ?? 'medium', body.remarks ?? null,
  ]);
  return row;
}

export async function updateActionPlan(id: string, institutionId: string, body: Record<string, unknown>) {
  const allowed = ['title','description','target_date','responsible_id','status','completion_pct','academic_year','priority','remarks'];
  const fields: string[] = [];
  const params: unknown[] = [];
  let idx = 1;

  for (const key of allowed) {
    if (body[key] !== undefined) { fields.push(`${key}=$${idx++}`); params.push(body[key]); }
  }
  if (fields.length === 0) throw new AppError('No fields to update', 400);

  params.push(id, institutionId);
  const row = await queryOne<Record<string, unknown>>(`
    UPDATE iqac_action_plans SET ${fields.join(',')} WHERE id=$${idx} AND institution_id=$${idx + 1} RETURNING *
  `, params);
  if (!row) throw new AppError('Action plan not found', 404);
  return row;
}

export async function deleteActionPlan(id: string, institutionId: string): Promise<void> {
  const res = await query('DELETE FROM iqac_action_plans WHERE id=$1 AND institution_id=$2', [id, institutionId]);
  if ((res.rowCount ?? 0) === 0) throw new AppError('Action plan not found', 404);
}
