import { query, queryOne, queryMany } from '../config/database';
import { AppError } from '../middleware/errorHandler';
import { Request } from 'express';
import { parsePagination, buildPaginatedResponse } from '../utils/pagination';

const FACULTY_SELECT = `
  f.id, f.user_id, f.department_id, f.employee_code, f.gender, f.date_of_birth,
  f.date_of_joining, f.employment_type, f.qualification, f.specialization,
  f.experience_years, f.industry_exp_years, f.ugc_net, f.gate_score,
  f.phd_guide, f.phd_students_count, f.funded_projects, f.publications_count,
  f.patents_count, f.awards_count, f.fdp_attended, f.fdp_organized,
  f.orcid_id, f.scopus_id, f.google_scholar_url, f.profile_url,
  f.created_at, f.updated_at,
  u.name, u.email, u.phone, u.designation, u.avatar_url, u.employee_id,
  d.name AS department, d.code AS department_code
`;

export async function listFaculty(req: Request) {
  const instId = req.user!.institutionId;
  const { limit, offset, page } = parsePagination(req);
  const deptId = req.query.department_id as string | undefined;
  const search = req.query.search as string | undefined;
  const empType = req.query.employment_type as string | undefined;

  const conditions = ['u.institution_id = $1'];
  const params: unknown[] = [instId];
  let idx = 2;

  if (deptId)  { conditions.push(`f.department_id = $${idx++}`);    params.push(deptId); }
  if (empType) { conditions.push(`f.employment_type = $${idx++}::employment_type`); params.push(empType); }
  if (search)  { conditions.push(`(u.name ILIKE $${idx} OR u.email ILIKE $${idx} OR f.employee_code ILIKE $${idx})`); params.push(`%${search}%`); idx++; }

  const where = conditions.join(' AND ');

  const [rows, countRes] = await Promise.all([
    queryMany<Record<string, unknown>>(`
      SELECT ${FACULTY_SELECT}
      FROM faculty f
      JOIN users u ON u.id = f.user_id
      JOIN departments d ON d.id = f.department_id
      WHERE ${where}
      ORDER BY u.name
      LIMIT $${idx} OFFSET $${idx + 1}
    `, [...params, limit, offset]),
    query<{ count: string }>(`
      SELECT COUNT(*) FROM faculty f JOIN users u ON u.id=f.user_id WHERE ${where}
    `, params),
  ]);

  return buildPaginatedResponse(rows, parseInt(countRes.rows[0].count, 10), { page, limit, offset });
}

export async function getFacultyById(id: string, institutionId: string) {
  const row = await queryOne<Record<string, unknown>>(`
    SELECT ${FACULTY_SELECT},
           (SELECT json_agg(r ORDER BY r.year DESC) FROM research r WHERE r.faculty_id = f.id) AS publications
    FROM faculty f
    JOIN users u ON u.id = f.user_id
    JOIN departments d ON d.id = f.department_id
    WHERE f.id = $1 AND u.institution_id = $2
  `, [id, institutionId]);

  if (!row) throw new AppError('Faculty not found', 404);
  return row;
}

export async function createFaculty(body: Record<string, unknown>, institutionId: string) {
  // Validate user belongs to institution
  const user = await queryOne<{ id: string; department_id: string | null }>(
    'SELECT id, department_id FROM users WHERE id=$1 AND institution_id=$2',
    [body.user_id, institutionId]
  );
  if (!user) throw new AppError('User not found in this institution', 404);

  const existing = await queryOne('SELECT id FROM faculty WHERE user_id=$1', [body.user_id]);
  if (existing) throw new AppError('Faculty profile already exists for this user', 409);

  const row = await queryOne<Record<string, unknown>>(`
    INSERT INTO faculty (
      user_id, department_id, employee_code, gender, date_of_birth, date_of_joining,
      employment_type, qualification, specialization, experience_years, industry_exp_years,
      ugc_net, gate_score, phd_guide, phd_students_count, funded_projects,
      publications_count, patents_count, awards_count, fdp_attended, fdp_organized,
      orcid_id, scopus_id, google_scholar_url, profile_url
    ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25)
    RETURNING *
  `, [
    body.user_id, body.department_id ?? user.department_id, body.employee_code ?? null,
    body.gender ?? null, body.date_of_birth ?? null, body.date_of_joining ?? null,
    body.employment_type ?? 'permanent', body.qualification ?? null, body.specialization ?? null,
    body.experience_years ?? 0, body.industry_exp_years ?? 0,
    body.ugc_net ?? false, body.gate_score ?? null, body.phd_guide ?? false,
    body.phd_students_count ?? 0, body.funded_projects ?? 0, body.publications_count ?? 0,
    body.patents_count ?? 0, body.awards_count ?? 0, body.fdp_attended ?? 0, body.fdp_organized ?? 0,
    body.orcid_id ?? null, body.scopus_id ?? null, body.google_scholar_url ?? null, body.profile_url ?? null,
  ]);
  return row;
}

export async function updateFaculty(id: string, institutionId: string, body: Record<string, unknown>) {
  // Ensure faculty belongs to institution
  const check = await queryOne<{ id: string }>(
    'SELECT f.id FROM faculty f JOIN users u ON u.id=f.user_id WHERE f.id=$1 AND u.institution_id=$2',
    [id, institutionId]
  );
  if (!check) throw new AppError('Faculty not found', 404);

  const allowed = [
    'department_id','employee_code','gender','date_of_birth','date_of_joining','employment_type',
    'qualification','specialization','experience_years','industry_exp_years','ugc_net','gate_score',
    'phd_guide','phd_students_count','funded_projects','publications_count','patents_count',
    'awards_count','fdp_attended','fdp_organized','orcid_id','scopus_id','google_scholar_url','profile_url',
  ];

  const fields: string[] = [];
  const params: unknown[] = [];
  let idx = 1;

  for (const key of allowed) {
    if (body[key] !== undefined) { fields.push(`${key}=$${idx++}`); params.push(body[key]); }
  }
  if (fields.length === 0) throw new AppError('No fields to update', 400);

  params.push(id);
  const row = await queryOne<Record<string, unknown>>(
    `UPDATE faculty SET ${fields.join(',')} WHERE id=$${idx} RETURNING *`, params
  );
  return row;
}

export async function getFacultyStats(institutionId: string) {
  const rows = await queryMany<Record<string, unknown>>(`
    SELECT
      COUNT(f.id)                                       AS total_faculty,
      COUNT(*) FILTER (WHERE f.employment_type='permanent') AS permanent,
      COUNT(*) FILTER (WHERE f.ugc_net=true)            AS ugc_net_qualified,
      COUNT(*) FILTER (WHERE f.phd_guide=true)          AS phd_guides,
      COALESCE(SUM(f.publications_count),0)             AS total_publications,
      COALESCE(SUM(f.patents_count),0)                  AS total_patents,
      COALESCE(SUM(f.funded_projects),0)                AS total_funded_projects,
      COALESCE(AVG(f.experience_years),0)::NUMERIC(4,1) AS avg_experience,
      COALESCE(SUM(f.fdp_attended),0)                   AS total_fdp_attended
    FROM faculty f
    JOIN users u ON u.id = f.user_id
    WHERE u.institution_id = $1
  `, [institutionId]);

  return rows[0];
}

export async function deleteFaculty(id: string, institutionId: string): Promise<void> {
  const check = await queryOne<{ id: string }>(
    'SELECT f.id FROM faculty f JOIN users u ON u.id=f.user_id WHERE f.id=$1 AND u.institution_id=$2',
    [id, institutionId]
  );
  if (!check) throw new AppError('Faculty not found', 404);
  await query('DELETE FROM faculty WHERE id=$1', [id]);
}
