// ─── Enums ────────────────────────────────────────────────────────────────────

export enum UserRole {
  ADMIN            = 'admin',
  PRINCIPAL        = 'principal',
  IQAC_COORDINATOR = 'iqac_coordinator',
  HOD              = 'hod',
  FACULTY          = 'faculty',
  STUDENT          = 'student',
}

export enum DocStatus {
  DRAFT    = 'draft',
  PENDING  = 'pending',
  APPROVED = 'approved',
  REJECTED = 'rejected',
  ARCHIVED = 'archived',
}

export enum CriterionType {
  NAAC = 'naac',
  NBA  = 'nba',
  OBE  = 'obe',
  IQAC = 'iqac',
}

export enum ActivityAction {
  UPLOAD  = 'upload',
  REVIEW  = 'review',
  APPROVE = 'approve',
  REJECT  = 'reject',
  COMMENT = 'comment',
  LOGIN   = 'login',
  LOGOUT  = 'logout',
  CREATE  = 'create',
  UPDATE  = 'update',
  DELETE  = 'delete',
  AI_MAP  = 'ai_map',
}

export enum NotifType {
  INFO    = 'info',
  WARNING = 'warning',
  SUCCESS = 'success',
  ERROR   = 'error',
}

export enum ResearchType {
  JOURNAL      = 'journal',
  CONFERENCE   = 'conference',
  BOOK         = 'book',
  BOOK_CHAPTER = 'book_chapter',
  PATENT       = 'patent',
  PROJECT      = 'project',
  CONSULTANCY  = 'consultancy',
}

export enum PlacementStatus {
  PLACED         = 'placed',
  NOT_PLACED     = 'not_placed',
  HIGHER_STUDIES = 'higher_studies',
  ENTREPRENEUR   = 'entrepreneur',
}

export enum ReportType {
  NAAC_SSR  = 'naac_ssr',
  NAAC_IQAR = 'naac_iqar',
  NBA_SAR   = 'nba_sar',
  IQAC_AQAR = 'iqac_aqar',
  CUSTOM    = 'custom',
}

export enum AIAnalysisStatus {
  PENDING   = 'pending',
  RUNNING   = 'running',
  COMPLETED = 'completed',
  FAILED    = 'failed',
}

// ─── Domain Interfaces ────────────────────────────────────────────────────────

export interface Institution {
  id: string;
  name: string;
  code: string;
  address?: string;
  city?: string;
  state?: string;
  pincode?: string;
  phone?: string;
  email?: string;
  website?: string;
  established?: number;
  naac_grade?: string;
  naac_score?: number;
  nba_status: boolean;
  logo_url?: string;
  created_at: Date;
  updated_at: Date;
}

export interface Department {
  id: string;
  institution_id: string;
  name: string;
  code: string;
  hod_name?: string;
  established?: number;
  intake: number;
  nba_accredited: boolean;
  nba_valid_till?: Date;
  description?: string;
  created_at: Date;
  updated_at: Date;
}

export interface User {
  id: string;
  institution_id: string;
  department_id?: string;
  email: string;
  password_hash: string;
  name: string;
  role: UserRole;
  phone?: string;
  avatar_url?: string;
  employee_id?: string;
  designation?: string;
  is_active: boolean;
  last_login?: Date;
  refresh_token?: string;
  created_at: Date;
  updated_at: Date;
}

export interface Faculty {
  id: string;
  user_id: string;
  department_id: string;
  employee_code?: string;
  gender?: string;
  date_of_birth?: Date;
  date_of_joining?: Date;
  employment_type: string;
  qualification?: string;
  specialization?: string;
  experience_years: number;
  industry_exp_years: number;
  ugc_net: boolean;
  gate_score?: number;
  phd_guide: boolean;
  phd_students_count: number;
  funded_projects: number;
  publications_count: number;
  patents_count: number;
  awards_count: number;
  fdp_attended: number;
  fdp_organized: number;
  orcid_id?: string;
  scopus_id?: string;
  google_scholar_url?: string;
  profile_url?: string;
  created_at: Date;
  updated_at: Date;
}

export interface Student {
  id: string;
  institution_id: string;
  department_id: string;
  roll_number: string;
  name: string;
  email?: string;
  phone?: string;
  gender?: string;
  date_of_birth?: Date;
  batch_year: number;
  year_of_study?: number;
  semester?: number;
  section?: string;
  lateral_entry: boolean;
  category?: string;
  cgpa?: number;
  arrear_count: number;
  active: boolean;
  created_at: Date;
  updated_at: Date;
}

export interface Document {
  id: string;
  institution_id: string;
  department_id?: string;
  uploaded_by: string;
  reviewed_by?: string;
  title: string;
  description?: string;
  file_name: string;
  file_path: string;
  file_type?: string;
  file_size?: number;
  status: DocStatus;
  criterion_type?: CriterionType;
  criterion_ref?: string;
  tags?: string[];
  ai_tags?: string[];
  ai_mapped: boolean;
  ai_confidence?: number;
  academic_year?: string;
  version: number;
  rejection_note?: string;
  review_note?: string;
  created_at: Date;
  updated_at: Date;
}

export interface Research {
  id: string;
  faculty_id: string;
  title: string;
  type: ResearchType;
  journal_name?: string;
  publisher?: string;
  doi?: string;
  isbn_issn?: string;
  year?: number;
  volume?: string;
  issue?: string;
  pages?: string;
  impact_factor?: number;
  scopus_indexed: boolean;
  wos_indexed: boolean;
  ugc_listed: boolean;
  funding_agency?: string;
  funding_amount?: number;
  abstract?: string;
  keywords?: string[];
  co_authors?: string[];
  document_url?: string;
  verified: boolean;
  verified_by?: string;
  created_at: Date;
  updated_at: Date;
}

export interface Placement {
  id: string;
  student_id: string;
  batch_year: number;
  status: PlacementStatus;
  company_name?: string;
  package_lpa?: number;
  offer_date?: Date;
  joining_date?: Date;
  job_role?: string;
  placement_type?: string;
  higher_studies?: string;
  created_at: Date;
  updated_at: Date;
}

export interface NaacCriteria {
  id: string;
  institution_id: string;
  criterion_no: string;
  criterion_name: string;
  sub_criteria?: string;
  description?: string;
  max_score: number;
  current_score: number;
  completion_pct: number;
  cycle_year?: string;
  responsible_id?: string;
  due_date?: Date;
  notes?: string;
  created_at: Date;
  updated_at: Date;
}

export interface Report {
  id: string;
  institution_id: string;
  generated_by: string;
  title: string;
  type: ReportType;
  academic_year?: string;
  description?: string;
  parameters?: Record<string, unknown>;
  file_path?: string;
  file_size?: number;
  status: string;
  generated_at?: Date;
  created_at: Date;
  updated_at: Date;
}

export interface AIAnalysis {
  id: string;
  institution_id: string;
  document_id?: string;
  triggered_by: string;
  analysis_type: string;
  status: AIAnalysisStatus;
  input_data?: Record<string, unknown>;
  result?: Record<string, unknown>;
  suggestions?: Record<string, unknown>;
  confidence?: number;
  criteria_mapped?: string[];
  error_message?: string;
  started_at?: Date;
  completed_at?: Date;
  created_at: Date;
}

// ─── Request / Response helpers ───────────────────────────────────────────────

export interface AuthPayload {
  userId: string;
  institutionId: string;
  role: UserRole;
  email: string;
}

export interface PaginationParams {
  page: number;
  limit: number;
  offset: number;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

export interface ApiResponse<T = unknown> {
  success: boolean;
  message: string;
  data?: T;
  errors?: string[];
}

// ─── Express augmentation ─────────────────────────────────────────────────────

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      user?: AuthPayload;
      institutionId?: string;
      file?: Express.Multer.File;
    }
  }
}
