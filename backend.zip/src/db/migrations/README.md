# Migrations

The canonical, tested migration runner is **`src/db/migrate.ts`**, executed via:

```bash
npm run db:migrate
```

It is idempotent — every `CREATE TYPE`, `CREATE TABLE`, `CREATE INDEX`, and
trigger statement uses `IF NOT EXISTS` / exception-guarded blocks, so it can
be safely re-run against an existing database without error or data loss.

`001_initial_schema.sql` in this folder is a plain-SQL mirror of that same
schema, provided for:

- Direct inspection without running Node/TypeScript
- Applying the schema with `psql -f src/db/migrations/001_initial_schema.sql`
  in environments where running the TypeScript runner isn't convenient
- Database tooling that expects a `migrations/` folder with `.sql` files

If you modify the schema, update **`src/db/migrate.ts` first** (it is what
`npm run db:migrate` actually executes), then mirror the change here.
