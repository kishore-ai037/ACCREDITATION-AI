-- ============================================================================
-- AccrediAI — Initial Schema Migration (SQL reference)
-- ============================================================================
-- This file is a plain-SQL mirror of the migration logic executed by
-- `src/db/migrate.ts` (the canonical, tested runner invoked via `npm run
-- db:migrate`). It is provided so the schema can also be applied directly
-- with `psql -f` or inspected without running Node/TypeScript.
--
-- Source of truth: src/db/migrate.ts
-- ============================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- ── Enums ────────────────────────────────────────────────────────────────────
DO $$ BEGIN
  CREATE TYPE user_role AS ENUM ('admin','principal','iqac_coordinator','hod','faculty','student');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE doc_status AS ENUM ('draft','pending','approved','rejected','archived');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE criterion_type AS ENUM ('naac','nba','obe','iqac');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE activity_action AS ENUM ('upload','review','approve','reject','comment','login','logout','create','update','delete','ai_map');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE notif_type AS ENUM ('info','warning','success','error');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE gender_type AS ENUM ('male','female','other','prefer_not_to_say');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE employment_type AS ENUM ('permanent','contract','visiting','adjunct');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE placement_status AS ENUM ('placed','not_placed','higher_studies','entrepreneur');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE research_type AS ENUM ('journal','conference','book','book_chapter','patent','project','consultancy');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE report_type AS ENUM ('naac_ssr','naac_iqar','nba_sar','iqac_aqar','custom');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE ai_analysis_status AS ENUM ('pending','running','completed','failed');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- ── Institutions ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS institutions (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name          VARCHAR(255)  NOT NULL,
  code          VARCHAR(50)   UNIQUE NOT NULL,
  address       TEXT,
  city          VARCHAR(100),
  state         VARCHAR(100),
  pincode       VARCHAR(10),
  phone         VARCHAR(20),
  email         VARCHAR(150),
  website       VARCHAR(255),
  established   INTEGER,
  naac_grade    VARCHAR(5),
  naac_score    DECIMAL(4,2),
  nba_status    BOOLEAN       NOT NULL DEFAULT FALSE,
  logo_url      VARCHAR(500),
  created_at    TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

-- ── Departments ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS departments (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  institution_id  UUID          NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
  name            VARCHAR(200)  NOT NULL,
  code            VARCHAR(20)   NOT NULL,
  hod_name        VARCHAR(200),
  established     INTEGER,
  intake          INTEGER       NOT NULL DEFAULT 60,
  nba_accredited  BOOLEAN       NOT NULL DEFAULT FALSE,
  nba_valid_till  DATE,
  description     TEXT,
  created_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  UNIQUE (institution_id, code)
);
CREATE INDEX IF NOT EXISTS idx_dept_inst ON departments(institution_id);

-- ── Users ────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  institution_id  UUID          NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
  department_id   UUID          REFERENCES departments(id) ON DELETE SET NULL,
  email           VARCHAR(255)  UNIQUE NOT NULL,
  password_hash   VARCHAR(255)  NOT NULL,
  name            VARCHAR(200)  NOT NULL,
  role            user_role     NOT NULL DEFAULT 'faculty',
  phone           VARCHAR(20),
  avatar_url      VARCHAR(500),
  employee_id     VARCHAR(50),
  designation     VARCHAR(150),
  is_active       BOOLEAN       NOT NULL DEFAULT TRUE,
  last_login      TIMESTAMPTZ,
  refresh_token   TEXT,
  created_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_inst  ON users(institution_id);
CREATE INDEX IF NOT EXISTS idx_users_dept  ON users(department_id);
CREATE INDEX IF NOT EXISTS idx_users_role  ON users(role);

-- ── Faculty Profiles ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS faculty (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id             UUID          UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  department_id       UUID          NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
  employee_code       VARCHAR(50)   UNIQUE,
  gender              gender_type,
  date_of_birth       DATE,
  date_of_joining     DATE,
  employment_type     employment_type NOT NULL DEFAULT 'permanent',
  qualification       VARCHAR(255),
  specialization      VARCHAR(255),
  experience_years    DECIMAL(4,1)  NOT NULL DEFAULT 0,
  industry_exp_years  DECIMAL(4,1)  NOT NULL DEFAULT 0,
  ugc_net             BOOLEAN       NOT NULL DEFAULT FALSE,
  gate_score          DECIMAL(6,2),
  phd_guide           BOOLEAN       NOT NULL DEFAULT FALSE,
  phd_students_count  INTEGER       NOT NULL DEFAULT 0,
  funded_projects     INTEGER       NOT NULL DEFAULT 0,
  publications_count  INTEGER       NOT NULL DEFAULT 0,
  patents_count       INTEGER       NOT NULL DEFAULT 0,
  awards_count        INTEGER       NOT NULL DEFAULT 0,
  fdp_attended        INTEGER       NOT NULL DEFAULT 0,
  fdp_organized       INTEGER       NOT NULL DEFAULT 0,
  orcid_id            VARCHAR(50),
  scopus_id           VARCHAR(50),
  google_scholar_url  VARCHAR(500),
  profile_url         VARCHAR(500),
  created_at          TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  updated_at          TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_faculty_dept ON faculty(department_id);
CREATE INDEX IF NOT EXISTS idx_faculty_user ON faculty(user_id);

-- ── Students ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS students (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  institution_id  UUID          NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
  department_id   UUID          NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
  roll_number     VARCHAR(50)   UNIQUE NOT NULL,
  name            VARCHAR(200)  NOT NULL,
  email           VARCHAR(255),
  phone           VARCHAR(20),
  gender          gender_type,
  date_of_birth   DATE,
  batch_year      INTEGER       NOT NULL,
  year_of_study   INTEGER,
  semester        INTEGER,
  section         VARCHAR(5),
  lateral_entry   BOOLEAN       NOT NULL DEFAULT FALSE,
  category        VARCHAR(20),
  cgpa            DECIMAL(4,2),
  arrear_count    INTEGER       NOT NULL DEFAULT 0,
  active          BOOLEAN       NOT NULL DEFAULT TRUE,
  created_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_students_dept  ON students(department_id);
CREATE INDEX IF NOT EXISTS idx_students_batch ON students(batch_year);
CREATE INDEX IF NOT EXISTS idx_students_roll  ON students(roll_number);
CREATE INDEX IF NOT EXISTS idx_students_inst  ON students(institution_id);

-- ── Placements ───────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS placements (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  student_id      UUID              NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  batch_year      INTEGER           NOT NULL,
  status          placement_status  NOT NULL DEFAULT 'not_placed',
  company_name    VARCHAR(200),
  package_lpa     DECIMAL(6,2),
  offer_date      DATE,
  joining_date    DATE,
  job_role        VARCHAR(200),
  placement_type  VARCHAR(50),
  higher_studies  VARCHAR(200),
  created_at      TIMESTAMPTZ       NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ       NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_place_student ON placements(student_id);
CREATE INDEX IF NOT EXISTS idx_place_batch   ON placements(batch_year);

-- ── Research ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS research (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  faculty_id      UUID           NOT NULL REFERENCES faculty(id) ON DELETE CASCADE,
  title           VARCHAR(500)   NOT NULL,
  type            research_type  NOT NULL,
  journal_name    VARCHAR(300),
  publisher       VARCHAR(200),
  doi             VARCHAR(200),
  isbn_issn       VARCHAR(50),
  year            INTEGER,
  volume          VARCHAR(20),
  issue           VARCHAR(20),
  pages           VARCHAR(30),
  impact_factor   DECIMAL(5,3),
  scopus_indexed  BOOLEAN        NOT NULL DEFAULT FALSE,
  wos_indexed     BOOLEAN        NOT NULL DEFAULT FALSE,
  ugc_listed      BOOLEAN        NOT NULL DEFAULT FALSE,
  funding_agency  VARCHAR(200),
  funding_amount  DECIMAL(12,2),
  abstract        TEXT,
  keywords        TEXT[],
  co_authors      TEXT[],
  document_url    VARCHAR(500),
  verified        BOOLEAN        NOT NULL DEFAULT FALSE,
  verified_by     UUID           REFERENCES users(id) ON DELETE SET NULL,
  created_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_research_faculty ON research(faculty_id);
CREATE INDEX IF NOT EXISTS idx_research_year    ON research(year);
CREATE INDEX IF NOT EXISTS idx_research_type    ON research(type);

-- ── NAAC Criteria ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS naac_criteria (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  institution_id  UUID           NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
  criterion_no    VARCHAR(10)    NOT NULL,
  criterion_name  VARCHAR(200)   NOT NULL,
  sub_criteria    VARCHAR(20),
  description     TEXT,
  max_score       DECIMAL(6,2)   NOT NULL DEFAULT 100,
  current_score   DECIMAL(6,2)   NOT NULL DEFAULT 0,
  completion_pct  DECIMAL(5,2)   NOT NULL DEFAULT 0,
  cycle_year      VARCHAR(10),
  responsible_id  UUID           REFERENCES users(id) ON DELETE SET NULL,
  due_date        DATE,
  notes           TEXT,
  created_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
  UNIQUE(institution_id, criterion_no, COALESCE(sub_criteria,''), COALESCE(cycle_year,''))
);
CREATE INDEX IF NOT EXISTS idx_naac_inst ON naac_criteria(institution_id);

-- ── NBA Criteria ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS nba_criteria (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  department_id   UUID           NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
  criterion_no    VARCHAR(10)    NOT NULL,
  criterion_name  VARCHAR(200)   NOT NULL,
  max_marks       DECIMAL(6,2),
  obtained_marks  DECIMAL(6,2)   NOT NULL DEFAULT 0,
  completion_pct  DECIMAL(5,2)   NOT NULL DEFAULT 0,
  cycle_year      VARCHAR(10),
  tier            INTEGER        NOT NULL DEFAULT 1,
  notes           TEXT,
  created_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_nba_dept ON nba_criteria(department_id);

-- ── Documents ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS documents (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  institution_id  UUID           NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
  department_id   UUID           REFERENCES departments(id) ON DELETE SET NULL,
  uploaded_by     UUID           NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  reviewed_by     UUID           REFERENCES users(id) ON DELETE SET NULL,
  title           VARCHAR(500)   NOT NULL,
  description     TEXT,
  file_name       VARCHAR(500)   NOT NULL,
  file_path       VARCHAR(500)   NOT NULL,
  file_type       VARCHAR(50),
  file_size       BIGINT,
  status          doc_status     NOT NULL DEFAULT 'draft',
  criterion_type  criterion_type,
  criterion_ref   VARCHAR(20),
  tags            TEXT[]         NOT NULL DEFAULT '{}',
  ai_tags         TEXT[]         NOT NULL DEFAULT '{}',
  ai_mapped       BOOLEAN        NOT NULL DEFAULT FALSE,
  ai_confidence   DECIMAL(5,2),
  academic_year   VARCHAR(10),
  version         INTEGER        NOT NULL DEFAULT 1,
  rejection_note  TEXT,
  review_note     TEXT,
  created_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_docs_inst      ON documents(institution_id);
CREATE INDEX IF NOT EXISTS idx_docs_status    ON documents(status);
CREATE INDEX IF NOT EXISTS idx_docs_criterion ON documents(criterion_type, criterion_ref);
CREATE INDEX IF NOT EXISTS idx_docs_uploader  ON documents(uploaded_by);
CREATE INDEX IF NOT EXISTS idx_docs_dept      ON documents(department_id);
CREATE INDEX IF NOT EXISTS idx_docs_tags      ON documents USING gin(tags);
CREATE INDEX IF NOT EXISTS idx_docs_search    ON documents USING gin(to_tsvector('english', title));

-- ── IQAC Meetings ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS iqac_meetings (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  institution_id  UUID           NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
  title           VARCHAR(300)   NOT NULL,
  meeting_date    DATE           NOT NULL,
  venue           VARCHAR(200),
  agenda          TEXT,
  minutes         TEXT,
  action_points   JSONB          NOT NULL DEFAULT '[]',
  attendees       UUID[]         NOT NULL DEFAULT '{}',
  document_url    VARCHAR(500),
  created_by      UUID           NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  created_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_iqac_meetings_inst ON iqac_meetings(institution_id);

-- ── IQAC Action Plans ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS iqac_action_plans (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  institution_id  UUID           NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
  title           VARCHAR(300)   NOT NULL,
  description     TEXT,
  target_date     DATE,
  responsible_id  UUID           REFERENCES users(id) ON DELETE SET NULL,
  status          VARCHAR(50)    NOT NULL DEFAULT 'planned',
  completion_pct  DECIMAL(5,2)   NOT NULL DEFAULT 0,
  academic_year   VARCHAR(10),
  priority        VARCHAR(20)    NOT NULL DEFAULT 'medium',
  remarks         TEXT,
  created_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_iqac_plans_inst ON iqac_action_plans(institution_id);

-- ── Reports ──────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS reports (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  institution_id  UUID           NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
  generated_by    UUID           NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  title           VARCHAR(400)   NOT NULL,
  type            report_type    NOT NULL,
  academic_year   VARCHAR(10),
  description     TEXT,
  parameters      JSONB          NOT NULL DEFAULT '{}',
  file_path       VARCHAR(500),
  file_size       BIGINT,
  status          VARCHAR(50)    NOT NULL DEFAULT 'generating',
  generated_at    TIMESTAMPTZ,
  created_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_reports_inst ON reports(institution_id);
CREATE INDEX IF NOT EXISTS idx_reports_type ON reports(type);

-- ── AI Analysis ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS ai_analysis (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  institution_id  UUID                NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
  document_id     UUID                REFERENCES documents(id) ON DELETE CASCADE,
  triggered_by    UUID                NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  analysis_type   VARCHAR(100)        NOT NULL,
  status          ai_analysis_status  NOT NULL DEFAULT 'pending',
  input_data      JSONB               NOT NULL DEFAULT '{}',
  result          JSONB,
  suggestions     JSONB,
  confidence      DECIMAL(5,2),
  criteria_mapped TEXT[]              NOT NULL DEFAULT '{}',
  error_message   TEXT,
  started_at      TIMESTAMPTZ,
  completed_at    TIMESTAMPTZ,
  created_at      TIMESTAMPTZ         NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_ai_inst ON ai_analysis(institution_id);
CREATE INDEX IF NOT EXISTS idx_ai_doc  ON ai_analysis(document_id);

-- ── Activity Log ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS activity_log (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  institution_id  UUID             REFERENCES institutions(id) ON DELETE CASCADE,
  user_id         UUID             REFERENCES users(id) ON DELETE SET NULL,
  user_name       VARCHAR(200),
  action          activity_action  NOT NULL,
  entity_type     VARCHAR(100),
  entity_id       UUID,
  entity_title    VARCHAR(500),
  description     TEXT,
  ip_address      INET,
  user_agent      TEXT,
  metadata        JSONB            NOT NULL DEFAULT '{}',
  created_at      TIMESTAMPTZ      NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_act_inst    ON activity_log(institution_id);
CREATE INDEX IF NOT EXISTS idx_act_user    ON activity_log(user_id);
CREATE INDEX IF NOT EXISTS idx_act_created ON activity_log(created_at DESC);

-- ── Notifications ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS notifications (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID           NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title           VARCHAR(300)   NOT NULL,
  message         TEXT           NOT NULL,
  type            notif_type     NOT NULL DEFAULT 'info',
  read            BOOLEAN        NOT NULL DEFAULT FALSE,
  link            VARCHAR(500),
  metadata        JSONB          NOT NULL DEFAULT '{}',
  created_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_notif_user ON notifications(user_id, read);

-- ── Auto-updated_at trigger ──────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION fn_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$;

-- Applied via src/db/migrate.ts to: institutions, departments, users, faculty,
-- students, placements, research, naac_criteria, nba_criteria, documents,
-- iqac_meetings, iqac_action_plans, reports, ai_analysis
