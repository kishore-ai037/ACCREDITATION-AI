import bcrypt from 'bcryptjs';
import { query, testConnection, withTransaction } from '../config/database';
import { PoolClient } from 'pg';

async function seed(client: PoolClient): Promise<void> {
  console.log('🌱 Seeding AccrediAI database…\n');

  // ── Institution ────────────────────────────────────────────────────────────
  const institutionRes = await client.query<{ id: string }>(`
    INSERT INTO institutions (name, code, address, city, state, pincode, phone, email, website, established, naac_grade, naac_score, nba_status)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
    ON CONFLICT (code) DO UPDATE SET name = EXCLUDED.name
    RETURNING id
  `, [
    'Sri Ramakrishna Engineering College', 'SREC',
    '395 Vattamalaipalayam, Coimbatore', 'Coimbatore', 'Tamil Nadu', '641022',
    '0422-2666571', 'info@srec.ac.in', 'https://www.srec.ac.in',
    1994, 'A++', 3.42, true,
  ]);
  const instId = institutionRes.rows[0].id;
  console.log('  ✓ Institution:', instId);

  // ── Departments ────────────────────────────────────────────────────────────
  const depts = [
    { name: 'Computer Science & Engineering', code: 'CSE', hod: 'Dr. Meena Rajan', intake: 120 },
    { name: 'Electronics & Communication Engineering', code: 'ECE', hod: 'Dr. Suresh Babu', intake: 90 },
    { name: 'Mechanical Engineering', code: 'MECH', hod: 'Dr. Karthik Raman', intake: 60 },
    { name: 'Civil Engineering', code: 'CIVIL', hod: 'Dr. Anitha Selvam', intake: 60 },
    { name: 'Information Technology', code: 'IT', hod: 'Dr. Pradeep Kumar', intake: 60 },
    { name: 'Administration', code: 'ADMIN', hod: 'Dr. Priya Sharma', intake: 0 },
  ];

  const deptIds: Record<string, string> = {};
  for (const d of depts) {
    const r = await client.query<{ id: string }>(`
      INSERT INTO departments (institution_id, name, code, hod_name, intake, nba_accredited)
      VALUES ($1,$2,$3,$4,$5,$6)
      ON CONFLICT (institution_id, code) DO UPDATE SET name = EXCLUDED.name
      RETURNING id
    `, [instId, d.name, d.code, d.hod, d.intake, d.code !== 'ADMIN']);
    deptIds[d.code] = r.rows[0].id;
  }
  console.log('  ✓ Departments:', Object.keys(deptIds).join(', '));

  // ── Users ──────────────────────────────────────────────────────────────────
  const passwordHash = await bcrypt.hash('Admin@123', 12);

  const users = [
    { email: 'admin@accredi.ai',  name: 'Dr. Priya Sharma',   role: 'admin',            dept: 'ADMIN', designation: 'Principal' },
    { email: 'iqac@accredi.ai',   name: 'Prof. Rajesh Kumar',  role: 'iqac_coordinator', dept: 'ADMIN', designation: 'IQAC Director' },
    { email: 'hod@accredi.ai',    name: 'Dr. Meena Rajan',     role: 'hod',              dept: 'CSE',   designation: 'Professor & HoD' },
    { email: 'faculty@accredi.ai',name: 'Prof. Anitha Selvam', role: 'faculty',          dept: 'CSE',   designation: 'Associate Professor' },
    { email: 'hod.ece@accredi.ai',name: 'Dr. Suresh Babu',     role: 'hod',              dept: 'ECE',   designation: 'Professor & HoD' },
    { email: 'hod.it@accredi.ai', name: 'Dr. Pradeep Kumar',   role: 'hod',              dept: 'IT',    designation: 'Professor & HoD' },
  ];

  const userIds: Record<string, string> = {};
  for (const u of users) {
    const r = await client.query<{ id: string }>(`
      INSERT INTO users (institution_id, department_id, email, password_hash, name, role, designation, is_active)
      VALUES ($1,$2,$3,$4,$5,$6::user_role,$7,$8)
      ON CONFLICT (email) DO UPDATE SET name = EXCLUDED.name
      RETURNING id
    `, [instId, deptIds[u.dept], u.email, passwordHash, u.name, u.role, u.designation, true]);
    userIds[u.email] = r.rows[0].id;
  }
  console.log('  ✓ Users:', Object.keys(userIds).length);

  // ── Faculty Profiles ───────────────────────────────────────────────────────
  const facultyData = [
    { email: 'hod@accredi.ai',    dept: 'CSE',  code: 'FAC001', exp: 22, pubs: 45, patents: 3, ugc: true,  phd_guide: true },
    { email: 'faculty@accredi.ai',dept: 'CSE',  code: 'FAC002', exp: 14, pubs: 28, patents: 1, ugc: true,  phd_guide: false },
    { email: 'hod.ece@accredi.ai',dept: 'ECE',  code: 'FAC003', exp: 19, pubs: 38, patents: 2, ugc: true,  phd_guide: true },
    { email: 'hod.it@accredi.ai', dept: 'IT',   code: 'FAC004', exp: 16, pubs: 32, patents: 0, ugc: true,  phd_guide: false },
  ];

  const facultyIds: Record<string, string> = {};
  for (const f of facultyData) {
    const r = await client.query<{ id: string }>(`
      INSERT INTO faculty (user_id, department_id, employee_code, gender, date_of_joining, employment_type, qualification, specialization,
                           experience_years, ugc_net, phd_guide, publications_count, patents_count, awards_count, fdp_attended, fdp_organized)
      VALUES ($1,$2,$3,'female',$4,'permanent','Ph.D','Computer Science',$5,$6,$7,$8,$9,$10,$11,$12)
      ON CONFLICT (user_id) DO UPDATE SET publications_count = EXCLUDED.publications_count
      RETURNING id
    `, [userIds[f.email], deptIds[f.dept], f.code, '2005-07-01', f.exp, f.ugc, f.phd_guide, f.pubs, f.patents, 5, 12, 3]);
    facultyIds[f.email] = r.rows[0].id;
  }
  console.log('  ✓ Faculty profiles:', Object.keys(facultyIds).length);

  // ── Students (sample) ──────────────────────────────────────────────────────
  const batchYear = 2022;
  for (let i = 1; i <= 20; i++) {
    const roll = `22CSE${String(i).padStart(3, '0')}`;
    await client.query(`
      INSERT INTO students (institution_id, department_id, roll_number, name, batch_year, year_of_study, semester, section, cgpa, active)
      VALUES ($1,$2,$3,$4,$5,3,5,'A',$6,true)
      ON CONFLICT (roll_number) DO NOTHING
    `, [instId, deptIds['CSE'], roll, `Student ${i}`, batchYear, (3.5 + Math.random() * 1.5).toFixed(2)]);
  }
  console.log('  ✓ Students: 20');

  // ── Placements (sample) ────────────────────────────────────────────────────
  const companies = ['TCS', 'Infosys', 'Wipro', 'Cognizant', 'HCL', 'Zoho', 'Google', 'Amazon'];
  const studentRes = await client.query<{ id: string }>(`SELECT id FROM students WHERE department_id=$1 LIMIT 15`, [deptIds['CSE']]);
  for (let i = 0; i < studentRes.rows.length; i++) {
    const placed = i < 12;
    await client.query(`
      INSERT INTO placements (student_id, batch_year, status, company_name, package_lpa, job_role, offer_date)
      VALUES ($1,$2,$3,$4,$5,$6,$7)
      ON CONFLICT DO NOTHING
    `, [
      studentRes.rows[i].id, batchYear,
      placed ? 'placed' : 'not_placed',
      placed ? companies[i % companies.length] : null,
      placed ? (3.5 + Math.random() * 12).toFixed(2) : null,
      placed ? 'Software Engineer' : null,
      placed ? '2024-04-15' : null,
    ]);
  }
  console.log('  ✓ Placements');

  // ── Research Publications ──────────────────────────────────────────────────
  const researchData = [
    { title: 'Deep Learning Approaches for Medical Image Segmentation', type: 'journal', journal: 'IEEE Transactions on Medical Imaging', year: 2024, if: 10.048, scopus: true, wos: true },
    { title: 'Federated Learning in Privacy-Preserving IoT Systems', type: 'journal', journal: 'Elsevier Computers & Security', year: 2024, if: 5.105, scopus: true, wos: false },
    { title: 'Explainable AI for Credit Risk Assessment', type: 'conference', journal: 'IEEE ICMLA 2024', year: 2024, if: 0, scopus: true, wos: false },
    { title: 'Quantum-Resistant Cryptographic Protocols for Smart Grid', type: 'journal', journal: 'Future Generation Computer Systems', year: 2023, if: 7.307, scopus: true, wos: true },
    { title: 'Blockchain-Based Decentralized Identity Verification', type: 'conference', journal: 'ACM CCS 2023', year: 2023, if: 0, scopus: true, wos: false },
  ];

  const facultyIdList = Object.values(facultyIds);
  for (let i = 0; i < researchData.length; i++) {
    const r = researchData[i];
    await client.query(`
      INSERT INTO research (faculty_id, title, type, journal_name, year, impact_factor, scopus_indexed, wos_indexed, ugc_listed, verified)
      VALUES ($1,$2,$3::research_type,$4,$5,$6,$7,$8,true,true)
    `, [facultyIdList[i % facultyIdList.length], r.title, r.type, r.journal, r.year, r.if, r.scopus, r.wos]);
  }
  console.log('  ✓ Research:', researchData.length);

  // ── NAAC Criteria ──────────────────────────────────────────────────────────
  const naacData = [
    { no: 'C1', name: 'Curricular Aspects',          score: 88,  max: 100 },
    { no: 'C2', name: 'Teaching-Learning & Evaluation', score: 72, max: 100 },
    { no: 'C3', name: 'Research, Innovations & Extension', score: 65, max: 100 },
    { no: 'C4', name: 'Infrastructure & Learning Resources', score: 91, max: 100 },
    { no: 'C5', name: 'Student Support & Progression', score: 79, max: 100 },
    { no: 'C6', name: 'Governance, Leadership & Management', score: 58, max: 100 },
    { no: 'C7', name: 'Institutional Values & Best Practices', score: 43, max: 100 },
  ];
  for (const c of naacData) {
    await client.query(`
      INSERT INTO naac_criteria (institution_id, criterion_no, criterion_name, max_score, current_score, completion_pct, cycle_year)
      VALUES ($1,$2,$3,$4,$5,$6,'2024-25')
      ON CONFLICT (institution_id, criterion_no, COALESCE(sub_criteria,''), COALESCE(cycle_year,''))
      DO UPDATE SET current_score = EXCLUDED.current_score, completion_pct = EXCLUDED.completion_pct
    `, [instId, c.no, c.name, c.max, c.score, c.score]);
  }
  console.log('  ✓ NAAC criteria:', naacData.length);

  // ── Documents ──────────────────────────────────────────────────────────────
  const docData = [
    { title: 'Course Outcome Assessment Report – CSE 2024-25', criterion: 'naac', ref: 'C2', status: 'approved', uid: userIds['hod@accredi.ai'] },
    { title: 'NBA Criterion 4 Evidence Bundle – ECE', criterion: 'nba', ref: 'C4', status: 'approved', uid: userIds['hod.ece@accredi.ai'] },
    { title: 'Annual Quality Assurance Report 2024-25', criterion: 'iqac', ref: null, status: 'pending', uid: userIds['iqac@accredi.ai'] },
    { title: 'Faculty Development Program Records', criterion: 'naac', ref: 'C3', status: 'approved', uid: userIds['hod@accredi.ai'] },
    { title: 'Student Feedback Analysis – Even Semester', criterion: 'naac', ref: 'C2', status: 'pending', uid: userIds['faculty@accredi.ai'] },
    { title: 'Lab Utilization Report 2024-25', criterion: 'naac', ref: 'C4', status: 'draft', uid: userIds['hod.ece@accredi.ai'] },
    { title: 'Research Publication Summary 2023-24', criterion: 'naac', ref: 'C3', status: 'approved', uid: userIds['hod@accredi.ai'] },
    { title: 'Placement Statistics Report 2024', criterion: 'naac', ref: 'C5', status: 'approved', uid: userIds['iqac@accredi.ai'] },
  ];
  for (const d of docData) {
    await client.query(`
      INSERT INTO documents (institution_id, department_id, uploaded_by, title, file_name, file_path, file_type, file_size, status, criterion_type, criterion_ref, academic_year, tags, ai_mapped)
      VALUES ($1,$2,$3,$4,$5,$6,'application/pdf',$7,$8::doc_status,$9::criterion_type,$10,'2024-25',$11,true)
    `, [
      instId, deptIds['CSE'], d.uid,
      d.title,
      d.title.toLowerCase().replace(/[^a-z0-9]+/g, '_') + '.pdf',
      '/uploads/sample/' + d.title.toLowerCase().replace(/[^a-z0-9]+/g, '_') + '.pdf',
      Math.floor(Math.random() * 2000000) + 500000,
      d.status, d.criterion, d.ref,
      ['accreditation', d.criterion ?? 'general'],
    ]);
  }
  console.log('  ✓ Documents:', docData.length);

  // ── IQAC Meetings ──────────────────────────────────────────────────────────
  await client.query(`
    INSERT INTO iqac_meetings (institution_id, title, meeting_date, venue, agenda, minutes, action_points, created_by)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
    ON CONFLICT DO NOTHING
  `, [
    instId,
    '1st IQAC Meeting 2024-25',
    '2024-07-15',
    'Committee Room, Admin Block',
    'Review of NAAC criteria progress; Action plan for criterion 3 & 6; NBA re-accreditation status',
    'The meeting discussed progress on NAAC criteria. Action items were assigned.',
    JSON.stringify([
      { point: 'Upload remaining C3 documents', responsible: 'Dr. Meena Rajan', deadline: '2024-08-01', status: 'completed' },
      { point: 'Prepare C6 governance report', responsible: 'Dr. Priya Sharma', deadline: '2024-08-15', status: 'in_progress' },
    ]),
    userIds['iqac@accredi.ai'],
  ]);
  console.log('  ✓ IQAC meetings: 1');

  // ── Notifications ──────────────────────────────────────────────────────────
  const notifs = [
    { userId: userIds['hod@accredi.ai'],    title: 'NAAC Deadline Approaching', msg: 'Criterion 7 evidence submission closes in 5 days.', type: 'warning' },
    { userId: userIds['iqac@accredi.ai'],   title: 'AI Evidence Match Found',   msg: '3 new documents auto-mapped to NBA Criterion 2.',  type: 'success' },
    { userId: userIds['admin@accredi.ai'],  title: 'Review Assigned',           msg: 'IQAC report assigned to you for verification.',     type: 'info' },
    { userId: userIds['faculty@accredi.ai'],title: 'Document Rejected',         msg: 'Lab utilization report needs revision.',            type: 'error' },
  ];
  for (const n of notifs) {
    await client.query(`
      INSERT INTO notifications (user_id, title, message, type, read)
      VALUES ($1,$2,$3,$4::notif_type,false)
    `, [n.userId, n.title, n.msg, n.type]);
  }
  console.log('  ✓ Notifications:', notifs.length);

  // ── Activity Log ───────────────────────────────────────────────────────────
  await client.query(`
    INSERT INTO activity_log (institution_id, user_id, user_name, action, entity_type, entity_title, description)
    VALUES ($1,$2,$3,'create','institution',$4,'Institution and seed data created via db:seed')
  `, [instId, userIds['admin@accredi.ai'], 'Dr. Priya Sharma', 'AccrediAI Seed']);
  console.log('  ✓ Activity log entry');

  console.log('\n✅ Seed complete.\n');
  console.log('Demo credentials (all use password: Admin@123)');
  console.log('  admin@accredi.ai    → Admin / Principal');
  console.log('  iqac@accredi.ai     → IQAC Coordinator');
  console.log('  hod@accredi.ai      → Head of Department (CSE)');
  console.log('  faculty@accredi.ai  → Faculty\n');
}

testConnection()
  .then(() => withTransaction(seed))
  .then(() => process.exit(0))
  .catch(err => { console.error(err); process.exit(1); });
