# Seeds

The canonical, tested seed runner is **`src/db/seed.ts`**, executed via:

```bash
npm run db:seed
```

It performs real logic that cannot be reduced to static data alone:

- Hashes the demo password (`Admin@123`) with `bcryptjs` before insert
- Looks up generated UUIDs (institution, department, user, faculty IDs) and
  wires foreign keys correctly across 9+ related tables
- Uses `ON CONFLICT ... DO UPDATE` / `DO NOTHING` so it is safe to re-run
- Runs inside a single database transaction (`withTransaction`) so a failure
  partway through leaves no partial data behind

`demo_dataset.json` in this folder documents the resulting dataset (which
institution, departments, demo user accounts, and NAAC criteria get created)
for quick reference without reading the full runner script.

If you need different demo data, edit **`src/db/seed.ts` directly** — it is
what `npm run db:seed` actually executes.
