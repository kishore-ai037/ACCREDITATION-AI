import { query, testConnection } from '../config/database';

async function reset(): Promise<void> {
  console.log('⚠️  Dropping all AccrediAI tables…');

  await query(`DROP TABLE IF EXISTS
    notifications, activity_log, ai_analysis, reports,
    iqac_action_plans, iqac_meetings, documents,
    nba_criteria, naac_criteria, research, placements,
    students, faculty, users, departments, institutions
    CASCADE`);

  await query(`DROP TYPE IF EXISTS
    user_role, doc_status, criterion_type, activity_action,
    notif_type, gender_type, employment_type, placement_status,
    research_type, report_type, ai_analysis_status
    CASCADE`);

  console.log('✅ Database reset complete. Run db:migrate then db:seed to restore.');
}

testConnection()
  .then(reset)
  .then(() => process.exit(0))
  .catch(err => { console.error(err); process.exit(1); });
