/**
 * AccrediAI Evidence Classification Engine
 * ──────────────────────────────────────────────────────────────────────────
 * Keyword-dictionary based heuristic classifier used to suggest which NAAC
 * or NBA/OBE criterion a given document most likely provides evidence for.
 *
 * This module is intentionally free of database and Express dependencies —
 * it is a pure text-classification engine that `aiAnalysisService.ts`
 * orchestrates against persisted documents. Keeping it isolated here makes
 * it straightforward to unit test, swap for a more sophisticated model
 * later (e.g. embeddings-based similarity), or reuse outside the HTTP layer.
 */

export interface CriterionSuggestion {
  criterion_ref: string;
  confidence: number;
  matched_keywords: string[];
}

// ─── Criterion keyword dictionaries ────────────────────────────────────────────

export const NAAC_KEYWORDS: Record<string, string[]> = {
  C1: ['curriculum', 'syllabus', 'course design', 'academic flexibility', 'choice based credit', 'cbcs', 'elective'],
  C2: ['teaching', 'learning outcome', 'evaluation', 'assessment', 'pedagogy', 'student-centric', 'co-attainment', 'feedback'],
  C3: ['research', 'publication', 'patent', 'innovation', 'incubation', 'consultancy', 'extension activity', 'funded project'],
  C4: ['infrastructure', 'laboratory', 'library', 'classroom', 'ict', 'learning resources', 'physical facilities'],
  C5: ['scholarship', 'student support', 'mentoring', 'placement', 'progression', 'alumni', 'grievance'],
  C6: ['governance', 'leadership', 'management', 'perspective plan', 'administration', 'e-governance', 'strategy'],
  C7: ['institutional value', 'best practice', 'gender equity', 'environment', 'sustainability', 'human value'],
};

export const NBA_KEYWORDS: Record<string, string[]> = {
  C1: ['vision', 'mission', 'program educational objective', 'peo'],
  C2: ['program outcome', 'course outcome', 'po', 'co', 'attainment'],
  C3: ['outcome based education', 'obe', 'curriculum design'],
  C4: ['student performance', 'pass percentage', 'placement', 'higher studies'],
  C5: ['faculty', 'faculty information', 'faculty contribution'],
  C6: ['facilities', 'laboratory', 'technical manpower'],
};

// ─── Scoring primitives ─────────────────────────────────────────────────────────

/**
 * Returns the fraction (0–1) of keywords from the given list found in text.
 * Exposed for callers that want a raw match ratio rather than the confidence
 * curve used by `suggestCriteria`.
 */
export function scoreKeywordMatch(text: string, keywords: string[]): number {
  const lower = text.toLowerCase();
  let hits = 0;
  for (const kw of keywords) {
    if (lower.includes(kw.toLowerCase())) hits++;
  }
  return keywords.length === 0 ? 0 : Math.round((hits / keywords.length) * 100) / 100;
}

/**
 * Scans `text` against every criterion in `dictionary` and returns ranked
 * suggestions (highest confidence first). Confidence is a heuristic curve:
 * a base of 0.3 plus 0.15 per matched keyword, capped at 0.95 (the engine
 * never claims absolute certainty).
 */
export function suggestCriteria(
  text: string,
  dictionary: Record<string, string[]>
): CriterionSuggestion[] {
  const results: CriterionSuggestion[] = [];
  const lower = text.toLowerCase();

  for (const [ref, keywords] of Object.entries(dictionary)) {
    const matched = keywords.filter(k => lower.includes(k.toLowerCase()));
    if (matched.length > 0) {
      results.push({
        criterion_ref: ref,
        confidence: Math.min(0.95, 0.3 + matched.length * 0.15),
        matched_keywords: matched,
      });
    }
  }

  return results.sort((a, b) => b.confidence - a.confidence);
}

/**
 * Convenience wrapper: classifies text against both NAAC and NBA
 * dictionaries in one call, returning both suggestion lists plus the
 * single highest-confidence suggestion across either framework.
 */
export function classifyDocument(text: string): {
  naac_suggestions: CriterionSuggestion[];
  nba_suggestions: CriterionSuggestion[];
  top_suggestion: (CriterionSuggestion & { framework: 'naac' | 'nba' }) | null;
} {
  const naac_suggestions = suggestCriteria(text, NAAC_KEYWORDS);
  const nba_suggestions = suggestCriteria(text, NBA_KEYWORDS);

  const naacTop = naac_suggestions[0] ? { ...naac_suggestions[0], framework: 'naac' as const } : null;
  const nbaTop = nba_suggestions[0] ? { ...nba_suggestions[0], framework: 'nba' as const } : null;

  let top_suggestion: (CriterionSuggestion & { framework: 'naac' | 'nba' }) | null = null;
  if (naacTop && nbaTop) {
    top_suggestion = naacTop.confidence >= nbaTop.confidence ? naacTop : nbaTop;
  } else {
    top_suggestion = naacTop ?? nbaTop ?? null;
  }

  return { naac_suggestions, nba_suggestions, top_suggestion };
}
