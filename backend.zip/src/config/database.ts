import { Pool, PoolClient, QueryResult, QueryResultRow } from 'pg';
import config from '../config';

const pool = new Pool({
  connectionString: config.db.url,
  max: config.db.poolMax,
  idleTimeoutMillis: config.db.idleTimeout,
  connectionTimeoutMillis: config.db.connectTimeout,
  ssl: config.isProd ? { rejectUnauthorized: false } : false,
});

pool.on('error', (err: Error) => {
  console.error('[DB] Unexpected idle client error:', err.message);
});

pool.on('connect', () => {
  if (config.isDev) console.log('[DB] New client connected to pool');
});

// ─── Core query helper ────────────────────────────────────────────────────────

export async function query<T extends QueryResultRow = Record<string, unknown>>(
  text: string,
  params?: unknown[]
): Promise<QueryResult<T>> {
  const start = Date.now();
  try {
    const result = await pool.query<T>(text, params);
    if (config.isDev) {
      const ms = Date.now() - start;
      const preview = text.replace(/\s+/g, ' ').trim().slice(0, 100);
      console.log(`[DB] ${ms}ms | rows=${result.rowCount} | ${preview}`);
    }
    return result;
  } catch (err) {
    const e = err as Error;
    console.error('[DB] Query error:', e.message, '\nSQL:', text.slice(0, 200));
    throw err;
  }
}

// ─── Transaction helper ───────────────────────────────────────────────────────

export async function withTransaction<T>(
  fn: (client: PoolClient) => Promise<T>
): Promise<T> {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await fn(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

// ─── Single row helpers ───────────────────────────────────────────────────────

export async function queryOne<T extends QueryResultRow = Record<string, unknown>>(
  text: string,
  params?: unknown[]
): Promise<T | null> {
  const result = await query<T>(text, params);
  return result.rows[0] ?? null;
}

export async function queryMany<T extends QueryResultRow = Record<string, unknown>>(
  text: string,
  params?: unknown[]
): Promise<T[]> {
  const result = await query<T>(text, params);
  return result.rows;
}

// ─── Connectivity check ───────────────────────────────────────────────────────

export async function testConnection(): Promise<void> {
  const row = await queryOne<{ now: string }>('SELECT NOW() AS now');
  console.log(`✅ PostgreSQL connected — server time: ${row?.now}`);
}

export default pool;
