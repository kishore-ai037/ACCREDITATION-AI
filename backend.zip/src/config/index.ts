import dotenv from 'dotenv';
import path from 'path';

dotenv.config({ path: path.resolve(process.cwd(), '.env') });

function require_env(key: string): string {
  const value = process.env[key];
  if (!value) throw new Error(`Missing required environment variable: ${key}`);
  return value;
}

function optional_env(key: string, fallback: string): string {
  return process.env[key] ?? fallback;
}

const config = {
  env: optional_env('NODE_ENV', 'development'),
  port: parseInt(optional_env('PORT', '4000'), 10),

  db: {
    url: require_env('DATABASE_URL'),
    poolMax: parseInt(optional_env('DB_POOL_MAX', '20'), 10),
    idleTimeout: parseInt(optional_env('DB_IDLE_TIMEOUT', '30000'), 10),
    connectTimeout: parseInt(optional_env('DB_CONNECT_TIMEOUT', '5000'), 10),
  },

  jwt: {
    secret: require_env('JWT_SECRET'),
    expiresIn: optional_env('JWT_EXPIRES_IN', '7d'),
    refreshSecret: require_env('JWT_REFRESH_SECRET'),
    refreshExpiresIn: optional_env('JWT_REFRESH_EXPIRES_IN', '30d'),
  },

  cors: {
    frontendUrl: optional_env('FRONTEND_URL', 'http://localhost:3000'),
  },

  upload: {
    dir: path.resolve(process.cwd(), optional_env('UPLOAD_DIR', './uploads')),
    maxFileSizeMb: parseInt(optional_env('MAX_FILE_SIZE_MB', '50'), 10),
  },

  rateLimit: {
    windowMs: parseInt(optional_env('RATE_LIMIT_WINDOW_MS', '900000'), 10),
    max: parseInt(optional_env('RATE_LIMIT_MAX', '200'), 10),
  },

  isDev: optional_env('NODE_ENV', 'development') === 'development',
  isProd: optional_env('NODE_ENV', 'development') === 'production',
} as const;

export default config;
