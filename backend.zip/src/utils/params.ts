/**
 * Express 5's bundled types widen `req.params[key]` to `string | string[]`
 * to account for wildcard routes (e.g. `/files/*path`). AccrediAI's routes
 * never use that pattern, so every named param is a single string at
 * runtime. This helper narrows the type at the controller boundary so
 * service functions can keep simple `string` signatures.
 */
export function paramId(value: string | string[]): string {
  return Array.isArray(value) ? value[0] : value;
}
