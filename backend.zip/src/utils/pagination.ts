import { Request } from 'express';
import { PaginationParams, PaginatedResponse } from '../types';

export function parsePagination(req: Request, defaultLimit = 20): PaginationParams {
  const page  = Math.max(1, parseInt((req.query.page  as string) ?? '1',  10) || 1);
  const limit = Math.min(100, Math.max(1, parseInt((req.query.limit as string) ?? String(defaultLimit), 10) || defaultLimit));
  return { page, limit, offset: (page - 1) * limit };
}

export function buildPaginatedResponse<T>(
  data: T[],
  total: number,
  { page, limit }: PaginationParams
): PaginatedResponse<T> {
  return {
    data,
    total,
    page,
    limit,
    totalPages: Math.ceil(total / limit),
  };
}
