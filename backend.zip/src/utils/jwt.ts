import jwt from 'jsonwebtoken';
import config from '../config';
import { AuthPayload } from '../types';

/**
 * Strip JWT registered claims from a decoded payload so it can be
 * re-signed without the "payload already has an exp property" error.
 */
function toCleanPayload(decoded: AuthPayload): AuthPayload {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { iat, exp, iss, aud, nbf, jti, ...clean } =
    decoded as AuthPayload & { iat?: number; exp?: number; iss?: string; aud?: unknown; nbf?: number; jti?: string };
  return clean as AuthPayload;
}

export function signAccessToken(payload: AuthPayload): string {
  return jwt.sign(toCleanPayload(payload), config.jwt.secret, {
    expiresIn: config.jwt.expiresIn as jwt.SignOptions['expiresIn'],
    issuer: 'AccrediAI',
    audience: 'accredi-client',
  });
}

export function signRefreshToken(payload: AuthPayload): string {
  return jwt.sign(toCleanPayload(payload), config.jwt.refreshSecret, {
    expiresIn: config.jwt.refreshExpiresIn as jwt.SignOptions['expiresIn'],
    issuer: 'AccrediAI',
    audience: 'accredi-client',
  });
}

export function verifyAccessToken(token: string): AuthPayload {
  return jwt.verify(token, config.jwt.secret, {
    issuer: 'AccrediAI',
    audience: 'accredi-client',
  }) as AuthPayload;
}

export function verifyRefreshToken(token: string): AuthPayload {
  return jwt.verify(token, config.jwt.refreshSecret, {
    issuer: 'AccrediAI',
    audience: 'accredi-client',
  }) as AuthPayload;
}
