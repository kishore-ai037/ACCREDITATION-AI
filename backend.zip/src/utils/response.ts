import { Response } from 'express';

// ─────────────────────────────────────────────────────────────────────────
// Existing helpers — signatures and behavior unchanged.
// Every controller currently importing sendSuccess, sendCreated, sendError,
// sendNotFound, sendUnauthorized, sendForbidden, or sendConflict continues
// to work exactly as before; nothing below this comment was touched.
// ─────────────────────────────────────────────────────────────────────────

export function sendSuccess<T>(
  res: Response,
  data: T,
  message = 'Success',
  statusCode = 200
): void {
  res.status(statusCode).json({ success: true, message, data });
}

export function sendCreated<T>(res: Response, data: T, message = 'Created'): void {
  sendSuccess(res, data, message, 201);
}

export function sendError(
  res: Response,
  message: string,
  statusCode = 400,
  errors?: string[]
): void {
  res.status(statusCode).json({ success: false, message, ...(errors ? { errors } : {}) });
}

export function sendNotFound(res: Response, entity = 'Resource'): void {
  sendError(res, `${entity} not found`, 404);
}

export function sendUnauthorized(res: Response, message = 'Unauthorized'): void {
  sendError(res, message, 401);
}

export function sendForbidden(res: Response, message = 'Forbidden'): void {
  sendError(res, message, 403);
}

export function sendConflict(res: Response, message = 'Conflict'): void {
  sendError(res, message, 409);
}

// ─────────────────────────────────────────────────────────────────────────
// New helper — additive only.
//
// `sendResponse(res, statusCode, message, data)` is the exact signature
// used by every call site across ai.controller.ts, compliance.controller.ts,
// placement.controller.ts, research.controller.ts, and
// student-record.controller.ts (45 call sites checked, all identical
// positional order: res, statusCode, message, data).
//
// It intentionally does NOT replace sendSuccess/sendCreated internally and
// does NOT change the response envelope shape — a client can't tell whether
// a given endpoint used sendSuccess/sendCreated or sendResponse; both
// produce { success, message, data }. sendResponse simply lets the status
// code be passed positionally (matching how the newer controllers already
// call it) instead of via a trailing default parameter.
//
// success is derived from statusCode (< 400 = success) rather than hardcoded
// true, so a controller can also use sendResponse for an error-shaped reply
// (e.g. sendResponse(res, 404, 'Not found', null)) without needing a second
// helper — this matches how several of the new controllers use it for both
// success and not-found/validation replies.
// ─────────────────────────────────────────────────────────────────────────

export function sendResponse<T>(
  res: Response,
  statusCode: number,
  message: string,
  data?: T
): void {
  const success = statusCode < 400;
  res.status(statusCode).json({
    success,
    message,
    ...(data !== undefined ? { data } : {}),
  });
}

export default {
  sendSuccess,
  sendCreated,
  sendError,
  sendNotFound,
  sendUnauthorized,
  sendForbidden,
  sendConflict,
  sendResponse,
};