import { Request } from 'express';
import { query } from '../config/database';
import { ActivityAction } from '../types';

interface LogOptions {
  action: ActivityAction;
  entityType?: string;
  entityId?: string;
  entityTitle?: string;
  description?: string;
  metadata?: Record<string, unknown>;
}

export async function logActivity(req: Request, opts: LogOptions): Promise<void> {
  try {
    const userId        = req.user?.userId ?? null;
    const institutionId = req.user?.institutionId ?? null;
    const ip            = req.ip ?? req.socket.remoteAddress ?? null;
    const ua            = req.get('user-agent') ?? null;

    // Fetch user name if we have userId
    let userName: string | null = null;
    if (userId) {
      const r = await query<{ name: string }>('SELECT name FROM users WHERE id=$1', [userId]);
      userName = r.rows[0]?.name ?? null;
    }

    await query(`
      INSERT INTO activity_log
        (institution_id, user_id, user_name, action, entity_type, entity_id, entity_title, description, ip_address, user_agent, metadata)
      VALUES ($1,$2,$3,$4::activity_action,$5,$6,$7,$8,$9,$10,$11)
    `, [
      institutionId,
      userId,
      userName,
      opts.action,
      opts.entityType ?? null,
      opts.entityId ?? null,
      opts.entityTitle ?? null,
      opts.description ?? null,
      ip,
      ua,
      JSON.stringify(opts.metadata ?? {}),
    ]);
  } catch {
    // Never let logging crash the request
  }
}
