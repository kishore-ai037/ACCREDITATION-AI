/**
 * src/utils/AppError.ts
 *
 * Canonical import path for AppError.
 *
 * IMPORTANT: The AppError class itself is defined in `middleware/errorHandler.ts`,
 * where `globalErrorHandler` does `if (err instanceof AppError)` to decide how to
 * format the error response. This file re-exports that exact class rather than
 * defining a second one — if this were a separate class, errors thrown via
 * `import { AppError } from '../utils/AppError'` would fail the `instanceof`
 * check in the global error handler and get silently downgraded to generic
 * 500 responses, losing their real status code and message.
 *
 * Every module that does `import { AppError } from '../utils/AppError'`
 * (department, faculty, placement, research, student-record, compliance,
 * ai-parser, etc.) is safe to leave exactly as written — this file makes
 * that import path resolve to the one real AppError class already wired
 * into the global error handler.
 *
 * Do not add a second `export class AppError` anywhere else in the codebase.
 * If AppError ever needs new behavior, change it in `middleware/errorHandler.ts`
 * and it will automatically apply here too.
 */

export { AppError } from '../middleware/errorHandler';