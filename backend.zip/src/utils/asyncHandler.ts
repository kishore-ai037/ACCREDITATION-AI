import { Request, Response, NextFunction, RequestHandler } from 'express';

/**
 * Signature of an async Express route handler — identical shape to a normal
 * Express handler, but permitted (expected) to return a Promise.
 */
type AsyncRequestHandler = (
  req: Request,
  res: Response,
  next: NextFunction
) => Promise<unknown>;

/**
 * Wraps an async route handler so that any rejected promise (i.e. any thrown
 * error inside an `async` controller function, including `throw new AppError(...)`)
 * is forwarded to `next(err)` instead of crashing the process or leaving the
 * request hanging.
 *
 * Usage:
 *   export const getDepartments = asyncHandler(async (req, res) => {
 *     const data = await DepartmentService.listDepartments(...);
 *     return sendSuccess(res, data, 'Departments fetched successfully.');
 *   });
 *
 * Handlers may declare 2 params (req, res) or 3 (req, res, next) — both are
 * valid callback shapes for RequestHandler, so no generics are required here.
 */
export function asyncHandler(fn: AsyncRequestHandler): RequestHandler {
  return function wrappedHandler(req: Request, res: Response, next: NextFunction): void {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

export default asyncHandler;