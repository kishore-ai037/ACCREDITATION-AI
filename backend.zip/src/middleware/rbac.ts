import { Request, Response, NextFunction } from 'express';
import { UserRole } from '../types';
import { sendForbidden } from '../utils/response';

/**
 * Allow only users whose role is included in the provided list.
 * Must be used after `authenticate`.
 */
export function authorize(...roles: UserRole[]) {
  return (req: Request, res: Response, next: NextFunction): void => {
    if (!req.user) {
      sendForbidden(res, 'Not authenticated');
      return;
    }
    if (!roles.includes(req.user.role as UserRole)) {
      sendForbidden(res, `Role '${req.user.role}' is not authorised for this action`);
      return;
    }
    next();
  };
}

// Convenience pre-built guards
export const adminOnly    = authorize(UserRole.ADMIN);
export const staffOrAbove = authorize(UserRole.ADMIN, UserRole.PRINCIPAL, UserRole.IQAC_COORDINATOR);
export const hodOrAbove   = authorize(UserRole.ADMIN, UserRole.PRINCIPAL, UserRole.IQAC_COORDINATOR, UserRole.HOD);
export const anyStaff     = authorize(
  UserRole.ADMIN,
  UserRole.PRINCIPAL,
  UserRole.IQAC_COORDINATOR,
  UserRole.HOD,
  UserRole.FACULTY,
);
