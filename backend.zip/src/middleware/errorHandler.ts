import { Request, Response, NextFunction } from 'express';
import config from '../config';

export class AppError extends Error {
  constructor(
    public readonly message: string,
    public readonly statusCode: number = 500,
    public readonly errors?: string[]
  ) {
    super(message);
    this.name = 'AppError';
    Object.setPrototypeOf(this, AppError.prototype);
  }
}

export function notFoundHandler(req: Request, res: Response): void {
  res.status(404).json({
    success: false,
    message: `Route ${req.method} ${req.originalUrl} not found`,
  });
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function globalErrorHandler(
  err: Error,
  _req: Request,
  res: Response,
  _next: NextFunction
): void {
  // Multer errors
  if (err.name === 'MulterError') {
    res.status(400).json({ success: false, message: err.message });
    return;
  }

  // JWT errors
  if (err.name === 'JsonWebTokenError' || err.name === 'TokenExpiredError') {
    res.status(401).json({ success: false, message: 'Invalid or expired token' });
    return;
  }

  // Validation errors from express-validator are handled per-route, but just in case:
  if (err.name === 'ValidationError') {
    res.status(422).json({ success: false, message: err.message });
    return;
  }

  // PostgreSQL unique violation
  const pgErr = err as Error & { code?: string; detail?: string };
  if (pgErr.code === '23505') {
    res.status(409).json({ success: false, message: 'Duplicate entry — ' + (pgErr.detail ?? 'already exists') });
    return;
  }
  if (pgErr.code === '23503') {
    res.status(409).json({ success: false, message: 'Foreign key constraint failed — referenced record does not exist' });
    return;
  }
  if (pgErr.code === '23502') {
    res.status(400).json({ success: false, message: 'Required field is missing' });
    return;
  }

  // Application errors
  if (err instanceof AppError) {
    res.status(err.statusCode).json({
      success: false,
      message: err.message,
      ...(err.errors ? { errors: err.errors } : {}),
    });
    return;
  }

  // Unknown — log and return 500
  console.error('[UNHANDLED ERROR]', err);
  res.status(500).json({
    success: false,
    message: config.isDev ? err.message : 'Internal server error',
    ...(config.isDev ? { stack: err.stack } : {}),
  });
}
