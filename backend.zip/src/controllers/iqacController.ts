import { Request, Response, NextFunction } from 'express';
import { paramId } from '../utils/params';
import * as iqacService from '../services/iqacService';
import { sendSuccess, sendCreated } from '../utils/response';
import { logActivity } from '../utils/logger';
import { ActivityAction } from '../types';

// ─── Meetings ──────────────────────────────────────────────────────────────────

export async function listMeetings(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const result = await iqacService.listMeetings(req);
    sendSuccess(res, result, 'IQAC meetings fetched');
  } catch (err) {
    next(err);
  }
}

export async function getMeeting(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await iqacService.getMeetingById(paramId(req.params.id), req.user!.institutionId);
    sendSuccess(res, row, 'Meeting fetched');
  } catch (err) {
    next(err);
  }
}

export async function createMeeting(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await iqacService.createMeeting(req.body, req.user!.userId, req.user!.institutionId);
    await logActivity(req, {
      action: ActivityAction.CREATE,
      entityType: 'iqac_meeting',
      entityId: (row as Record<string, unknown>).id as string,
      entityTitle: req.body.title,
      description: `Scheduled IQAC meeting: ${req.body.title}`,
    });
    sendCreated(res, row, 'IQAC meeting created successfully');
  } catch (err) {
    next(err);
  }
}

export async function updateMeeting(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await iqacService.updateMeeting(paramId(req.params.id), req.user!.institutionId, req.body);
    await logActivity(req, {
      action: ActivityAction.UPDATE,
      entityType: 'iqac_meeting',
      entityId: paramId(req.params.id),
      description: 'Updated IQAC meeting',
    });
    sendSuccess(res, row, 'Meeting updated successfully');
  } catch (err) {
    next(err);
  }
}

export async function deleteMeeting(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    await iqacService.deleteMeeting(paramId(req.params.id), req.user!.institutionId);
    await logActivity(req, {
      action: ActivityAction.DELETE,
      entityType: 'iqac_meeting',
      entityId: paramId(req.params.id),
      description: 'Deleted IQAC meeting',
    });
    sendSuccess(res, null, 'Meeting deleted successfully');
  } catch (err) {
    next(err);
  }
}

// ─── Action Plans ──────────────────────────────────────────────────────────────

export async function listActionPlans(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const result = await iqacService.listActionPlans(req);
    sendSuccess(res, result, 'Action plans fetched');
  } catch (err) {
    next(err);
  }
}

export async function createActionPlan(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await iqacService.createActionPlan(req.body, req.user!.institutionId);
    await logActivity(req, {
      action: ActivityAction.CREATE,
      entityType: 'iqac_action_plan',
      entityId: (row as Record<string, unknown>).id as string,
      entityTitle: req.body.title,
      description: `Created action plan: ${req.body.title}`,
    });
    sendCreated(res, row, 'Action plan created successfully');
  } catch (err) {
    next(err);
  }
}

export async function updateActionPlan(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await iqacService.updateActionPlan(paramId(req.params.id), req.user!.institutionId, req.body);
    await logActivity(req, {
      action: ActivityAction.UPDATE,
      entityType: 'iqac_action_plan',
      entityId: paramId(req.params.id),
      description: 'Updated action plan',
    });
    sendSuccess(res, row, 'Action plan updated successfully');
  } catch (err) {
    next(err);
  }
}

export async function deleteActionPlan(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    await iqacService.deleteActionPlan(paramId(req.params.id), req.user!.institutionId);
    await logActivity(req, {
      action: ActivityAction.DELETE,
      entityType: 'iqac_action_plan',
      entityId: paramId(req.params.id),
      description: 'Deleted action plan',
    });
    sendSuccess(res, null, 'Action plan deleted successfully');
  } catch (err) {
    next(err);
  }
}
