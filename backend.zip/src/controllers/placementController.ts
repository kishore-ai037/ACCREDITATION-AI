import { Request, Response, NextFunction } from 'express';
import { paramId } from '../utils/params';
import * as placementService from '../services/placementService';
import { sendSuccess } from '../utils/response';
import { logActivity } from '../utils/logger';
import { ActivityAction } from '../types';

export async function list(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const result = await placementService.listPlacements(req);
    sendSuccess(res, result, 'Placement records fetched');
  } catch (err) {
    next(err);
  }
}

export async function getOne(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await placementService.getPlacementById(paramId(req.params.id), req.user!.institutionId);
    sendSuccess(res, row, 'Placement record fetched');
  } catch (err) {
    next(err);
  }
}

export async function upsert(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await placementService.upsertPlacement(paramId(req.params.studentId), req.body, req.user!.institutionId);
    await logActivity(req, {
      action: ActivityAction.UPDATE,
      entityType: 'placement',
      entityId: paramId(req.params.studentId),
      description: 'Updated placement record',
    });
    sendSuccess(res, row, 'Placement record saved successfully');
  } catch (err) {
    next(err);
  }
}

export async function remove(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    await placementService.deletePlacement(paramId(req.params.id), req.user!.institutionId);
    await logActivity(req, {
      action: ActivityAction.DELETE,
      entityType: 'placement',
      entityId: paramId(req.params.id),
      description: 'Deleted placement record',
    });
    sendSuccess(res, null, 'Placement record deleted successfully');
  } catch (err) {
    next(err);
  }
}

export async function stats(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const batchYear = req.query.batch_year ? parseInt(req.query.batch_year as string, 10) : undefined;
    const row = await placementService.getPlacementStats(req.user!.institutionId, batchYear);
    sendSuccess(res, row, 'Placement statistics fetched');
  } catch (err) {
    next(err);
  }
}

export async function trend(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const rows = await placementService.getPlacementTrend(req.user!.institutionId);
    sendSuccess(res, rows, 'Placement trend fetched');
  } catch (err) {
    next(err);
  }
}
