import { Request, Response, NextFunction } from 'express';
import * as authService from '../services/authService';
import { sendSuccess, sendError } from '../utils/response';
import { logActivity } from '../utils/logger';
import { ActivityAction } from '../types';

export async function login(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const { email, password } = req.body;
    const result = await authService.login(email, password);

    req.user = {
      userId: result.user.id,
      institutionId: result.user.institution_id,
      role: result.user.role as never,
      email: result.user.email,
    };
    await logActivity(req, {
      action: ActivityAction.LOGIN,
      entityType: 'user',
      entityId: result.user.id,
      description: `${result.user.name} logged in`,
    });

    sendSuccess(res, result, 'Login successful');
  } catch (err) {
    next(err);
  }
}

export async function refresh(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const { refreshToken } = req.body;
    if (!refreshToken) {
      sendError(res, 'Refresh token is required', 400);
      return;
    }
    const tokens = await authService.refreshTokens(refreshToken);
    sendSuccess(res, tokens, 'Token refreshed');
  } catch (err) {
    next(err);
  }
}

export async function logout(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    await authService.logout(req.user!.userId);
    await logActivity(req, { action: ActivityAction.LOGOUT, description: 'User logged out' });
    sendSuccess(res, null, 'Logged out successfully');
  } catch (err) {
    next(err);
  }
}

export async function me(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const profile = await authService.getProfile(req.user!.userId);
    sendSuccess(res, profile, 'Profile fetched');
  } catch (err) {
    next(err);
  }
}

export async function changePassword(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const { currentPassword, newPassword } = req.body;
    await authService.changePassword(req.user!.userId, currentPassword, newPassword);
    sendSuccess(res, null, 'Password changed successfully');
  } catch (err) {
    next(err);
  }
}
