import { Request, Response, NextFunction } from 'express';
import { paramId } from '../utils/params';
import * as facultyService from '../services/facultyService';
import { sendSuccess, sendCreated } from '../utils/response';
import { logActivity } from '../utils/logger';
import { ActivityAction } from '../types';

export async function list(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const result = await facultyService.listFaculty(req);
    sendSuccess(res, result, 'Faculty fetched');
  } catch (err) {
    next(err);
  }
}

export async function getOne(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await facultyService.getFacultyById(paramId(req.params.id), req.user!.institutionId);
    sendSuccess(res, row, 'Faculty profile fetched');
  } catch (err) {
    next(err);
  }
}

export async function create(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await facultyService.createFaculty(req.body, req.user!.institutionId);
    await logActivity(req, {
      action: ActivityAction.CREATE,
      entityType: 'faculty',
      entityId: (row as Record<string, unknown>).id as string,
      description: 'Created faculty profile',
    });
    sendCreated(res, row, 'Faculty profile created successfully');
  } catch (err) {
    next(err);
  }
}

export async function update(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await facultyService.updateFaculty(paramId(req.params.id), req.user!.institutionId, req.body);
    await logActivity(req, {
      action: ActivityAction.UPDATE,
      entityType: 'faculty',
      entityId: paramId(req.params.id),
      description: 'Updated faculty profile',
    });
    sendSuccess(res, row, 'Faculty profile updated successfully');
  } catch (err) {
    next(err);
  }
}

export async function remove(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    await facultyService.deleteFaculty(paramId(req.params.id), req.user!.institutionId);
    await logActivity(req, {
      action: ActivityAction.DELETE,
      entityType: 'faculty',
      entityId: paramId(req.params.id),
      description: 'Deleted faculty profile',
    });
    sendSuccess(res, null, 'Faculty profile deleted successfully');
  } catch (err) {
    next(err);
  }
}

export async function stats(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await facultyService.getFacultyStats(req.user!.institutionId);
    sendSuccess(res, row, 'Faculty statistics fetched');
  } catch (err) {
    next(err);
  }
}
