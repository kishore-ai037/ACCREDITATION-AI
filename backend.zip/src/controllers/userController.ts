import { Request, Response, NextFunction } from 'express';
import { paramId } from '../utils/params';
import * as userService from '../services/userService';
import { sendSuccess, sendCreated } from '../utils/response';
import { logActivity } from '../utils/logger';
import { ActivityAction } from '../types';

export async function list(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const result = await userService.listUsers(req);
    sendSuccess(res, result, 'Users fetched');
  } catch (err) {
    next(err);
  }
}

export async function getOne(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await userService.getUserById(paramId(req.params.id), req.user!.institutionId);
    sendSuccess(res, row, 'User fetched');
  } catch (err) {
    next(err);
  }
}

export async function create(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await userService.createUser(req.body, req.user!.institutionId);
    await logActivity(req, {
      action: ActivityAction.CREATE,
      entityType: 'user',
      entityId: (row as Record<string, unknown>).id as string,
      entityTitle: req.body.name,
      description: `Created user ${req.body.email}`,
    });
    sendCreated(res, row, 'User created successfully');
  } catch (err) {
    next(err);
  }
}

export async function update(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await userService.updateUser(paramId(req.params.id), req.user!.institutionId, req.body);
    await logActivity(req, {
      action: ActivityAction.UPDATE,
      entityType: 'user',
      entityId: paramId(req.params.id),
      description: 'Updated user profile',
    });
    sendSuccess(res, row, 'User updated successfully');
  } catch (err) {
    next(err);
  }
}

export async function remove(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    await userService.deleteUser(paramId(req.params.id), req.user!.institutionId, req.user!.userId);
    await logActivity(req, {
      action: ActivityAction.DELETE,
      entityType: 'user',
      entityId: paramId(req.params.id),
      description: 'Deleted user account',
    });
    sendSuccess(res, null, 'User deleted successfully');
  } catch (err) {
    next(err);
  }
}
