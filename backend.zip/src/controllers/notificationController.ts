import { Request, Response, NextFunction } from 'express';
import { paramId } from '../utils/params';
import * as notificationService from '../services/notificationService';
import { sendSuccess } from '../utils/response';

export async function list(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const result = await notificationService.listNotifications(req);
    sendSuccess(res, result, 'Notifications fetched');
  } catch (err) {
    next(err);
  }
}

export async function unreadCount(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const count = await notificationService.getUnreadCount(req.user!.userId);
    sendSuccess(res, { count }, 'Unread count fetched');
  } catch (err) {
    next(err);
  }
}

export async function markRead(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await notificationService.markAsRead(paramId(req.params.id), req.user!.userId);
    sendSuccess(res, row, 'Notification marked as read');
  } catch (err) {
    next(err);
  }
}

export async function markAllRead(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const count = await notificationService.markAllAsRead(req.user!.userId);
    sendSuccess(res, { updated: count }, 'All notifications marked as read');
  } catch (err) {
    next(err);
  }
}

export async function remove(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    await notificationService.deleteNotification(paramId(req.params.id), req.user!.userId);
    sendSuccess(res, null, 'Notification deleted successfully');
  } catch (err) {
    next(err);
  }
}
