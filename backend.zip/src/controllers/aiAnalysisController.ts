import { Request, Response, NextFunction } from 'express';
import { paramId } from '../utils/params';
import * as aiService from '../services/aiAnalysisService';
import { sendSuccess, sendCreated } from '../utils/response';
import { logActivity } from '../utils/logger';
import { ActivityAction } from '../types';

export async function list(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const result = await aiService.listAnalyses(req);
    sendSuccess(res, result, 'AI analysis jobs fetched');
  } catch (err) {
    next(err);
  }
}

export async function getOne(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await aiService.getAnalysisById(paramId(req.params.id), req.user!.institutionId);
    sendSuccess(res, row, 'AI analysis job fetched');
  } catch (err) {
    next(err);
  }
}

export async function mapDocument(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await aiService.runDocumentMapping(req.body.document_id, req.user!.userId, req.user!.institutionId);
    await logActivity(req, {
      action: ActivityAction.AI_MAP,
      entityType: 'document',
      entityId: req.body.document_id,
      description: 'Ran AI evidence mapping on document',
    });
    sendCreated(res, row, 'AI evidence mapping completed');
  } catch (err) {
    next(err);
  }
}

export async function bulkSearch(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const criterionType = (req.body.criterion_type as 'naac' | 'nba') ?? 'naac';
    const row = await aiService.runBulkEvidenceSearch(req.user!.userId, req.user!.institutionId, criterionType);
    await logActivity(req, {
      action: ActivityAction.AI_MAP,
      entityType: 'bulk_search',
      description: `Ran bulk AI evidence search for ${criterionType.toUpperCase()}`,
    });
    sendCreated(res, row, 'Bulk evidence search completed');
  } catch (err) {
    next(err);
  }
}

export async function stats(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await aiService.getAnalysisStats(req.user!.institutionId);
    sendSuccess(res, row, 'AI analysis statistics fetched');
  } catch (err) {
    next(err);
  }
}
