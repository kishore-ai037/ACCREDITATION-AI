import { Request, Response, NextFunction } from 'express';
import { paramId } from '../utils/params';
import * as studentService from '../services/studentService';
import { sendSuccess, sendCreated } from '../utils/response';
import { logActivity } from '../utils/logger';
import { ActivityAction } from '../types';

export async function list(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const result = await studentService.listStudents(req);
    sendSuccess(res, result, 'Students fetched');
  } catch (err) {
    next(err);
  }
}

export async function getOne(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await studentService.getStudentById(paramId(req.params.id), req.user!.institutionId);
    sendSuccess(res, row, 'Student fetched');
  } catch (err) {
    next(err);
  }
}

export async function create(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await studentService.createStudent(req.body, req.user!.institutionId);
    await logActivity(req, {
      action: ActivityAction.CREATE,
      entityType: 'student',
      entityId: (row as Record<string, unknown>).id as string,
      entityTitle: req.body.name,
      description: `Added student ${req.body.name}`,
    });
    sendCreated(res, row, 'Student created successfully');
  } catch (err) {
    next(err);
  }
}

export async function update(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await studentService.updateStudent(paramId(req.params.id), req.user!.institutionId, req.body);
    await logActivity(req, {
      action: ActivityAction.UPDATE,
      entityType: 'student',
      entityId: paramId(req.params.id),
      description: 'Updated student record',
    });
    sendSuccess(res, row, 'Student updated successfully');
  } catch (err) {
    next(err);
  }
}

export async function remove(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    await studentService.deleteStudent(paramId(req.params.id), req.user!.institutionId);
    await logActivity(req, {
      action: ActivityAction.DELETE,
      entityType: 'student',
      entityId: paramId(req.params.id),
      description: 'Deleted student record',
    });
    sendSuccess(res, null, 'Student deleted successfully');
  } catch (err) {
    next(err);
  }
}

export async function stats(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await studentService.getStudentStats(req.user!.institutionId);
    sendSuccess(res, row, 'Student statistics fetched');
  } catch (err) {
    next(err);
  }
}
