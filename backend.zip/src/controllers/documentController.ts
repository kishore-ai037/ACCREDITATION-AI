import { Request, Response, NextFunction } from 'express';
import { paramId } from '../utils/params';
import * as documentService from '../services/documentService';
import { sendSuccess, sendCreated, sendError } from '../utils/response';
import { logActivity } from '../utils/logger';
import { ActivityAction, DocStatus } from '../types';

export async function list(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const result = await documentService.listDocuments(req);
    sendSuccess(res, result, 'Documents fetched');
  } catch (err) {
    next(err);
  }
}

export async function getOne(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await documentService.getDocumentById(paramId(req.params.id), req.user!.institutionId);
    sendSuccess(res, row, 'Document fetched');
  } catch (err) {
    next(err);
  }
}

export async function upload(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    if (!req.file) {
      sendError(res, 'No file uploaded', 400);
      return;
    }
    const row = await documentService.createDocument(req.file, req.body, req.user!.userId, req.user!.institutionId);
    await logActivity(req, {
      action: ActivityAction.UPLOAD,
      entityType: 'document',
      entityId: (row as Record<string, unknown>).id as string,
      entityTitle: req.body.title,
      description: `Uploaded document: ${req.body.title}`,
    });
    sendCreated(res, row, 'Document uploaded successfully');
  } catch (err) {
    next(err);
  }
}

export async function approve(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await documentService.updateDocumentStatus(
      paramId(req.params.id), req.user!.institutionId, DocStatus.APPROVED, req.user!.userId, req.body.note
    );
    await logActivity(req, {
      action: ActivityAction.APPROVE,
      entityType: 'document',
      entityId: paramId(req.params.id),
      description: 'Approved document',
    });
    sendSuccess(res, row, 'Document approved');
  } catch (err) {
    next(err);
  }
}

export async function reject(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await documentService.updateDocumentStatus(
      paramId(req.params.id), req.user!.institutionId, DocStatus.REJECTED, req.user!.userId, req.body.note
    );
    await logActivity(req, {
      action: ActivityAction.REJECT,
      entityType: 'document',
      entityId: paramId(req.params.id),
      description: `Rejected document: ${req.body.note ?? 'no reason given'}`,
    });
    sendSuccess(res, row, 'Document rejected');
  } catch (err) {
    next(err);
  }
}

export async function setStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const { status, note } = req.body;
    const row = await documentService.updateDocumentStatus(
      paramId(req.params.id), req.user!.institutionId, status, req.user!.userId, note
    );
    await logActivity(req, {
      action: ActivityAction.REVIEW,
      entityType: 'document',
      entityId: paramId(req.params.id),
      description: `Status changed to ${status}`,
    });
    sendSuccess(res, row, 'Document status updated');
  } catch (err) {
    next(err);
  }
}

export async function remove(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    await documentService.deleteDocument(paramId(req.params.id), req.user!.institutionId, req.user!.userId, req.user!.role);
    await logActivity(req, {
      action: ActivityAction.DELETE,
      entityType: 'document',
      entityId: paramId(req.params.id),
      description: 'Deleted document',
    });
    sendSuccess(res, null, 'Document deleted successfully');
  } catch (err) {
    next(err);
  }
}

export async function stats(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await documentService.getDocumentStats(req.user!.institutionId);
    sendSuccess(res, row, 'Document statistics fetched');
  } catch (err) {
    next(err);
  }
}

export async function search(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const q = (req.query.q as string) ?? '';
    const criterionType = req.query.criterion_type as string | undefined;
    const rows = await documentService.searchDocuments(req.user!.institutionId, q, criterionType);
    sendSuccess(res, rows, 'Search results fetched');
  } catch (err) {
    next(err);
  }
}
