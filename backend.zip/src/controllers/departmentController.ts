import { Request, Response, NextFunction } from 'express';
import { paramId } from '../utils/params';
import * as departmentService from '../services/departmentService';
import { sendSuccess, sendCreated } from '../utils/response';
import { logActivity } from '../utils/logger';
import { ActivityAction } from '../types';

export async function list(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const result = await departmentService.listDepartments(req);
    sendSuccess(res, result, 'Departments fetched');
  } catch (err) {
    next(err);
  }
}

export async function getOne(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await departmentService.getDepartmentById(paramId(req.params.id), req.user!.institutionId);
    sendSuccess(res, row, 'Department fetched');
  } catch (err) {
    next(err);
  }
}

export async function create(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await departmentService.createDepartment(req.body, req.user!.institutionId);
    await logActivity(req, {
      action: ActivityAction.CREATE,
      entityType: 'department',
      entityId: (row as Record<string, unknown>).id as string,
      entityTitle: req.body.name,
      description: `Created department ${req.body.name}`,
    });
    sendCreated(res, row, 'Department created successfully');
  } catch (err) {
    next(err);
  }
}

export async function update(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await departmentService.updateDepartment(paramId(req.params.id), req.user!.institutionId, req.body);
    await logActivity(req, {
      action: ActivityAction.UPDATE,
      entityType: 'department',
      entityId: paramId(req.params.id),
      description: 'Updated department details',
    });
    sendSuccess(res, row, 'Department updated successfully');
  } catch (err) {
    next(err);
  }
}

export async function remove(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    await departmentService.deleteDepartment(paramId(req.params.id), req.user!.institutionId);
    await logActivity(req, {
      action: ActivityAction.DELETE,
      entityType: 'department',
      entityId: paramId(req.params.id),
      description: 'Deleted department',
    });
    sendSuccess(res, null, 'Department deleted successfully');
  } catch (err) {
    next(err);
  }
}
