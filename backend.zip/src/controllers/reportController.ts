import { Request, Response, NextFunction } from 'express';
import { paramId } from '../utils/params';
import * as reportService from '../services/reportService';
import { sendSuccess, sendCreated, sendError } from '../utils/response';
import { logActivity } from '../utils/logger';
import { ActivityAction } from '../types';
import fs from 'fs';

export async function list(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const result = await reportService.listReports(req);
    sendSuccess(res, result, 'Reports fetched');
  } catch (err) {
    next(err);
  }
}

export async function getOne(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await reportService.getReportById(paramId(req.params.id), req.user!.institutionId);
    sendSuccess(res, row, 'Report fetched');
  } catch (err) {
    next(err);
  }
}

export async function generate(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await reportService.generateReport(req.body, req.user!.userId, req.user!.institutionId);
    await logActivity(req, {
      action: ActivityAction.CREATE,
      entityType: 'report',
      entityId: (row as Record<string, unknown>).id as string,
      entityTitle: req.body.title,
      description: `Generated report: ${req.body.title}`,
    });
    sendCreated(res, row, 'Report generated successfully');
  } catch (err) {
    next(err);
  }
}

export async function download(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const report = await reportService.getReportById(paramId(req.params.id), req.user!.institutionId);
    const filePath = (report as Record<string, unknown>).file_path as string | null;

    if (!filePath || !fs.existsSync(filePath)) {
      sendError(res, 'Report file not available', 404);
      return;
    }

    res.download(filePath, `${(report as Record<string, unknown>).title}.json`);
  } catch (err) {
    next(err);
  }
}

export async function remove(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    await reportService.deleteReport(paramId(req.params.id), req.user!.institutionId);
    await logActivity(req, {
      action: ActivityAction.DELETE,
      entityType: 'report',
      entityId: paramId(req.params.id),
      description: 'Deleted report',
    });
    sendSuccess(res, null, 'Report deleted successfully');
  } catch (err) {
    next(err);
  }
}
