import { Request, Response, NextFunction } from 'express';
import * as dashboardService from '../services/dashboardService';
import { sendSuccess } from '../utils/response';

export async function summary(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await dashboardService.getDashboardSummary(req.user!.institutionId);
    sendSuccess(res, row, 'Dashboard summary fetched');
  } catch (err) {
    next(err);
  }
}

export async function recentActivity(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const limit = req.query.limit ? parseInt(req.query.limit as string, 10) : 10;
    const rows = await dashboardService.getRecentActivity(req.user!.institutionId, limit);
    sendSuccess(res, rows, 'Recent activity fetched');
  } catch (err) {
    next(err);
  }
}

export async function documentTrend(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const months = req.query.months ? parseInt(req.query.months as string, 10) : 6;
    const rows = await dashboardService.getDocumentTrend(req.user!.institutionId, months);
    sendSuccess(res, rows, 'Document trend fetched');
  } catch (err) {
    next(err);
  }
}
