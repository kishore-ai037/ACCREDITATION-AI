import { Request, Response, NextFunction } from 'express';
import { paramId } from '../utils/params';
import * as researchService from '../services/researchService';
import { sendSuccess, sendCreated } from '../utils/response';
import { logActivity } from '../utils/logger';
import { ActivityAction } from '../types';

export async function list(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const result = await researchService.listResearch(req);
    sendSuccess(res, result, 'Research records fetched');
  } catch (err) {
    next(err);
  }
}

export async function getOne(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await researchService.getResearchById(paramId(req.params.id), req.user!.institutionId);
    sendSuccess(res, row, 'Research record fetched');
  } catch (err) {
    next(err);
  }
}

export async function create(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await researchService.createResearch(req.body, req.user!.institutionId);
    await logActivity(req, {
      action: ActivityAction.CREATE,
      entityType: 'research',
      entityId: (row as Record<string, unknown>).id as string,
      entityTitle: req.body.title,
      description: `Added research record: ${req.body.title}`,
    });
    sendCreated(res, row, 'Research record created successfully');
  } catch (err) {
    next(err);
  }
}

export async function update(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await researchService.updateResearch(paramId(req.params.id), req.user!.institutionId, req.body);
    await logActivity(req, {
      action: ActivityAction.UPDATE,
      entityType: 'research',
      entityId: paramId(req.params.id),
      description: 'Updated research record',
    });
    sendSuccess(res, row, 'Research record updated successfully');
  } catch (err) {
    next(err);
  }
}

export async function verify(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await researchService.verifyResearch(paramId(req.params.id), req.user!.institutionId, req.user!.userId);
    await logActivity(req, {
      action: ActivityAction.APPROVE,
      entityType: 'research',
      entityId: paramId(req.params.id),
      description: 'Verified research record',
    });
    sendSuccess(res, row, 'Research record verified');
  } catch (err) {
    next(err);
  }
}

export async function remove(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    await researchService.deleteResearch(paramId(req.params.id), req.user!.institutionId);
    await logActivity(req, {
      action: ActivityAction.DELETE,
      entityType: 'research',
      entityId: paramId(req.params.id),
      description: 'Deleted research record',
    });
    sendSuccess(res, null, 'Research record deleted successfully');
  } catch (err) {
    next(err);
  }
}

export async function stats(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await researchService.getResearchStats(req.user!.institutionId);
    sendSuccess(res, row, 'Research statistics fetched');
  } catch (err) {
    next(err);
  }
}
