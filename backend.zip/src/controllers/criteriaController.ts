import { Request, Response, NextFunction } from 'express';
import { paramId } from '../utils/params';
import * as criteriaService from '../services/criteriaService';
import { sendSuccess, sendCreated } from '../utils/response';
import { logActivity } from '../utils/logger';
import { ActivityAction } from '../types';

// ─── NAAC ──────────────────────────────────────────────────────────────────────

export async function listNaac(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const result = await criteriaService.listNaacCriteria(req);
    sendSuccess(res, result, 'NAAC criteria fetched');
  } catch (err) {
    next(err);
  }
}

export async function getNaacOne(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await criteriaService.getNaacCriterionById(paramId(req.params.id), req.user!.institutionId);
    sendSuccess(res, row, 'NAAC criterion fetched');
  } catch (err) {
    next(err);
  }
}

export async function createNaac(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await criteriaService.createNaacCriterion(req.body, req.user!.institutionId);
    await logActivity(req, {
      action: ActivityAction.CREATE,
      entityType: 'naac_criterion',
      entityId: (row as Record<string, unknown>).id as string,
      description: `Created NAAC criterion ${req.body.criterion_no}`,
    });
    sendCreated(res, row, 'NAAC criterion created successfully');
  } catch (err) {
    next(err);
  }
}

export async function updateNaac(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await criteriaService.updateNaacCriterion(paramId(req.params.id), req.user!.institutionId, req.body);
    await logActivity(req, {
      action: ActivityAction.UPDATE,
      entityType: 'naac_criterion',
      entityId: paramId(req.params.id),
      description: 'Updated NAAC criterion progress',
    });
    sendSuccess(res, row, 'NAAC criterion updated successfully');
  } catch (err) {
    next(err);
  }
}

export async function deleteNaac(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    await criteriaService.deleteNaacCriterion(paramId(req.params.id), req.user!.institutionId);
    await logActivity(req, {
      action: ActivityAction.DELETE,
      entityType: 'naac_criterion',
      entityId: paramId(req.params.id),
      description: 'Deleted NAAC criterion',
    });
    sendSuccess(res, null, 'NAAC criterion deleted successfully');
  } catch (err) {
    next(err);
  }
}

export async function naacOverview(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await criteriaService.getNaacOverview(req.user!.institutionId);
    sendSuccess(res, row, 'NAAC overview fetched');
  } catch (err) {
    next(err);
  }
}

// ─── NBA ───────────────────────────────────────────────────────────────────────

export async function listNba(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const result = await criteriaService.listNbaCriteria(req);
    sendSuccess(res, result, 'NBA criteria fetched');
  } catch (err) {
    next(err);
  }
}

export async function getNbaOne(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await criteriaService.getNbaCriterionById(paramId(req.params.id), req.user!.institutionId);
    sendSuccess(res, row, 'NBA criterion fetched');
  } catch (err) {
    next(err);
  }
}

export async function createNba(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await criteriaService.createNbaCriterion(req.body, req.user!.institutionId);
    await logActivity(req, {
      action: ActivityAction.CREATE,
      entityType: 'nba_criterion',
      entityId: (row as Record<string, unknown>).id as string,
      description: `Created NBA criterion ${req.body.criterion_no}`,
    });
    sendCreated(res, row, 'NBA criterion created successfully');
  } catch (err) {
    next(err);
  }
}

export async function updateNba(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const row = await criteriaService.updateNbaCriterion(paramId(req.params.id), req.user!.institutionId, req.body);
    await logActivity(req, {
      action: ActivityAction.UPDATE,
      entityType: 'nba_criterion',
      entityId: paramId(req.params.id),
      description: 'Updated NBA criterion progress',
    });
    sendSuccess(res, row, 'NBA criterion updated successfully');
  } catch (err) {
    next(err);
  }
}

export async function deleteNba(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    await criteriaService.deleteNbaCriterion(paramId(req.params.id), req.user!.institutionId);
    await logActivity(req, {
      action: ActivityAction.DELETE,
      entityType: 'nba_criterion',
      entityId: paramId(req.params.id),
      description: 'Deleted NBA criterion',
    });
    sendSuccess(res, null, 'NBA criterion deleted successfully');
  } catch (err) {
    next(err);
  }
}

export async function nbaOverview(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const deptId = req.query.department_id as string | undefined;
    const rows = await criteriaService.getNbaOverviewByDept(req.user!.institutionId, deptId);
    sendSuccess(res, rows, 'NBA overview fetched');
  } catch (err) {
    next(err);
  }
}
