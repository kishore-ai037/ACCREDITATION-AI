import app from './app';
import config from './config';
import { testConnection } from './config/database';

async function bootstrap(): Promise<void> {
  try {
    await testConnection();

    const server = app.listen(config.port, () => {
      console.log('\n========================================');
      console.log('  🚀 AccrediAI Backend API');
      console.log('========================================');
      console.log(`  Environment : ${config.env}`);
      console.log(`  Port        : ${config.port}`);
      console.log(`  Health      : http://localhost:${config.port}/health`);
      console.log(`  API base    : http://localhost:${config.port}/api`);
      console.log(`  Frontend CORS: ${config.cors.frontendUrl}`);
      console.log('========================================\n');
    });

    const shutdown = (signal: string) => {
      console.log(`\n${signal} received. Shutting down gracefully…`);
      server.close(() => {
        console.log('HTTP server closed.');
        process.exit(0);
      });
      setTimeout(() => process.exit(1), 10000).unref();
    };

    process.on('SIGTERM', () => shutdown('SIGTERM'));
    process.on('SIGINT', () => shutdown('SIGINT'));

    process.on('unhandledRejection', (reason) => {
      console.error('Unhandled Rejection:', reason);
    });
    process.on('uncaughtException', (err) => {
      console.error('Uncaught Exception:', err);
      process.exit(1);
    });
  } catch (err) {
    console.error('❌ Failed to start server:', err);
    process.exit(1);
  }
}

bootstrap();
